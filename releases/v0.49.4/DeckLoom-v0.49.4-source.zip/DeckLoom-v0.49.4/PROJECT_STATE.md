# PROJECT STATE — v0.49.4

- デザイン基準を現行Web版Deckroomのスマホ表示へ変更。前回HTMLモックは操作方針と情報配置の参考に限定。現行README／TODO／PROJECT_STATEとUI実装を読み、適用するAGENTS.mdはないことを確認。
- 2026-10-10に現行HTML・CSS・ページJSを再取得。CSSのSHA-256はv0.49.2と同一。Chromiumの390px幅でcomputed styleと検索シートの開く状態を確認。TLS検証した取得をブラウザーへ渡し、外部カードデータは遮断。Androidの表示検証とは区別する。
- 基本パレットに加え、現行CSSのブランド文字・検索枠・選択面／文字／枠を共通化。HEX 35種類はCSS内に存在し、主要文字色22組は静的に4.5:1以上。Web専用エラー画面と現行ダーク表示は引き続き未確認。
- Style.ktとDeckroomComponents.ktに文字、角丸、白い操作面、細い境界、Outlinedアイコン、選択状態を集約。標準SansSerifとsp/dp、48dp操作領域を使用。Materialの自動標高色を無効化し、全画面を緑で塗らない。
- デッキ一覧・デッキ内容・検索・詳細・一人回しへ適用。実カード名／タイプをグリッドへ表示。検索の絞り込みと除外は下部シートへ集約し、元の全条件・保存済み検索・検索実行を維持。一人回しの盤面・手札寸法、サムネイル限定ドラッグと詳細からの移動を維持。
- 右上4アイコン、横一列フォルダ、検索対象・×・即時デッキ検索・表示保存、並び順メニューの継続操作、等幅ボタン、固定追加通知・一括Undo、左下閉じる、削除位置、詳細内の重複エラーと候補保持、種類別とカテゴリ／出力／両面表示を引き継ぐ。
- versionName 0.49.4 / versionCode 23。applicationId、Room 8、検索DB schema 4、JDK 17・SDK 36・Gradle 8.14.4・AGP／Kotlin／KSPと依存を維持。data／network／一人回しエンジン／ViewModel・リソース・スキーマ・テスト・Wrapperは前版とバイト一致。DB取得・日本語補完・更新とREADMEの出典を変更しない。
- assembleDebug成功、既存JUnit57件すべて成功。Roomの5テーブル移行照合／FK、ICU 76の本番22正規表現とマナ抽出9ケース成功。lintDebugは既存FullBackupContentエラー6件・警告31件・ヒント2件で失敗、前版と指摘のID・重大度・メッセージ・パスが一致。
- Sourceと前回納品v0.49.3 Source専用Patchをセットで用意。変更20・追加5・削除0。実際の前版ZIPへPatchを適用し、Source全156ファイルとのバイト一致とCRCを確認。根拠はDESIGN_RULES.md、適用はRELEASE-v0.49.4.md、検証はVALIDATION-v0.49.4.md。
- Android実機／エミュレーターの画面描画・スクロール・ドラッグ・操作感と、ユーザーのWindows Android Studioの新版Sync／Runは未確認。TODO.mdに具体的な項目を記載。クラウド環境の再利用設定は前回保存済みで、今回はツール構成を変更しない。

## v0.49.3の記録

- ユーザーのWindows版Android StudioでGradle Sync成功とGradle 8.13の非推奨警告を確認。クラウドの変更前v0.49.2ビルドでも同じ警告を再現した。同期やAPKビルドのエラーを示す警告ではない。
- Gradle Wrapperを8.14.4へ更新し、gradlew・gradlew.bat・Wrapper JARを標準タスクで再生成。配布ZIPとJARの公式SHA-256を設定・照合。警告抑制は追加しない。
- versionName 0.49.3 / versionCode 22。AGP 8.13.0・Kotlin 2.4.20・KSP 2.3.10・JDK 17・Android SDK 36・アプリ依存・applicationId・Room 8・検索DB schema 4を維持。
- v0.49.2のアプリソース・リソース・テストがバイト単位で同一。UI・Web配色・データ処理・ネットワーク・一人回し・DB取得・日本語補完・更新・出典を保持。
- 更新後GradleでassembleDebug成功、57単体テストすべて成功。完全なビルドログでDeprecatedGradleVersionWarningが出ないことを確認。Room移行照合、ICU 76の本番22正規表現とマナ抽出9ケースも成功。
- lintDebugは既存FullBackupContentエラー6件・警告31件・ヒント2件で失敗。元v0.49とID・重大度・メッセージ・対象パスが一致し、追加指摘なし。バックアップ設定やLintの抑制は変更しない。
- Sourceと前回納品v0.49.2 Source専用Patchをセットで用意。変更9・追加2・削除0ファイル。元の納品ZIPへ実際のPatch ZIPを適用し、Source全151ファイルとのバイト一致とZIPのCRCを確認済み。適用手順はRELEASE-v0.49.3.md、検証はVALIDATION-v0.49.3.md。
- ユーザーのWindows環境での新版Gradle Sync／Runと、実機の描画・スクロール・ドラッグ・操作感は未確認。TODO.mdで確認を継続する。

## v0.49.2の記録

- 前回納品のv0.49.1 Sourceを基準に、保留していたWeb配色を反映。versionName 0.49.2 / versionCode 21、Room 8・検索DB schema 4・applicationIdを維持。
- 2026-10-10にユーザー指定のWebページとリンク先CSS／ページJSがHTTP 200で取得できた。CSS後半の:rootが現在の明色パレット。背景#F6F7F4、文字#202920、カード面#FFFFFF、アクセント#547627を利用。
- 選択面・文字・境界線をWebの役割別CSS値へ対応させた。Androidのエラーは、白背景とのコントラストが低い継承destructive色ではなく、Webの負の状態の文字#A04336と面#F4E5E1を利用。Web専用エラー表示は未確認として明記。
- ライト／ダーク／端末設定の切り替えは維持。Androidダークは同じCSSに残る暗色ベースを参照したもの。現在のWebページでの暗色表示の存在・描画確認とは扱わない。すべての採用HEX色30種類は取得CSS内に存在し、主要文字色20組の静的コントラストが4.5:1以上。
- v0.49.1のデッキ一覧・検索・詳細・一人回しのUIと既存機能を維持。テーマ以外のUI実装、DB取得・日本語補完・更新・キャッシュ、データ形式と依存宣言は変更しない。
- 根拠と未確認範囲はWEB_COLORS.md、適用はRELEASE-v0.49.2.md、検証はVALIDATION-v0.49.2.md、実機チェックはTODO.md。Sourceとv0.49.1用Patchをセット配布する。
- Debugビルド・JUnit57件・Room／ICUチェックが成功。Lintは既存のエラー6件・警告31件・ヒント2件で追加指摘なし。実際のv0.49.1 ZIPへPatch ZIPを適用してSource版149ファイルとのバイト一致を確認。変更7・追加2・削除0。

## v0.49.1の記録

- 基準はユーザー添付のDeckLoom-v0.49-source.zip。選択リポジトリShinji-a/Deck_roomには初期コミットがなく、このSourceを既存の作業ディレクトリへ展開した。
- versionName 0.49.1 / versionCode 20 / applicationId jp.deckloom.app。Room 8とカード検索DB schema 4を維持。data・network・一人回しエンジン・DB移行・依存バージョンは添付版と同一。
- デッキ一覧は統率者画像・デッキ名・メモ・実枚数を整理。現在階層の子フォルダを横一列表示し、既存の階層操作を維持。
- デッキ／検索は通常時の右上4アイコン、検索対象・×・即時デッキ検索・表示保存を維持。グリッドは幅に応じてカードを複数列表示。ソートの選択ではメニューを閉じない。検索結果は要求単位で管理し、連続変更時に古い表示要求を反映しない。
- 一人回し／カードを追加は等幅・同高の固定フッター。OperationNoticeHostが最新操作の通知を1本だけ表示。追加通知は所属と実枚数、Undoは既存の一括トランザクション全体を取り消す。
- カード詳細の保存エラーをスクロール本文から固定フッターへ移した。重複エラーは詳細内で理由を表示し、候補の元データを保存失敗で変更しない。閉じる左下・削除は保存の左隣。一人回しカード詳細にも左下閉じるを適用。
- 一人回しはターン／ライフ横並び、盤面の余白と手札・領域バーの高さを整理。狭い高さでは手札を縮める。Undo／Redo・領域・カウンター・トークン連続追加・既存ドラッグ座標系・詳細からの移動は維持。
- HTMLモックは配置のみ参照。モックの紫・ダミー画像・本文・枚数・簡略動作は取り込んでいない。Web版URLは403で参照できず、実色の反映は未完了。現行Materialテーマを維持し、6種類の確認対象をWEB_COLORS.mdに明記。
- JDK 17.0.18、Android SDK 36／Build Tools 35.0.0を準備し、変更前のassembleDebugとJUnit 50件の成功を確認してから実装。再利用するinstall_script／start_skillとWebホスト許可の環境設定案は保存済み。設定案の公開・反映は環境設定画面で行う。
- 変更・適用方法はRELEASE-v0.49.1.md、検証はVALIDATION-v0.49.1.md。実機／エミュレーターの描画・スクロール・ドラッグ・操作感は未確認で、TODO.mdをチェックリストとする。
- 変更後assembleDebugとJUnit 57件、Room構造照合、ICU検証が成功。Lintは元v0.49も変更後も同じFullBackupContentエラー6件・警告31件・ヒント2件で失敗。追加指摘なし。バックアップ仕様の変更・Lint抑制は行わない。
- Sourceと添付v0.49用Patchをセット配布。ZIP直下はプロジェクト相対パスでfiles階層なし。過去版の記録は以下に保持。
- 元の添付ZIPへ実際のPatch ZIPを適用し、Source版147ファイルとのバイト一致を確認。変更14・追加8・削除0。配布物にSDK・キャッシュ・署名キー・ビルド生成物を含めない。

## v0.49の記録

- 配布基準：v0.48.1。アプリ更新はversionName 0.49 / versionCode 19。
- 実装内容と適用方法はRELEASE-v0.49.md。検証はVALIDATION-v0.49.md。
- Room 7→8の追加移行：decks.groupByCategory（既定ON）、deck_cards.addedAt（既存id順で初期化）。データを破棄しない。カード検索DBはschema 4のまま。
- 追加順：新規カードと候補→メインで更新。数量増減・カテゴリ・その他編集では維持。種類別OFFでは統率者も全体のソートに従う。
- 枚数上限：Oracle IDを優先して照合。未照合を通常1枚と決めつけない。既存不整合は削除しない。確定済み一括変更は一回でUndo、変更後に別編集が入った場合は無断上書きしない。
- 領域一覧は一人回しと同じComposeルートに重ねる。ドラッグ中も元の入力処理を維持して透過。ドロップと盤面座標は同一ルート基準、専用キャンセルを優先。元位置ではキャンセルしない。
- 閉じる位置は共通ダイアログアクションで左側。一人回しカード詳細は例外として従来配置を維持。
- アプリREADMEにもDB利用元とWHISPER転載・独自訳について表示。DB生成側の直列取得・間隔・監査・キャッシュ運用は既存の別リポジトリ側。
- Sourceとv0.48.1用Patchをセット配布。Patchの直下はプロジェクト相対パスでfiles階層なし。

## 過去版の記録

## v0.48.1 日本語情報修正

[適用手順・変更内容](RELEASE-v0.48.1.md)を参照。当時の最新版は0.48.1、versionCode 18。Room schema 7・検索DB schema 4を維持。以下のv0.48記録は前版の履歴。

# DeckLoom PROJECT STATE — v0.48 / pre-v0.5

## v0.48の実装と合意

基準は配布済みv0.47.2 Source。ユーザーは現在のクラッシュが見当たらないこと、怒り狂うベイロスの日本語表示は解決したことを報告。その他のカードDB漏れはユーザーが調査する。DB生成側PRの適用済みとは推測せず、本リリースではUIとデッキ内フォルダ構造を変更する。

- フォルダはディレクトリとして扱い、現在の直下だけを表示。子フォルダは横一列のLazyRow、フォルダ行自体はデッキと一緒に縦スクロールする。縦に何段も積まない。階層検索ダイアログは画面タイトル／一覧ボタンから開く。
- 親フォルダへの戻る、フォルダ作成・改名・移動・左右の順序変更。自分／子孫への移動をUIとRepositoryで禁止。削除はトランザクション内で直接の子フォルダ・デッキを親へ移してから実行する。
- デッキの上部4アイコンは表示／検索／画像状態／メニュー。補助行を削り、一人回しは追加の左のFAB、統計はメニュー、枚数は「すべて」タブ、画像未取得数は更新アイコンのバッジ。
- 共通CardSearchToolbarで虫眼鏡▼の対象選択、入力内クリア、外側のソート。デッキ内の即時絞り込みとカテゴリ内MV順を維持。
- 左右スワイプはカテゴリ移動へ割り当て、メイン／候補／履歴はタップ。カテゴリ移動時はヘッダーを表示し、移動先を確認できる。
- 検索のDB状態はタイトル横のアイコン。状態／枚数／更新日時／更新操作はダイアログ内。長い概要行を削り、追加先デッキはフォルダアイコン・選択中の追加欄・詳細で確認する。
- 検索グリッドで画像の外側のカード名を省略。画像未取得／失敗時は名前を残す。表裏の実画像があるカードだけ切り替えを表示し、裏面smallは別キャッシュへ保存。リストにも同じ画像コンポーネントを使用。
- 一人回し上部はUndo／Redo／表示／メニューの4アイコン。履歴がなければUndo／Redoを無効化。ライフの▼から±1／±5、表示メニューへズーム／Fit／Pan、山札操作はメニュー内へ。新しいゲームは確認付き。
- 手札操作はカードと重ならない下部一列（一覧・左右移動・スライダー・次ターン・メニュー）。既存のドラッグ、ゾーン、トークン連続追加を維持。

## v0.48の互換性

- applicationId `jp.deckloom.app`、versionName `0.48`、versionCode `17`。
- Room schema **7**。本番MIGRATION_6_7でdeck_folders.parentIdと外部キー／インデックスだけを追加。旧フォルダはparentId=NULLで最上位に残る。従来の1→6の移行を維持し、破壊的初期化を使わない。
- External card-index schema 4、画像パック・既存キャッシュ・設定の形式は維持。再取得不要。
- Gradle Wrapper jarと配布物SHA-256を含む既存のWrapperを維持。
- Patchの適用元はv0.47.2。ZIP直下をsettings.gradle.ktsと同じ階層へ上書きする。files階層なし。従来と同じ署名で更新する。schema 7へ更新後に旧版へ単純に戻すことはサポートしない。

## v0.48の検証

- JDK 17.0.18 / Gradle 8.13 / Android SDK 36で `:app:assembleDebug :app:testDebugUnitTest` 成功。
- APKメタデータはapplicationId `jp.deckloom.app`、versionName `0.48`、versionCode `17`。
- JUnit **20件成功**、失敗0／エラー0／スキップ0。内訳：CardPresentation 4、FolderTree 5、Migration5To6 1、Migration6To7 1、TokenQueries 5、TokenSession 4。
- フォルダの循環移動防止・同名フォルダのパス識別、既存のデッキ／カード／メモ／履歴／保存済み検索の保持、削除時の親への移動に使うSQLと外部キー、ライフ操作時のUndo／Redo状態を確認。
- `tools/verify_room_schema.py` 成功。本番5→6→7移行後とRoom生成schema 7の5テーブル（decks、deck_cards、deck_folders、deck_change_log、saved_searches）について、列・初期値・キー・インデックスが一致。foreign_key_checkも通過。
- ICU 74で本番正規表現18箇所がコンパイル可能、マナ抽出9ケース成功。v0.47の旧式が位置8で失敗することも再現。
- v0.47.2へ配布Patch ZIPを展開し、Source版全125プロジェクトファイルとのバイト一致を確認。変更22・追加4・削除0ファイル。ZIP直下にapp等を配置。
- 残る警告はGradle／Compose非推奨APIなど。Android端末での画面描画、押しやすさ、スワイプの感触、ユーザー実データの上書き更新は未確認。TODO.mdを実機チェックリストとする。
- 移行テストはJDBC SQLiteと本番移行クラス、構造照合はPython SQLiteとRoom生成DDLによるもの。Android端末上のRoom migration instrumentation testではない。

以下は過去版の記録。仕様・バージョン・検証環境の現状は上記を優先する。

## 基準と位置づけ（v0.47時点）

v0.46-sourceを基準に、ユーザーの実機フィードバックを反映。v0.46実装分はユーザー環境で動作確認済み。v0.47はv0.5に向けてデザイン・操作を実機評価するための開発版。

ScryfallClientの `ResolvedCard` 構築に `thumbnailUrl` を追加した手修正を取り込み済み。local image_uris.small → 第1面small → frontの順に解決。

## v0.47.2：トークン候補検索のクラッシュ修正

ユーザーログ（2026-09-17 02:42:30）で `IllegalArgumentException: the bind value at index 6 is null`、`SQLiteProgram.bindString` → `CardIndexStore.tokenByName` を確認。v0.47のP/T絞り込み追加で、P/T未指定時も6個の引数にnullを含めていたことが原因。v0.46にはこのP/T条件がなく、v0.47.1のマナ修正とは別件。

`data/TokenQueries.kt` へクエリ生成を分離し、P/T指定時だけAND条件と引数を追加。引数は非nullの `List<String>`。空文字をnullの代用品にせず、明示した空文字は従来どおり一致条件とする。英語名／日本語名のORを括弧でまとめ、双方へP/T条件が適用されることを確認。CardIndexStoreはこのクエリをrawQueryへ渡す。

サムネイル・画像の遅延反映・ダイアログを開いたままの連続追加・Undo/Redoは変更していない。Room schema 6、カード検索DB schema 4、DB移行コードは維持。配布はフル版とv0.47.1向けPatch。Patchはプロジェクト相対パスをZIP直下へ配置する。

## v0.47.2の検証結果と制限

- 本番のSQLリテラルとJUnit内のfixture SQLをPython SQLiteで実行し、12ケース成功。P/T未指定、英語大文字小文字、日本語名、片方だけ指定、両方指定、非一致、空文字、可変P/T、引用符付き入力を確認。
- `TokenQueriesTest` 5件を追加。本番のクエリ生成を呼び、引数数・非null・SQLite結果・日本語／英語双方への条件適用を確認する内容。JDBCはnullを受け付けるため、Androidの非null制約を明示的に検証する。
- 現在の環境にAndroid SDK・Gradle・Kotlinコンパイラがないため、JUnitテスト、Androidビルド、実機操作は未実施。Python検証はKotlinの条件分岐やAndroid描画の実行確認ではない。
- PatchのZIPを実際にv0.47.1へ適用し、v0.47.2フル版の全121プロジェクトファイルとのバイト一致を確認。変更8・追加2・削除0ファイル。
- 根拠：[Android API](https://developer.android.com/reference/android/database/sqlite/SQLiteProgram#bindAllArgsAsStrings(java.lang.String[]))、[AOSP SQLiteProgram](https://android.googlesource.com/platform/frameworks/base/+/refs/heads/main/core/java/android/database/sqlite/SQLiteProgram.java)。

## v0.47.1：マナ表示クラッシュの修正

ユーザーログ（2026-09-17 02:26:28）で `PatternSyntaxException`、パターン `\{[^}]+}`、位置8、`ManaText.kt:25` → `HomeScreen.kt:104` を確認。マナ表示用正規表現の閉じ波括弧をエスケープしていなかったことが原因。このログはDB移行の失敗を示していない。

`Regex("\\{[^}]+\\}")` へ修正。挙動の修正はこの式のみで、バージョン表記・User-Agent・文書・ICU検証スクリプトを更新。Room schema 6、カード検索DB schema 4、DB移行コードはv0.47と同じ。

前の「見た目が変わらない」件は、ユーザー確認でfiles階層のコピー先が原因と判明済み。クラッシュとは別件。Patchは今後もフル版とセットで配布し、直前版を基準にZIP直下をプロジェクトと同じ相対パスにする。

## 合意した仕様

- デッキ詳細の下部は **閉じる／削除／保存**。削除は保存の左隣に常設し、赤い枠線と確認ダイアログを使う。
- 枚数・所属・特殊役割・ユーザーカテゴリを保存時にまとめて確定。未保存で閉じると保存／破棄を選択。候補への移動では特殊役割を解除。
- ユーザーカテゴリがあれば優先、空欄ならタイプによる自動分類へ戻る。カテゴリのプリセットにタイプ名を混ぜない。
- デッキソートはカテゴリを保ち、統率者を優先。登録順／MV昇順／MV降順／名前順をデッキごとに保存。未解決MVを0マナのカードと混ぜない。
- フォルダは1階層。デッキの上下移動はフォルダ内。フォルダ削除時はデッキを未分類へ移す。
- Medium上のnormal自動取得は初期値オフ。未収録カード・明示的な印刷版は取得可能。取得済みnormalは優先。検索詳細で手動取得可。
- トークンの追加ではダイアログを閉じない。画像が未取得でも即時追加し、到着後に反映。Undo/Redoやゲーム再開後に別トークンへ画像が誤付与されないようIDを再利用しない。

## 主な実装箇所

- `data/CardPresentation.kt`: 読みがな除去、実効カテゴリ、カテゴリ内ソート。
- `DeckLoomApplication.MIGRATION_5_6`: フォルダ・メモ・デッキ順序・カードソート・ユーザーカテゴリの追加移行。
- `data/DeckRepository.kt`: フォルダ操作、保存の一括トランザクション、最新行を用いた情報更新、normal/smallキャッシュ共有、トークン画像。
- `ui/HomeScreen.kt`: 統率者画像、概要・メモ、フォルダ・デッキ順序。
- `ui/DeckScreen.kt` / `ui/CardUi.kt`: 即時検索、カテゴリ一括変更、ソート、保存フッター、統率者バッジ。
- `ui/CardDatabaseSearchScreen.kt` / `ui/SearchCardImage.kt`: 一覧画像取得、詳細とリストの配置、Oracle折りたたみ、コピー3択、ページ操作、下部解除。
- `ui/HeaderScrollBehavior.kt`: 累積84dpで隠す／44dpで戻す。小さい往復・横スクロールを除外し、表示は240msで変化。
- `ui/ManaText.kt` / `ui/ManaDrawables.kt`: 公式素材55種のインライン表示。未収録記号は原文へフォールバック。
- `ui/PlaytestScreen.kt` / `playtest/Playtest.kt`: ローカルトークン画像、連続追加、top文字のみ削除。

## スキーマ・互換性

- applicationId `jp.deckloom.app`、versionName `0.47.2`、versionCode `16`。
- Room schema 6（5→6を追加）。1→2→3→4→5の既存経路を維持。
- External card-index schema 4は維持。DB生成側の再配布は今回不要。
- 旧categoryは後方参照のため保持し、新userCategoryへ独自名のみ移行。標準分類名と同名だった独自カテゴリは旧データから区別できない。
- 非破壊の移行。デッキ／カードの削除による初期化やfallbackToDestructiveMigrationは使用しない。
- 新設定は既存SharedPreferencesへ追加。検索表示の初期値は前回表示（初回はリスト）。

## v0.47.1の検証結果

- `python3 tools/verify_regex_icu.py` 成功（ICU 74）。配布ソースから正規表現リテラルを読み取って検証。
- 旧マナ式で `U_REGEX_RULE_SYNTAX at offset 8` を再現し、ユーザーログの位置8と一致。
- 修正後の本番正規表現18箇所がすべてICUでコンパイル可能。
- マナ抽出9ケース成功。通常・連続・混成・ファイレクシア・タップ・未知記号・日本語本文・絵文字・未閉じの括弧を確認。
- v0.47にPatchを適用した後のソースが、v0.47.1フル版とバイト単位で一致することを配布時に確認。
- 当時の環境にAndroid SDK・Gradle・JDKコンパイラがないため、v0.47.1のAndroidビルド、JVMテスト、Android端末上の再実行は未実施。ICU直接検証はCompose描画・Androidアプリ起動全体のテストではない。

## v0.47時点の検証記録

2026-09-16、JDK 17 / Gradle 8.13 / Android SDK 36で検証。

- `:app:assembleDebug` 成功。生成APKのapplicationIdは `jp.deckloom.app`、versionName `0.47`、versionCode `14`。
- `:app:testDebugUnitTest` 成功。8件実行、失敗0、エラー0、スキップ0（CardPresentation 4件、Migration5To6 1件、TokenSession 3件）。
- `python3 tools/verify_room_schema.py` 成功。凍結したv0.46/schema 5の定義に本番の移行SQLを実行し、Roomが生成したschema 6と照合。decks・deck_cards・deck_foldersの列、初期値、主キー、外部キー、インデックスが一致し、foreign_key_checkも通過。
- Gradle Wrapperのスクリプト・jarを同梱し、Gradle配布物のSHA-256を公式値と照合して設定。

ビルド時にCompose非推奨APIと既存の履歴表示条件の警告は残るが、コンパイルエラーはない。実機の画面操作やユーザーの実データを用いた上書き更新は未検証。

当時の追加テストは、読みがなと意味のある括弧、独自カテゴリの解除、MV順と統率者優先、未知MV、トークン連続作成・遅延画像・Undo/Redo、実際の移行SQLによるデータ維持とフォルダ削除の非連鎖を対象にしていた。ManaTextの正規表現やAndroidでの描画は対象外で、今回の不具合を検出できなかった。

## 実機確認の範囲

この環境ではAndroid端末での操作確認は行っていない。スクロールの感触、画像切替、狭い画面・文字拡大、ユーザーの実データでの上書き更新をTODO.mdにまとめた。

S-03（三顧の礼の検索漏れ）はユーザー再確認で非再現。確定不具合・修正済みとせず保留。既存の英語Oracleタイプを用いる検索条件は維持。
