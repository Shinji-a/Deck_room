package jp.deckloom.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.ErrorOutline
import jp.deckloom.app.data.CardNames
import jp.deckloom.app.data.CardCategories
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil3.compose.AsyncImage
import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import java.io.File
import jp.deckloom.app.ui.theme.LocalDeckroomControlColors

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CardThumb(card: DeckCardEntity, modifier: Modifier = Modifier, fallbackImagePath: String = "", selected: Boolean = false, onLongClick: () -> Unit = {}, onClick: () -> Unit = {}) {
    OutlinedCard(modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick).semantics { this.selected = selected },
        shape = MaterialTheme.shapes.medium,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) LocalDeckroomControlColors.current.selectionBorder else MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.outlinedCardColors(containerColor = if (selected) LocalDeckroomControlColors.current.selection else MaterialTheme.colorScheme.surface)) {
        val thumbPath = card.imagePath.takeIf { it.isNotBlank() && File(it).exists() } ?: fallbackImagePath
        Box {
        if (thumbPath.isNotBlank()) {
            AsyncImage(model = File(thumbPath), contentDescription = card.displayName, modifier = Modifier.fillMaxWidth().aspectRatio(0.716f), contentScale = ContentScale.Fit)
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(0.716f).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Text(CardNames.clean(card.displayName.ifBlank { card.inputName }), modifier = Modifier.padding(8.dp), maxLines = 4)
            }
        }
        if (card.specialRole != DeckSpecialRoles.NONE) Surface(Modifier.align(Alignment.TopStart).padding(6.dp), color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) {
            Row(Modifier.padding(5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Outlined.Star, null, modifier = Modifier.size(16.dp))
                Text(if (card.specialRole == DeckSpecialRoles.COMMANDER) "統率者" else "相棒 / 背景", style = MaterialTheme.typography.labelSmall)
            }
        }
        if (card.quantity > 1) Surface(Modifier.align(Alignment.BottomEnd).padding(6.dp), color = MaterialTheme.colorScheme.surface, shape = MaterialTheme.shapes.small) {
            Text("×${card.quantity}", modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp), style = MaterialTheme.typography.labelLarge)
        }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(CardNames.clean(card.displayName.ifBlank { card.inputName }), style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (card.displayTypeLine.isNotBlank()) Text(card.displayTypeLine, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CardRow(card: DeckCardEntity, fallbackImagePath: String = "", selected: Boolean = false, onLongClick: () -> Unit = {}, onClick: () -> Unit) {
    DeckroomListItem(
        modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick).semantics { this.selected = selected },
        divider = true,
        colors = ListItemDefaults.colors(containerColor = if (selected) LocalDeckroomControlColors.current.selection else MaterialTheme.colorScheme.surface),
        headlineContent = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                if (card.specialRole == DeckSpecialRoles.COMMANDER) Icon(Icons.Outlined.Star, "統率者", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                Text(buildString { if (card.quantity > 1) append("${card.quantity}× "); append(CardNames.clean(card.displayName.ifBlank { card.inputName })) }, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                if (card.manaCost.isNotBlank()) ManaText(card.manaCost, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 104.dp))
            }
        },
        supportingContent = {
            val role = when (card.specialRole) {
                DeckSpecialRoles.COMMANDER -> "統率者"
                DeckSpecialRoles.COMPANION_BACKGROUND -> "相棒/背景"
                else -> roleLabel(card.deckRole).takeIf { card.deckRole != DeckRoles.MAIN }.orEmpty()
            }
            Text(listOfNotNull(role.takeIf { it.isNotBlank() }, card.userCategory.takeIf { it.isNotBlank() }, card.displayTypeLine.takeIf { it.isNotBlank() }).joinToString(" · "), maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        },
        leadingContent = {
            Box(Modifier.width(48.dp).height(68.dp).clip(MaterialTheme.shapes.small)
                .border(if (selected) 2.dp else 1.dp, if (selected) LocalDeckroomControlColors.current.selectionBorder else MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small)) {
                val rowPath = card.imagePath.takeIf { it.isNotBlank() && File(it).exists() } ?: fallbackImagePath
                if (rowPath.isNotBlank()) AsyncImage(model = File(rowPath), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        },
        trailingContent = {
            if (card.cacheState == "ERROR") Icon(Icons.Outlined.ErrorOutline, "カード情報の取得エラー", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
            else if (card.imagePath.isBlank() && fallbackImagePath.isBlank()) Text("…", fontWeight = FontWeight.Bold)
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardDetailDialog(
    card: DeckCardEntity,
    fallbackImagePath: String = "",
    onDismiss: () -> Unit,
    onSave: (Int, String, String, String, () -> Unit, (String) -> Unit) -> Unit,
    categoryOptions: List<String> = emptyList(),
    onDelete: (() -> Unit)? = null,
    onRetryName: ((String) -> Unit)? = null,
    onChangePrinting: (() -> Unit)? = null,
) {
    var back by remember(card.id) { mutableStateOf(false) }
    var category by remember(card.id) { mutableStateOf(card.userCategory) }
    var role by remember(card.id) { mutableStateOf(card.deckRole) }
    var quantity by remember(card.id) { mutableIntStateOf(card.quantity) }
    var specialRole by remember(card.id) { mutableStateOf(card.specialRole) }
    var categoryMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember(card.id) { mutableStateOf(false) }
    var confirmClose by remember(card.id) { mutableStateOf(false) }
    var saving by remember(card.id) { mutableStateOf(false) }
    var error by remember(card.id) { mutableStateOf("") }
    var retryName by remember(card.id, card.inputName) { mutableStateOf(card.inputName) }
    val context = LocalContext.current
    val dirty = category != card.userCategory || role != card.deckRole || quantity != card.quantity || specialRole != card.specialRole
    val close = { if (!saving) { if (dirty) confirmClose = true else onDismiss() } }
    val save = {
        if (!dirty) onDismiss() else {
        saving = true
        error = ""
        onSave(quantity, category, role, specialRole, { saving = false; onDismiss() }, { saving = false; error = it })
        }
    }

    Dialog(onDismissRequest = close) {
        Surface(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.94f), shape = MaterialTheme.shapes.extraLarge,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
            Column(Modifier.fillMaxSize()) {
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val frontPath = card.imagePath.takeIf { it.isNotBlank() && File(it).exists() } ?: fallbackImagePath
                    val path = if (back && card.backImagePath.isNotBlank()) card.backImagePath else frontPath
                    if (path.isNotBlank()) Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AsyncImage(model = File(path), contentDescription = CardNames.clean(card.displayName), modifier = Modifier.widthIn(max = 260.dp).fillMaxWidth().aspectRatio(0.716f).clip(MaterialTheme.shapes.medium), contentScale = ContentScale.Fit)
                    }
                    if (card.backImagePath.isNotBlank()) DeckroomOutlinedButton(onClick = { back = !back }, modifier = Modifier.fillMaxWidth()) { Text(if (back) "表面を見る" else "裏面を見る") }
                    Text(CardNames.clean(card.displayName.ifBlank { card.inputName }), style = MaterialTheme.typography.titleLarge)
                    if (card.manaCost.isNotBlank()) ManaText(card.manaCost, style = MaterialTheme.typography.titleMedium)
                    if (card.displayTypeLine.isNotBlank()) Text(card.displayTypeLine, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (card.oracleText.isNotBlank()) ManaText(card.oracleText, style = MaterialTheme.typography.bodyLarge)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CopyCardMenu(CardNames.clean(card.displayName.ifBlank { card.inputName }), card.oracleText)
                        if (onChangePrinting != null) DeckroomTextButton(onClick = onChangePrinting) { Text("絵柄 / 印刷版") }
                    }
                    HorizontalDivider()
                    Text("デッキ内の設定", style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DeckroomFilterChip(selected = role == DeckRoles.MAIN, onClick = { role = DeckRoles.MAIN }, label = { Text("メイン") }, enabled = !saving)
                        DeckroomFilterChip(selected = role == DeckRoles.CANDIDATE, onClick = { role = DeckRoles.CANDIDATE; specialRole = DeckSpecialRoles.NONE }, label = { Text("候補") }, enabled = !saving)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("枚数", modifier = Modifier.weight(1f))
                        DeckroomOutlinedButton(onClick = { quantity-- }, enabled = quantity > 1 && !saving, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("−") }
                        Text(quantity.toString(), style = MaterialTheme.typography.titleMedium)
                        DeckroomOutlinedButton(onClick = { quantity++ }, enabled = !saving, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("＋") }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DeckroomFilterChip(selected = specialRole == DeckSpecialRoles.COMMANDER, enabled = role == DeckRoles.MAIN && !saving, onClick = { specialRole = if (specialRole == DeckSpecialRoles.COMMANDER) DeckSpecialRoles.NONE else DeckSpecialRoles.COMMANDER }, label = { Text("統率者") })
                        DeckroomFilterChip(selected = specialRole == DeckSpecialRoles.COMPANION_BACKGROUND, enabled = role == DeckRoles.MAIN && !saving, onClick = { specialRole = if (specialRole == DeckSpecialRoles.COMPANION_BACKGROUND) DeckSpecialRoles.NONE else DeckSpecialRoles.COMPANION_BACKGROUND }, label = { Text("相棒 / 背景") })
                    }
                    ExposedDropdownMenuBox(expanded = categoryMenu, onExpandedChange = { categoryMenu = it }) {
                        DeckroomTextField(value = category, onValueChange = { category = it }, label = { Text("ユーザーカテゴリ") }, placeholder = { Text("未指定なら自動分類") }, supportingText = { Text("空欄なら ${CardCategories.fromType(card.oracleTypeLine)} に分類") }, singleLine = true, enabled = !saving, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(categoryMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                            DropdownMenuItem(text = { Text("自動分類に戻す") }, onClick = { category = ""; categoryMenu = false })
                            categoryOptions.filter { it.isNotBlank() }.distinct().forEach { name -> DropdownMenuItem(text = { Text(name) }, onClick = { category = name; categoryMenu = false }) }
                        }
                    }
                    if (card.errorMessage.isNotBlank()) {
                        Text("カード情報の取得エラー", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.error)
                        SelectionContainer { Text(card.errorMessage.substringBefore("\n\n候補:"), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        if (onRetryName != null) {
                            card.errorMessage.substringAfter("候補:\n", "").lineSequence().filter { it.isNotBlank() }.take(3).forEach { suggestion -> DeckroomOutlinedButton(onClick = { retryName = suggestion; onRetryName(suggestion) }, modifier = Modifier.fillMaxWidth()) { Text(suggestion) } }
                            DeckroomTextField(retryName, { retryName = it }, label = { Text("カード名を修正") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            DeckroomButton(onClick = { onRetryName(retryName) }, enabled = retryName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("この名前で再照合") }
                        }
                        DeckroomTextButton(onClick = { (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("DeckLoom error", card.errorMessage)) }) { Text("エラーをコピー") }
                    }
                }
                HorizontalDivider()
                if (error.isNotBlank()) Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.heightIn(max = 112.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)
                        .semantics { liveRegion = LiveRegionMode.Polite }, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("保存できません", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onErrorContainer)
                        Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                        if (card.deckRole == DeckRoles.CANDIDATE) Text("保存前の候補データは保持されています。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    DeckroomTextButton(onClick = close, enabled = !saving, modifier = Modifier.weight(1f).heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("閉じる", maxLines = 1) }
                    if (onDelete != null) DeckroomOutlinedButton(onClick = { confirmDelete = true }, enabled = !saving, modifier = Modifier.weight(1f).heightIn(min = 48.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("削除", maxLines = 1) }
                    DeckroomButton(onClick = save, enabled = !saving, modifier = Modifier.weight(1f).heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(if (saving) "保存中" else "保存", maxLines = 1) }
                }
            }
        }
    }
    if (confirmClose) DeckLoomAlertDialog(onDismissRequest = { confirmClose = false }, title = { Text("変更を保存しますか？") }, confirmButton = { DeckroomButton(onClick = { confirmClose = false; save() }) { Text("保存") } }, dismissButton = { DeckroomTextButton(onClick = { confirmClose = false; onDismiss() }) { Text("破棄して閉じる") } })
    if (confirmDelete) DeckLoomAlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text("デッキから削除") }, text = { Text("${CardNames.clean(card.displayName.ifBlank { card.inputName })} ×${card.quantity} を削除します。") }, confirmButton = { DeckroomButton(onClick = { confirmDelete = false; onDelete?.invoke(); onDismiss() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("削除") } }, dismissButton = { DeckroomTextButton(onClick = { confirmDelete = false }) { Text("キャンセル") } })
}

@Composable
fun CopyCardMenu(name: String, text: String) {
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current
    Box {
        DeckroomIconButton(onClick = { expanded = true }) { Icon(Icons.Outlined.ContentCopy, contentDescription = "コピーする内容を選ぶ") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("名前" to CardNames.clean(name), "本文" to text, "名前＋本文" to "${CardNames.clean(name)}\n$text").forEach { (label, content) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, content)); expanded = false })
            }
        }
    }
}

fun roleLabel(role: String): String = when (role) {
    DeckRoles.COMMANDER -> "統率者"
    DeckRoles.SECOND_COMMANDER -> "第2統率者 / 背景"
    DeckRoles.COMPANION -> "相棒"
    DeckRoles.CANDIDATE -> "候補"
    else -> "メイン"
}
