package jp.deckloom.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ViewList
import androidx.compose.material.icons.automirrored.outlined.NavigateBefore
import androidx.compose.material.icons.automirrored.outlined.NavigateNext
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material.icons.outlined.NavigateBefore
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Sync
import androidx.compose.material.icons.outlined.SystemUpdate
import androidx.compose.material.icons.outlined.NavigateNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.outlined.FlipCameraAndroid
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil3.compose.AsyncImage
import jp.deckloom.app.data.CardFilterOptions
import jp.deckloom.app.data.CardIndexRecord
import jp.deckloom.app.data.CardSearchFilter
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.FilterOption
import java.io.File
import jp.deckloom.app.ui.theme.LocalDeckroomControlColors
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException

private val typeOptions = listOf(
    FilterOption("Legendary", "伝説"),
    FilterOption("Basic", "基本"),
    FilterOption("Snow", "氷雪"),
    FilterOption("Kindred", "同族"),
)

private val sortOptions = listOf(
    "NAME" to "名前（日本語優先）",
    "RELEASE_NEW" to "発売日：新しい順",
    "RELEASE_OLD" to "発売日：古い順",
    "MV_DESC" to "MV：大きい順",
    "MV_ASC" to "MV：小さい順",
    "POWER_DESC" to "パワー：大きい順",
    "POWER_ASC" to "パワー：小さい順",
    "TOUGHNESS_DESC" to "タフネス：大きい順",
    "TOUGHNESS_ASC" to "タフネス：小さい順",
)

private data class CardSearchRequest(val id: Long, val filter: CardSearchFilter, val page: Int)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CardDatabaseSearchScreen(vm: AppViewModel, initialDeckId: Long?, onBack: () -> Unit) {
    val decks by vm.decks.collectAsState()
    val saved by vm.savedSearches.collectAsState()
    val indexStatus by vm.cardIndexStatus.collectAsState()
    val packProgress by vm.imagePackProgress.collectAsState()
    val mediumProgress by vm.mediumImagePackProgress.collectAsState()
    val settings by vm.settings.collectAsState()
    var deckId by remember(initialDeckId) { mutableStateOf(initialDeckId ?: decks.firstOrNull()?.id) }
    LaunchedEffect(decks) { if (decks.none { it.id == deckId }) deckId = decks.firstOrNull()?.id }
    var filter by remember { mutableStateOf(CardSearchFilter()) }
    var results by remember { mutableStateOf<List<CardIndexRecord>>(emptyList()) }
    var page by remember { mutableIntStateOf(0) }
    var hasNext by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var searching by remember { mutableStateOf(false) }
    var gridMode by remember { mutableStateOf(when (settings.searchDisplayMode) { "GRID" -> true; "LIST" -> false; else -> settings.lastSearchGrid }) }
    var totalCount by remember { mutableIntStateOf(0) }
    var advancedOpen by remember { mutableStateOf(false) }
    var dbStatusOpen by remember { mutableStateOf(false) }
    var addingSelection by remember { mutableStateOf(false) }
    var selectionError by remember { mutableStateOf("") }
    var searchSequence by remember { mutableLongStateOf(0L) }
    var request by remember { mutableStateOf<CardSearchRequest?>(null) }
    var deckMenu by remember { mutableStateOf(false) }
    var options by remember { mutableStateOf(CardFilterOptions()) }
    var detailCard by remember { mutableStateOf<CardIndexRecord?>(null) }
    var savedOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val displayScope = rememberCoroutineScope()
    val cacheProgress by vm.cacheProgress.collectAsState()
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }

    LaunchedEffect(indexStatus.ready, indexStatus.schemaVersion) {
        if (indexStatus.ready) options = runCatching { vm.cardFilterOptions() }.getOrDefault(CardFilterOptions())
    }

    fun runSearch(resetPage: Boolean = true) {
        if (resetPage) page = 0
        request = CardSearchRequest(++searchSequence, filter, page)
        searching = true
    }
    // Changing sort repeatedly in the open menu cancels the previous UI request.
    // Each request keeps its own filter/page; late results never replace newer ones.
    LaunchedEffect(request) {
        request?.let { pending ->
            try {
                val batch = vm.searchCards(pending.filter, limit = 41, offset = pending.page * 40)
                val count = vm.searchCardCount(pending.filter)
                if (request != pending) return@LaunchedEffect
                totalCount = count
                hasNext = batch.size > 40
                results = batch.take(40)
                selected = emptySet()
                if (gridMode) gridState.scrollToItem(0) else listState.scrollToItem(0)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { vm.showNotice("検索できませんでした: ${e.message.orEmpty()}")
            } finally { if (request == pending) searching = false }
        }
    }

    fun addSelection(role: String) {
        val target = deckId ?: return
        if (addingSelection) return
        addingSelection = true; selectionError = ""
        vm.addIndexCards(target, results.filter { it.oracleId in selected }, role,
            onDone = { addingSelection = false; selected = emptySet() },
            onError = { addingSelection = false; selectionError = it })
    }

    var headerCollapsed by remember { mutableStateOf(false) }
    val collapseConnection = rememberHeaderScrollConnection { headerCollapsed = it }

    Scaffold(
        topBar = {
            DeckroomTopAppBar(
                title = {
                    Row(Modifier.heightIn(min = 48.dp).clickable { dbStatusOpen = true }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(if (selected.isEmpty()) "カード検索" else "選択中 ${selected.size}枚", style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        Icon(when { indexStatus.checking || indexStatus.updating -> Icons.Outlined.Sync; indexStatus.updateAvailable -> Icons.Outlined.SystemUpdate; indexStatus.ready -> Icons.Outlined.CheckCircle; else -> Icons.Outlined.Info },
                            "検索DBの状態：${indexStatus.message}", Modifier.size(14.dp), tint = if (indexStatus.ready && !indexStatus.updateAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.tertiary)
                    }
                },
                navigationIcon = { DeckroomIconButton(onClick = { if (selected.isNotEmpty()) selected = emptySet() else onBack() }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, null) } },
                actions = {
                    if (selected.isNotEmpty()) {
                        var exportOpen by remember { mutableStateOf(false) }
                        val copyContext = LocalContext.current
                        Box {
                            DeckroomIconButton(onClick = { exportOpen = true }) { Icon(Icons.Outlined.ContentCopy, "選択カードを出力") }
                            DropdownMenu(exportOpen, { exportOpen = false }) {
                                listOf(false to "晴れる屋形式", true to "英語形式").forEach { (english, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        val text = results.filter { it.oracleId in selected }.joinToString("\n") { "1 ${if (english) it.englishName else jp.deckloom.app.data.CardNames.clean(it.displayName)}" }
                                        copyText(copyContext, label, text); exportOpen = false; vm.showNotice("選択カードをコピーしました")
                                    })
                                }
                            }
                        }
                    }
                    DeckroomIconButton(onClick = {
                        val anchor = if (gridMode) gridState.firstVisibleItemIndex else listState.firstVisibleItemIndex
                        gridMode = !gridMode
                        vm.setLastSearchGrid(gridMode)
                        displayScope.launch { if (gridMode) gridState.scrollToItem(anchor.coerceAtMost((results.size - 1).coerceAtLeast(0))) else listState.scrollToItem(anchor.coerceAtMost((results.size - 1).coerceAtLeast(0))) }
                    }) { Icon(if (gridMode) Icons.AutoMirrored.Outlined.ViewList else Icons.Outlined.GridView, contentDescription = "表示切替") }
                    Box {
                        DeckroomIconButton(onClick = { deckMenu = true }) { Icon(Icons.Outlined.FolderOpen, contentDescription = "追加先デッキ") }
                        DropdownMenu(expanded = deckMenu, onDismissRequest = { deckMenu = false }) {
                            if (decks.isEmpty()) DropdownMenuItem(text = { Text("デッキがありません") }, onClick = { deckMenu = false }, enabled = false)
                            decks.forEach { d -> DropdownMenuItem(text = { Text(if (d.id == deckId) "✓ ${d.name}" else d.name) }, onClick = { deckId = d.id; deckMenu = false }) }
                        }
                    }
                    if (selected.isEmpty()) {
                    DeckroomIconButton(onClick = { vm.saveSearch(filter); vm.showNotice("検索条件を保存しました") }) {
                        Icon(Icons.Outlined.BookmarkAdd, contentDescription = "検索条件保存")
                    }
                    DeckroomIconButton(onClick = { savedOpen = true }) { Icon(Icons.Outlined.Bookmarks, contentDescription = "保存済み検索") }
                    } else {
                        DeckroomIconButton(onClick = { selected = emptySet(); selectionError = "" }, enabled = !addingSelection) { Icon(Icons.Outlined.Close, "選択を解除") }
                    }
                },
            )
        },
        bottomBar = {
            DeckroomFooter {
            Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            if (selected.isNotEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Text("追加先：${decks.firstOrNull { it.id == deckId }?.name ?: "未選択"}", style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.fillMaxWidth().clickable { deckMenu = true }.padding(top = 6.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${selected.size}枚選択", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
                        DeckroomTextButton(onClick = { selected = emptySet(); selectionError = "" }, enabled = !addingSelection) { Text("選択を解除") }
                    }
                    if (selectionError.isNotBlank()) Text(selectionError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.heightIn(max = 80.dp).verticalScroll(rememberScrollState()))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DeckroomButton(
                            enabled = deckId != null && !addingSelection,
                            onClick = { addSelection(DeckRoles.CANDIDATE) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        ) { Text("候補へ") }
                        DeckroomOutlinedButton(
                            enabled = deckId != null && !addingSelection,
                            onClick = { addSelection(DeckRoles.MAIN) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp),
                        ) { Text("メインへ") }
                    }
                    if (deckId == null) Text("追加するにはデッキを作成してください", style = MaterialTheme.typography.labelSmall)
                    }
            }
                SearchPagination(page, totalCount, results.size, hasNext, searching,
                    onPrevious = { page--; runSearch(false) }, onNext = { page++; runSearch(false) })
            }
            }
        },
        snackbarHost = { OperationNoticeHost(vm, visible = detailCard == null) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().nestedScroll(collapseConnection)) {
            androidx.compose.animation.AnimatedVisibility(visible = !headerCollapsed, enter = expandVertically(tween(240)), exit = shrinkVertically(tween(240))) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                CardSearchToolbar(
                    value = filter.text, onValueChange = { filter = filter.copy(text = it) },
                    scope = filter.textScope, onScopeChange = { filter = filter.copy(textScope = it) },
                    sort = filter.sortMode, sortOptions = sortOptions,
                    onSortChange = { filter = filter.copy(sortMode = it); if (results.isNotEmpty() || searching) runSearch(true) },
                    placeholder = "検索", enabled = !searching,
                    onSearch = { if (indexStatus.ready && !searching) runSearch() },
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DeckroomButton(onClick = { runSearch(true) }, enabled = indexStatus.ready && !searching) { Text(if (searching) "検索中…" else "検索") }
                    DeckroomOutlinedButton(enabled = !searching, onClick = { advancedOpen = true }) {
                        Icon(Icons.Outlined.Tune, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp))
                        Text("絞り込み${advancedCountSuffix(filter)}")
                    }
                    DeckroomOutlinedButton(enabled = !searching, onClick = { request = null; filter = CardSearchFilter(sortMode = filter.sortMode); results = emptyList(); selected = emptySet(); selectionError = ""; page = 0; hasNext = false; totalCount = 0 }) { Text("クリア") }
                }
                }
            }
            HorizontalDivider()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (gridMode) {
                    LazyVerticalGrid(columns = GridCells.Adaptive(136.dp), state = gridState, modifier = Modifier.fillMaxSize().padding(8.dp), contentPadding = PaddingValues(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        gridItems(results, key = { it.oracleId }) { card ->
                            val checked = card.oracleId in selected
                            OutlinedCard(shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(if (checked) 2.dp else 1.dp, if (checked) LocalDeckroomControlColors.current.selectionBorder else MaterialTheme.colorScheme.outlineVariant),
                                colors = CardDefaults.outlinedCardColors(containerColor = if (checked) LocalDeckroomControlColors.current.selection else MaterialTheme.colorScheme.surface), modifier = Modifier.combinedClickable(onClick = { if (selected.isNotEmpty()) selected = if (checked) selected-card.oracleId else selected+card.oracleId else detailCard=card }, onLongClick = { selected = if (checked) selected-card.oracleId else selected+card.oracleId })) {
                                Box {
                                    SearchCardImage(vm, card, Modifier.fillMaxWidth().aspectRatio(0.714f))
                                    if (selected.isNotEmpty()) Checkbox(checked=checked, onCheckedChange=null, modifier=Modifier.align(Alignment.TopStart))
                                }
                                Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(card.displayName, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(card.displayTypeLine, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp)) {
                    items(results, key = { it.oracleId }) { card ->
                        val checked = card.oracleId in selected
                        var rowFace by rememberSaveable(card.oracleId) { mutableIntStateOf(0) }
                        var rowHasBack by remember(card.oracleId) { mutableStateOf(false) }
                        DeckroomListItem(
                            colors = ListItemDefaults.colors(containerColor = if (checked) LocalDeckroomControlColors.current.selection else MaterialTheme.colorScheme.surface),
                            modifier = Modifier.combinedClickable(
                                onClick = {
                                    if (selected.isNotEmpty()) selected = if (checked) selected - card.oracleId else selected + card.oracleId
                                    else detailCard = card
                                },
                                onLongClick = { selected = if (checked) selected - card.oracleId else selected + card.oracleId },
                            ),
                            leadingContent = {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (selected.isNotEmpty()) Checkbox(checked = checked, onCheckedChange = null)
                                    SearchCardImage(vm, card, Modifier.width(52.dp).height(74.dp), compact = true,
                                        faceOverride = rowFace, onFaceChange = { rowFace = it }, showFaceToggle = false,
                                        onHasBackChange = { rowHasBack = it })
                                }
                            },
                            trailingContent = {
                                if (rowHasBack && selected.isEmpty()) DeckroomIconButton(onClick = { rowFace = 1 - rowFace }) {
                                    Icon(Icons.Outlined.FlipCameraAndroid, if (rowFace == 0) "裏面を見る" else "表面を見る", Modifier.size(18.dp))
                                }
                            },
                            headlineContent = {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(card.displayName, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                    if (card.manaCost.isNotBlank()) ManaText(card.manaCost, style = MaterialTheme.typography.bodySmall, maxLines = 1, modifier = Modifier.widthIn(max = 116.dp))
                                }
                            },
                            supportingContent = {
                                Column {
                                    Text(card.displayTypeLine, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (card.keywords.isNotEmpty()) Text(card.keywords.joinToString("・") { keyword -> options.keywords.firstOrNull { it.value == keyword }?.label ?: keyword }, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (card.displayText.isNotBlank()) ManaText(card.displayText, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                }
                            },
                        )
                        HorizontalDivider()
                    }
                }
                VerticalFastScrollbar(listState)
            }
                }
            cacheProgress?.takeIf { it.second > 0 }?.let { p ->
                LinearProgressIndicator(progress = { p.first.toFloat() / p.second.toFloat() }, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().height(3.dp))
            }
            if (packProgress.active) {
                LinearProgressIndicator(progress = { packProgress.fraction }, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().height(3.dp))
            }
            if (mediumProgress.active) LinearProgressIndicator(progress = { mediumProgress.fraction }, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().height(3.dp))
        }
    }

    if (dbStatusOpen) DeckLoomAlertDialog(
        onDismissRequest = { dbStatusOpen = false }, title = { Text("検索DBの状態") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(indexStatus.message)
            if (indexStatus.ready) Text("${indexStatus.uniqueCards}枚")
            if (indexStatus.bulkUpdatedAt.isNotBlank()) Text("データ更新：${indexStatus.bulkUpdatedAt}", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { DeckroomTextButton(enabled = !indexStatus.checking && !indexStatus.updating, onClick = { vm.refreshSearchCatalog() }) { Text(if (indexStatus.updateAvailable || !indexStatus.ready) "DBを取得・更新" else "更新を確認") } },
        dismissButton = { DeckroomTextButton(onClick = { dbStatusOpen = false }) { Text("閉じる") } },
    )

    if (advancedOpen) CardSearchFiltersSheet(
        filter = filter, options = options,
        onDismiss = { advancedOpen = false },
        onApply = { filter = it; advancedOpen = false },
    )
    if (savedOpen) SavedSearchDialog(
        saved = saved,
        onDismiss = { savedOpen = false },
        onApply = { filter = CardSearchFilter.fromJson(it.filterJson); savedOpen = false; runSearch() },
        onDelete = vm::deleteSavedSearch,
    )
    detailCard?.let { card -> CardSearchDetailDialog(vm, card, options, decks, deckId, onDismiss = { detailCard = null }) }
}

@Composable
private fun SearchPagination(page: Int, totalCount: Int, shownCount: Int, hasNext: Boolean, searching: Boolean, onPrevious: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        DeckroomTextButton(onClick = onPrevious, enabled = page > 0 && !searching, contentPadding = PaddingValues(horizontal = 4.dp)) { Icon(Icons.AutoMirrored.Outlined.NavigateBefore, null); Text("前へ") }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${if (totalCount == 0) 0 else page + 1} / ${(totalCount + 39) / 40} ページ", style = MaterialTheme.typography.labelLarge)
            Text("${if (shownCount == 0) 0 else page * 40 + 1}–${if (shownCount == 0) 0 else page * 40 + shownCount} / ${totalCount}件", style = MaterialTheme.typography.labelSmall)
        }
        DeckroomTextButton(onClick = onNext, enabled = hasNext && !searching, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("次へ"); Icon(Icons.AutoMirrored.Outlined.NavigateNext, null) }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CardSearchFiltersSheet(
    filter: CardSearchFilter, options: CardFilterOptions,
    onDismiss: () -> Unit, onApply: (CardSearchFilter) -> Unit,
) {
    // A local draft survives tab/picker changes; dismiss never commits it.
    var local by remember(filter) { mutableStateOf(filter) }
    var section by rememberSaveable { mutableIntStateOf(0) }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state,
        modifier = Modifier.fillMaxHeight(0.94f), shape = MaterialTheme.shapes.extraLarge,
        containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("検索条件", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                DeckroomTextButton(onClick = {
                    local = if (section == 0) clearAdvanced(local) else local.copy(
                        excludeName = "", excludeType = "", excludeSubtype = "", excludeText = "")
                }) { Text(if (section == 0) "条件をクリア" else "除外をクリア") }
            }
            DeckroomSegments(listOf("絞り込み", "除外${excludeCountSuffix(local)}"), section,
                { section = it }, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            val scroll = rememberScrollState()
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (section == 0) AdvancedSearchFields(local, options) { local = it }
                else {
                    Text("一致する語句を検索結果から除外します", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ExcludeSearchFields(local) { local = it }
                }
                Spacer(Modifier.height(12.dp))
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            DialogCloseRow(onClose = onDismiss) {
                DeckroomButton(onClick = { onApply(local) }) { Text("適用") }
            }
        }
    }
}

@Composable
private fun ExcludeSearchFields(filter: CardSearchFilter, onChange: (CardSearchFilter) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DeckroomTextField(filter.excludeName, { onChange(filter.copy(excludeName = it)) },
            label = { Text("名前") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        DeckroomTextField(filter.excludeType, { onChange(filter.copy(excludeType = it)) },
            label = { Text("タイプ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        DeckroomTextField(filter.excludeSubtype, { onChange(filter.copy(excludeSubtype = it)) },
            label = { Text("サブタイプ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        DeckroomTextField(filter.excludeText, { onChange(filter.copy(excludeText = it)) },
            label = { Text("本文") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun AdvancedSearchFields(filter: CardSearchFilter, options: CardFilterOptions, onChange: (CardSearchFilter) -> Unit) {
    var typeDialog by remember { mutableStateOf(false) }
    var subtypeDialog by remember { mutableStateOf(false) }
    var keywordDialog by remember { mutableStateOf(false) }
    var setDialog by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("カードタイプ", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BooleanTypeChip("クリーチャー", filter.creatureOnly) { onChange(filter.copy(creatureOnly = it)) }
            BooleanTypeChip("アーティファクト", filter.artifactOnly) { onChange(filter.copy(artifactOnly = it)) }
            BooleanTypeChip("エンチャント", filter.enchantmentOnly) { onChange(filter.copy(enchantmentOnly = it)) }
            BooleanTypeChip("インスタント", filter.instantOnly) { onChange(filter.copy(instantOnly = it)) }
            BooleanTypeChip("ソーサリー", filter.sorceryOnly) { onChange(filter.copy(sorceryOnly = it)) }
            BooleanTypeChip("土地", filter.landOnly) { onChange(filter.copy(landOnly = it)) }
            BooleanTypeChip("プレインズウォーカー", filter.planeswalkerOnly) { onChange(filter.copy(planeswalkerOnly = it)) }
            BooleanTypeChip("バトル", filter.battleOnly) { onChange(filter.copy(battleOnly = it)) }
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DeckroomOutlinedButton(onClick = { typeDialog = true }) { Text("タイプ${countSuffix(filter.typeTerms.size)}") }
            DeckroomOutlinedButton(onClick = { subtypeDialog = true }) { Text("サブタイプ${countSuffix(filter.subtypeTerms.size)}") }
            DeckroomOutlinedButton(onClick = { keywordDialog = true }) { Text("キーワード能力${countSuffix(filter.keywordTerms.size)}") }
            DeckroomOutlinedButton(onClick = { setDialog = true }) { Text("収録セット${countSuffix((filter.setCodes + listOfNotNull(filter.setCode.takeIf { it.isNotBlank() })).distinct().size)}") }
        }

        Text("固有色", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("W" to "白", "R" to "赤", "B" to "黒", "U" to "青", "G" to "緑", "C" to "無色").forEach { (symbol, label) ->
                val selected = symbol in filter.colorIdentity
                DeckroomFilterChip(
                    selected = selected,
                    onClick = {
                        val next = if (selected) filter.colorIdentity.replace(symbol, "") else filter.colorIdentity + symbol
                        onChange(filter.copy(colorIdentity = normalizeColorUi(next)))
                    },
                    label = { Text(label) },
                )
            }
        }
        if (filter.colorIdentity.isNotBlank()) {
            val coloredCount = filter.colorIdentity.count { it in "WUBRG" }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("CONTAINS" to "この色を含む", "MATCH" to "一致", "EXACT_MULTI" to "一致多色").forEach { (mode, label) ->
                    DeckroomFilterChip(
                        selected = filter.colorMode == mode,
                        onClick = { onChange(filter.copy(colorMode = mode)) },
                        enabled = mode != "EXACT_MULTI" || coloredCount >= 2,
                        label = { Text(label) },
                    )
                }
            }
            Text(
                when (filter.colorMode) {
                    "MATCH" -> "例: 青+緑なら 青 / 緑 / 青緑。無色も選択時は無色も追加"
                    "EXACT_MULTI" -> "例: 青+緑なら 青緑だけ（無色指定はこのモードでは除外）"
                    else -> "例: 青+緑なら 青緑赤なども対象。無色も選択時は無色も追加"
                },
                style = MaterialTheme.typography.labelSmall,
            )
        }

        NumericRangeRow("MV", filter.manaMin, filter.manaMax, 0..7) { min, max -> onChange(filter.copy(manaMin = min, manaMax = max)) }
        NumericRangeRow("P", filter.powerMin, filter.powerMax, 0..7) { min, max -> onChange(filter.copy(powerMin = min, powerMax = max)) }
        NumericRangeRow("T", filter.toughnessMin, filter.toughnessMax, 0..7) { min, max -> onChange(filter.copy(toughnessMin = min, toughnessMax = max)) }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DeckroomFilterChip(selected = filter.commanderLegalOnly, onClick = { onChange(filter.copy(commanderLegalOnly = !filter.commanderLegalOnly)) }, label = { Text("Commander可") })
            DeckroomFilterChip(selected = filter.legendaryOnly, onClick = { onChange(filter.copy(legendaryOnly = !filter.legendaryOnly)) }, label = { Text("伝説のみ") })
            listOf("" to "レア度すべて", "common" to "C", "uncommon" to "U", "rare" to "R", "mythic" to "M").forEach { (value, label) ->
                DeckroomFilterChip(selected = filter.rarity == value, onClick = { onChange(filter.copy(rarity = value)) }, label = { Text(label) })
            }
        }
    }

    if (typeDialog) MultiOptionDialog(
        title = "タイプ",
        options = typeOptions,
        selected = filter.typeTerms.toSet(),
        onDismiss = { typeDialog = false },
        onApply = { onChange(filter.copy(typeTerms = it.toList())); typeDialog = false },
    )
    if (subtypeDialog) MultiOptionDialog(
        title = "サブタイプ（日本語優先）",
        options = options.subtypes,
        selected = filter.subtypeTerms.toSet(),
        onDismiss = { subtypeDialog = false },
        onApply = { onChange(filter.copy(subtypeTerms = it.toList())); subtypeDialog = false },
    )
    if (keywordDialog) MultiOptionDialog(
        title = "キーワード能力（日本語優先）",
        options = options.keywords,
        selected = filter.keywordTerms.toSet(),
        onDismiss = { keywordDialog = false },
        onApply = { onChange(filter.copy(keywordTerms = it.toList())); keywordDialog = false },
    )
    if (setDialog) MultiOptionDialog(
        title = "収録セット（複数選択可）",
        options = options.sets,
        selected = (filter.setCodes + listOfNotNull(filter.setCode.takeIf { it.isNotBlank() })).toSet(),
        onDismiss = { setDialog = false },
        onApply = { onChange(filter.copy(setCode = "", setCodes = it.toList().sorted())); setDialog = false },
    )
}

@Composable
private fun BooleanTypeChip(label: String, selected: Boolean, onChange: (Boolean) -> Unit) {
    DeckroomFilterChip(selected = selected, onClick = { onChange(!selected) }, label = { Text(label) })
}

@Composable
private fun NumericRangeRow(label: String, min: Double?, max: Double?, range: IntRange, onChange: (Double?, Double?) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, modifier = Modifier.width(32.dp), fontWeight = FontWeight.SemiBold)
        NumberChoice("以上", min, range, Modifier.weight(1f)) { onChange(it, max) }
        Text("〜")
        NumberChoice("以下", max, range, Modifier.weight(1f)) { onChange(min, it) }
    }
}

@Composable
private fun NumberChoice(label: String, value: Double?, range: IntRange, modifier: Modifier = Modifier, onChange: (Double?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        DeckroomOutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$label: ${value?.cleanNumber() ?: "指定なし"}") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("指定なし") }, onClick = { onChange(null); expanded = false })
            range.forEach { n -> DropdownMenuItem(text = { Text(n.toString()) }, onClick = { onChange(n.toDouble()); expanded = false }) }
        }
    }
}

@Composable
private fun MultiOptionDialog(
    title: String,
    options: List<FilterOption>,
    selected: Set<String>,
    onDismiss: () -> Unit,
    onApply: (Set<String>) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var local by remember(selected) { mutableStateOf(selected) }
    val filtered = remember(options, query) {
        if (query.isBlank()) options else options.filter { it.label.contains(query, true) || it.value.contains(query, true) }
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.88f), shape = MaterialTheme.shapes.large, tonalElevation = 0.dp) {
            Column(Modifier.fillMaxSize()) {
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 6.dp))
                DeckroomTextField(query, { query = it }, label = { Text("検索") }, singleLine = true, leadingIcon = { Icon(Icons.Outlined.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${local.size}件選択", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                    DeckroomTextButton(onClick = { local = emptySet() }) { Text("クリア") }
                }
                val listState = rememberLazyListState()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp)) {
                        items(filtered, key = { it.value }) { option ->
                            val checked = option.value in local
                            DeckroomListItem(
                                modifier = Modifier.clickable { local = if (checked) local - option.value else local + option.value },
                                leadingContent = { Checkbox(checked, onCheckedChange = null) },
                                headlineContent = { Text(option.label) },
                                supportingContent = { if (option.label != option.value) Text(option.value, style = MaterialTheme.typography.labelSmall) },
                            )
                        }
                    }
                    VerticalFastScrollbar(listState)
                }
                DialogCloseRow(onClose = onDismiss) {
                    DeckroomButton(onClick = { onApply(local) }) { Text("適用") }
                }
            }
        }
    }
}

@Composable
private fun SingleOptionDialog(title: String, options: List<FilterOption>, selected: String, onDismiss: () -> Unit, onApply: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(options, query) { if (query.isBlank()) options else options.filter { it.label.contains(query, true) || it.value.contains(query, true) } }
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.88f), shape = MaterialTheme.shapes.large, tonalElevation = 0.dp) {
            Column(Modifier.fillMaxSize()) {
                Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 6.dp))
                DeckroomTextField(query, { query = it }, label = { Text("検索") }, singleLine = true, leadingIcon = { Icon(Icons.Outlined.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
                val listState = rememberLazyListState()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp)) {
                        item { DeckroomListItem(modifier = Modifier.clickable { onApply("") }, headlineContent = { Text("指定なし") }, leadingContent = { RadioButton(selected.isBlank(), null) }) }
                        items(filtered, key = { it.value }) { option ->
                            DeckroomListItem(
                                modifier = Modifier.clickable { onApply(option.value) },
                                leadingContent = { RadioButton(selected == option.value, null) },
                                headlineContent = { Text(option.label) },
                            )
                        }
                    }
                    VerticalFastScrollbar(listState)
                }
                DialogCloseRow(onClose = onDismiss)
            }
        }
    }
}

@Composable
private fun CardSearchDetailDialog(vm: AppViewModel, card: CardIndexRecord, options: CardFilterOptions, decks: List<jp.deckloom.app.data.DeckEntity>, currentDeckId: Long?, onDismiss: () -> Unit) {
    val settings by vm.settings.collectAsState()
    var face by rememberSaveable(card.oracleId) { mutableIntStateOf(0) }
    var hasBack by remember(card.oracleId) { mutableStateOf(false) }
    var retry by remember(card.oracleId, face) { mutableIntStateOf(0) }
    var imagePath by remember(card.oracleId, face) { mutableStateOf(vm.searchPreferredImagePath(card, face)) }
    var imageLoading by remember(card.oracleId, face) { mutableStateOf(false) }
    var imageError by remember(card.oracleId, face) { mutableStateOf("") }
    var oracleOpen by remember(card.oracleId) { mutableStateOf(false) }
    var addDeckId by remember(card.oracleId, currentDeckId) { mutableStateOf(currentDeckId ?: decks.firstOrNull()?.id) }
    var addDeckMenu by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var addError by remember(card.oracleId) { mutableStateOf("") }
    val addDeck = decks.firstOrNull { it.id == addDeckId } ?: decks.firstOrNull()
    fun add(role: String) {
        val target = addDeck ?: return
        if (adding) return
        adding = true; addError = ""
        vm.addIndexCards(target.id, listOf(card), role,
            onDone = { adding = false },
            onError = { adding = false; addError = it })
    }
    val keywordMap = remember(options.keywords) { options.keywords.associate { it.value to it.label } }
    LaunchedEffect(card.oracleId, retry) {
        try { hasBack = vm.searchHasBackFace(card) }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { /* Keep cached face controls usable offline. */ }
    }
    fun loadImage() { retry++ }
    LaunchedEffect(card.oracleId, face, settings.normalOverMedium, settings.imagePreloadMode, retry) {
        imageLoading = true; imageError = ""
        try {
            val path = vm.searchDetailImage(card, face, retry > 0)
            if (path.isNotBlank()) imagePath = path else imageError = "画像なし"
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { imageError = "画像を取得できませんでした。再試行できます。" }
        finally { imageLoading = false }
    }
    Dialog(onDismissRequest = { if (!adding) onDismiss() }) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.92f), shape = MaterialTheme.shapes.large, tonalElevation = 0.dp) {
            Column(Modifier.fillMaxSize()) {
                val state = rememberLazyListState()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(state = state, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(end = 8.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        item {
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                key(face) { StableCardImage(imagePath, card.displayName, Modifier.widthIn(max = 260.dp).fillMaxWidth().aspectRatio(0.714f), imageLoading) }
                            }
                            if (hasBack) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (face == 0) "表面" else "裏面", style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                                DeckroomTextButton(onClick = { face = 1 - face }) {
                                    Icon(Icons.Outlined.FlipCameraAndroid, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                                    Text(if (face == 0) "裏面を見る" else "表面を見る")
                                }
                            }
                            if (imageLoading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp))
                            if (imageError.isNotBlank()) Text(imageError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            if (imageError.isNotBlank() || (vm.hasMediumImage(card) && !settings.normalOverMedium)) {
                                DeckroomTextButton(enabled = !imageLoading, onClick = { loadImage() }) { Text(if (imageError.isNotBlank()) "画像を再取得" else "高画質を取得") }
                            }
                        }
                        item {
                            Text(card.displayName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            if (card.japaneseName.isNotBlank()) Text(card.englishName, style = MaterialTheme.typography.labelMedium)
                        }
                        if (card.manaCost.isNotBlank()) item { ManaText(card.manaCost, style = MaterialTheme.typography.titleMedium) }
                        item { Text(card.displayTypeLine, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        if (card.displayText.isNotBlank()) item { ManaText(card.displayText, style = MaterialTheme.typography.bodyLarge) }
                        if (card.power.isNotBlank() || card.toughness.isNotBlank()) item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Text("${card.power}/${card.toughness}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                        }
                        if (card.loyalty.isNotBlank()) item { Text("忠誠度 ${card.loyalty}") }
                        if (card.defense.isNotBlank()) item { Text("守備値 ${card.defense}") }
                        item {
                            HorizontalDivider(Modifier.padding(bottom = 10.dp))
                            val identity = "WUBRG".filter { it in card.colorIdentity }.map { "{$it}" }.joinToString("").ifBlank { "無色" }
                            val rarity = mapOf("common" to "コモン", "uncommon" to "アンコモン", "rare" to "レア", "mythic" to "神話レア", "special" to "特殊", "bonus" to "ボーナス")[card.rarity] ?: card.rarity
                            ManaText("MV ${card.manaValue.cleanNumber()} / 固有色 $identity / $rarity", style = MaterialTheme.typography.bodySmall)
                        }
                        if (card.firstReleasedAt.isNotBlank()) item { Text("初出 ${card.firstReleasedAt}", style = MaterialTheme.typography.bodySmall) }
                        if (card.keywords.isNotEmpty()) item { Text(card.keywords.joinToString("・") { keywordMap[it] ?: it }, style = MaterialTheme.typography.bodySmall) }
                        item { Text("Commander: ${card.legalCommander} / ${card.setCode.uppercase()}", style = MaterialTheme.typography.labelSmall) }
                        if (card.englishOracleText.isNotBlank()) item {
                            Column {
                                DeckroomTextButton(onClick = { oracleOpen = !oracleOpen }, contentPadding = PaddingValues(0.dp)) { Text("英語Oracle ${if (oracleOpen) "▴" else "▾"}") }
                                if (oracleOpen) ManaText(card.englishOracleText, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    VerticalFastScrollbar(state)
                }
                HorizontalDivider()
                if (addError.isNotBlank()) Surface(color = MaterialTheme.colorScheme.errorContainer) {
                    Text(addError, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 96.dp).verticalScroll(rememberScrollState()).padding(12.dp))
                }
                OperationNoticeHost(vm, visible = addError.isBlank())
                if (addDeck == null) Text("先にデッキを作成してください", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(12.dp))
                else Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    DeckroomTextButton(onClick = { addDeckMenu = true }, enabled = !adding, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                        Text("追加先：${addDeck.name}", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Icon(Icons.Outlined.ArrowDropDown, "追加先デッキを選択")
                    }
                    DropdownMenu(expanded = addDeckMenu, onDismissRequest = { addDeckMenu = false }) {
                        decks.forEach { d -> DropdownMenuItem(text = { Text(d.name, maxLines = 1, overflow = TextOverflow.Ellipsis) }, enabled = !adding, onClick = { addDeckId = d.id; addDeckMenu = false; addError = "" }) }
                    }
                }
                if (addDeck != null) Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DeckroomButton(enabled = !adding, onClick = { add(DeckRoles.MAIN) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text(if (adding) "追加中…" else "メインに追加") }
                    DeckroomOutlinedButton(enabled = !adding, onClick = { add(DeckRoles.CANDIDATE) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("候補に追加") }
                }
                DialogCloseRow(onClose = onDismiss, enabled = !adding) {
                    CopyCardMenu(card.displayName, card.displayText)
                }
            }
        }
    }
}

/** Keep the decoded previous image visible while a higher-resolution file is loading. */
@Composable
private fun StableCardImage(path: String, name: String, modifier: Modifier = Modifier, loading: Boolean = false) {
    var displayedPath by remember(name) { mutableStateOf("") }
    Box(modifier, contentAlignment = Alignment.Center) {
        if (displayedPath.isNotBlank() && displayedPath != path) AsyncImage(model = File(displayedPath), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        if (path.isNotBlank()) AsyncImage(model = File(path), contentDescription = name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit, onSuccess = { displayedPath = path })
        else Text(if (loading) "画像を取得中…" else "画像なし", style = MaterialTheme.typography.labelSmall)
    }
}

private fun clearAdvanced(current: CardSearchFilter): CardSearchFilter = CardSearchFilter(
    text = current.text,
    textScope = current.textScope,
    sortMode = current.sortMode,
)

private fun excludeCountSuffix(filter: CardSearchFilter): String {
    val n = listOf(filter.excludeName, filter.excludeType, filter.excludeSubtype, filter.excludeText).count { it.isNotBlank() }
    return if (n == 0) "" else " ($n)"
}

private fun advancedCountSuffix(filter: CardSearchFilter): String {
    var count = 0
    count += filter.typeTerms.size + filter.subtypeTerms.size + filter.keywordTerms.size
    if (filter.colorIdentity.isNotBlank()) count++
    if (filter.manaMin != null || filter.manaMax != null) count++
    if (filter.powerMin != null || filter.powerMax != null) count++
    if (filter.toughnessMin != null || filter.toughnessMax != null) count++
    if (filter.rarity.isNotBlank()) count++
    count += listOf(filter.excludeName, filter.excludeType, filter.excludeSubtype, filter.excludeText).count { it.isNotBlank() }
    if (filter.setCode.isNotBlank() || filter.setCodes.isNotEmpty()) count++
    if (filter.commanderLegalOnly) count++
    if (filter.legendaryOnly) count++
    listOf(filter.creatureOnly, filter.artifactOnly, filter.enchantmentOnly, filter.instantOnly, filter.sorceryOnly, filter.landOnly, filter.planeswalkerOnly, filter.battleOnly).forEach { if (it) count++ }
    return if (count == 0) "" else " ($count)"
}

@Composable
private fun SavedSearchDialog(
    saved: List<jp.deckloom.app.data.SavedSearchEntity>,
    onDismiss: () -> Unit,
    onApply: (jp.deckloom.app.data.SavedSearchEntity) -> Unit,
    onDelete: (Long) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.75f), shape = MaterialTheme.shapes.large, tonalElevation = 0.dp) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(14.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("保存済み検索", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                }
                if (saved.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("保存済み検索はありません") }
                else LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(saved, key = { it.id }) { item ->
                        DeckroomListItem(
                            modifier = Modifier.clickable { onApply(item) },
                            headlineContent = { Text(item.description, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { DeckroomTextButton(onClick = { onDelete(item.id) }) { Text("削除") } },
                        )
                        HorizontalDivider()
                    }
                }
                HorizontalDivider()
                DialogCloseRow(onClose = onDismiss)
            }
        }
    }
}

private fun copyText(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}

private fun scopeLabel(scope: String): String = when (scope) {
    "NAME" -> "名前 ▾"
    "TEXT" -> "本文 ▾"
    else -> "名前+本文 ▾"
}

private fun sortLabel(mode: String): String = sortOptions.firstOrNull { it.first == mode }?.second ?: "名前（日本語優先）"
private fun countSuffix(count: Int): String = if (count <= 0) "" else " ($count)"
private fun normalizeColorUi(raw: String): String = "WRBUGC".filter { it in raw.uppercase() }
private fun Double.cleanNumber(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()
