package jp.deckloom.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit, onHowTo: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val indexStatus by vm.cardIndexStatus.collectAsState()
    val packProgress by vm.imagePackProgress.collectAsState()
    val mediumProgress by vm.mediumImagePackProgress.collectAsState()
    var cacheBytes by remember { mutableLongStateOf(0L) }
    var packBytes by remember { mutableLongStateOf(0L) }
    var packCount by remember { mutableIntStateOf(0) }
    var mediumBytes by remember { mutableLongStateOf(0L) }
    var mediumCount by remember { mutableIntStateOf(0) }
    var confirmPackClear by remember { mutableStateOf(false) }
    var confirmMediumClear by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmMeteredUpdate by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit, packProgress.state, mediumProgress.state) { cacheBytes = vm.imageCacheBytes(); packBytes = vm.imagePackBytes(); packCount = vm.imagePackImageCount(); mediumBytes = vm.mediumImagePackBytes(); mediumCount = vm.mediumImagePackImageCount() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("設定") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "戻る") } },
            )
        },
        snackbarHost = {
            message?.let { text ->
                LaunchedEffect(text) { kotlinx.coroutines.delay(2600); message = null }
                Snackbar { Text(text) }
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Text("表示", style = MaterialTheme.typography.titleMedium)
            Column {
                listOf("SYSTEM" to "端末設定に従う", "LIGHT" to "ライト", "DARK" to "ダーク").forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setThemeMode(value) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = settings.themeMode == value, onClick = { vm.setThemeMode(value) })
                        Text(label)
                    }
                }
            }

            Text("カード検索を開いた時の表示", style = MaterialTheme.typography.titleSmall)
            listOf("LAST" to "前回の表示を使う", "LIST" to "リスト", "GRID" to "画像グリッド").forEach { (value, label) ->
                Row(Modifier.fillMaxWidth().clickable { vm.setSearchDisplayMode(value) }, verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = settings.searchDisplayMode == value, onClick = { vm.setSearchDisplayMode(value) })
                    Text(label)
                }
            }

            HorizontalDivider()
            Text("カード検索DB", style = MaterialTheme.typography.titleMedium)
            Text(indexStatus.message, style = MaterialTheme.typography.bodyMedium)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("従量制通信ではDBを自動ダウンロードしない")
                    Text("最新版の確認自体は軽量なmanifestのみ取得します。", style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = settings.blockMeteredCardDbDownload,
                    onCheckedChange = vm::setBlockMeteredCardDbDownload,
                )
            }
            Button(
                onClick = {
                    if (vm.isActiveNetworkMetered()) confirmMeteredUpdate = true
                    else { vm.refreshSearchCatalog(); message = "最新版を確認します" }
                },
                enabled = !indexStatus.checking && !indexStatus.updating,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (indexStatus.updating) "更新中…" else "DB最新版を確認・更新") }

            HorizontalDivider()
            Text("画像の事前ダウンロード", style = MaterialTheme.typography.titleMedium)
            Text("未導入でも必要な画像はオンデマンド取得できます。事前パックは通信待ちを減らすための任意機能です。", style = MaterialTheme.typography.bodySmall)
            listOf(
                "NONE" to "なし（必要な画像だけ取得）",
                "SMALL" to "small / 軽量（サムネ中心・約485MB）",
                "MEDIUM" to "Medium / 標準（400px WebP・カード閲覧向け）",
            ).forEach { (value, label) ->
                Row(Modifier.fillMaxWidth().clickable { vm.setImagePreloadMode(value) }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = settings.imagePreloadMode == value, onClick = { vm.setImagePreloadMode(value) })
                    Text(label)
                }
            }
            when (settings.imagePreloadMode) {
                "SMALL" -> {
                    Text(if (vm.imagePackInstalled()) "small導入済み ${packCount}枚 / ${formatBytes(packBytes)}" else "smallは未導入です")
                    if (packProgress.active) { LinearProgressIndicator(progress = { packProgress.fraction }, color = androidx.compose.ui.graphics.Color(0xFF7E57C2), modifier = Modifier.fillMaxWidth()); Text(packProgress.message, style = MaterialTheme.typography.bodySmall) }
                    Button(onClick = { vm.downloadImagePack(onDone = { message = "small画像パックを導入/更新しました" }, onError = { message = it }) }, enabled = !packProgress.active, modifier = Modifier.fillMaxWidth()) { Text(if (vm.imagePackInstalled()) "smallを更新" else "smallをダウンロード") }
                    if (vm.imagePackInstalled()) TextButton(onClick = { confirmPackClear = true }, enabled = !packProgress.active, modifier = Modifier.fillMaxWidth()) { Text("smallを削除") }
                }
                "MEDIUM" -> {
                    Text(if (vm.mediumImagePackInstalled()) "Medium導入済み ${mediumCount}枚 / ${formatBytes(mediumBytes)}" else "Mediumは未導入です")
                    vm.mediumImagePackUpdatedAt().takeIf { it.isNotBlank() }?.let { Text("データ更新: $it", style = MaterialTheme.typography.bodySmall) }
                    if (mediumProgress.active) { LinearProgressIndicator(progress = { mediumProgress.fraction }, color = androidx.compose.ui.graphics.Color(0xFF7E57C2), modifier = Modifier.fillMaxWidth()); Text(mediumProgress.message, style = MaterialTheme.typography.bodySmall) }
                    Button(onClick = { vm.downloadMediumImagePack(onDone = { message = "Medium画像パックを導入/更新しました" }, onError = { message = it }) }, enabled = !mediumProgress.active, modifier = Modifier.fillMaxWidth()) { Text(if (vm.mediumImagePackInstalled()) "Mediumを更新" else "Mediumをダウンロード") }
                    if (vm.mediumImagePackInstalled()) TextButton(onClick = { confirmMediumClear = true }, enabled = !mediumProgress.active, modifier = Modifier.fillMaxWidth()) { Text("Mediumを削除") }
                }
                else -> Text("事前ダウンロードは行いません。small / Mediumが端末に残っていても自動更新・優先表示には使いません。", style = MaterialTheme.typography.bodySmall)
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 8.dp)) {
                    Text("Mediumがあるカードもnormalを自動取得")
                    Text("オフならMediumのまま表示します。Mediumがないカードの画像と、版を指定した画像は引き続き取得します。取得済みのnormalは利用します。", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = settings.normalOverMedium, onCheckedChange = vm::setNormalOverMedium)
            }

            HorizontalDivider()
            Text("通常画像キャッシュ", style = MaterialTheme.typography.titleMedium)
            Text("使用容量 ${formatBytes(cacheBytes)}")
            OutlinedButton(onClick = { confirmClear = true }, enabled = cacheBytes > 0L, modifier = Modifier.fillMaxWidth()) {
                Text("画像キャッシュを削除")
            }
            Text("デッキ、設定、カード検索DBは削除されません。必要な画像は再取得されます。", style = MaterialTheme.typography.bodySmall)

            HorizontalDivider()
            Text("ヘルプ", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = onHowTo, modifier = Modifier.fillMaxWidth()) { Text("DeckLoom README") }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        DeckLoomAlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("画像キャッシュを削除") },
            text = { Text("${formatBytes(cacheBytes)} の画像キャッシュを削除します。必要な画像は後から再取得されます。") },
            confirmButton = {
                Button(onClick = {
                    confirmClear = false
                    vm.clearImageCache { removed -> cacheBytes = 0L; message = "${formatBytes(removed)} を削除しました" }
                }) { Text("削除") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("キャンセル") } },
        )
    }

    if (confirmPackClear) {
        DeckLoomAlertDialog(
            onDismissRequest = { confirmPackClear = false },
            title = { Text("軽量画像パックを削除") },
            text = { Text("${formatBytes(packBytes)} の軽量画像パックを削除します。デッキと通常画像キャッシュは削除されません。") },
            confirmButton = { Button(onClick = { confirmPackClear = false; vm.clearImagePack { removed -> packBytes = 0L; packCount = 0; message = "${formatBytes(removed)} を削除しました" } }) { Text("削除") } },
            dismissButton = { TextButton(onClick = { confirmPackClear = false }) { Text("キャンセル") } },
        )
    }

    if (confirmMediumClear) {
        DeckLoomAlertDialog(
            onDismissRequest = { confirmMediumClear = false },
            title = { Text("Medium画像パックを削除") },
            text = { Text("${formatBytes(mediumBytes)} のMedium画像パックを削除します。デッキと通常画像キャッシュは削除されません。") },
            confirmButton = { Button(onClick = { confirmMediumClear = false; vm.clearMediumImagePack { removed -> mediumBytes = 0L; mediumCount = 0; message = "${formatBytes(removed)} を削除しました" } }) { Text("削除") } },
            dismissButton = { TextButton(onClick = { confirmMediumClear = false }) { Text("キャンセル") } },
        )
    }

    if (confirmMeteredUpdate) {
        DeckLoomAlertDialog(
            onDismissRequest = { confirmMeteredUpdate = false },
            title = { Text("従量制通信で更新") },
            text = { Text("更新がある場合、カード検索DBをダウンロードします。現在の通信は従量制として認識されています。続行しますか？") },
            confirmButton = {
                Button(onClick = { confirmMeteredUpdate = false; vm.refreshSearchCatalog(); message = "最新版を確認します" }) { Text("続行") }
            },
            dismissButton = { TextButton(onClick = { confirmMeteredUpdate = false }) { Text("キャンセル") } },
        )
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return "${(kb * 10).roundToInt() / 10.0} KB"
    val mb = kb / 1024.0
    if (mb < 1024.0) return "${(mb * 10).roundToInt() / 10.0} MB"
    val gb = mb / 1024.0
    return "${(gb * 100).roundToInt() / 100.0} GB"
}
