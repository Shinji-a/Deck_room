package jp.deckloom.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import jp.deckloom.app.data.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: AppViewModel, onImport: () -> Unit, onDeck: (Long) -> Unit, onSearch: () -> Unit, onSettings: () -> Unit) {
    val decks by vm.decks.collectAsState()
    val entries by vm.homeDecks.collectAsState()
    val folders by vm.folders.collectAsState()
    val status by vm.cardIndexStatus.collectAsState()
    var currentId by rememberSaveable { mutableLongStateOf(0L) }
    val parentId = currentId.takeIf { it != 0L }
    val current = folders.firstOrNull { it.id == parentId }
    val children = folders.filter { it.parentId == parentId }
    val shown = entries.filter { it.deck.folderId == parentId }
    val listState = rememberLazyListState()
    var createDialog by remember { mutableStateOf(false) }
    var createFolder by remember { mutableStateOf(false) }
    var editFolder by remember { mutableStateOf<DeckFolderEntity?>(null) }
    var actionFolder by remember { mutableStateOf<DeckFolderEntity?>(null) }
    var deletingFolder by remember { mutableStateOf<DeckFolderEntity?>(null) }
    var movingFolder by remember { mutableStateOf<DeckFolderEntity?>(null) }
    var folderList by remember { mutableStateOf(false) }
    var homeMenu by remember { mutableStateOf(false) }
    var deckMenu by remember { mutableStateOf<Long?>(null) }
    var deletingDeck by remember { mutableStateOf<DeckEntity?>(null) }
    var organize by remember { mutableStateOf<DeckEntity?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    fun up() { currentId = current?.parentId ?: 0L }
    BackHandler(enabled = currentId != 0L) { up() }
    var previousFolder by rememberSaveable { mutableLongStateOf(currentId) }
    LaunchedEffect(currentId) {
        if (previousFolder != currentId) { listState.scrollToItem(0); previousFolder = currentId }
    }

    Scaffold(
        topBar = { TopAppBar(
            title = { Text(current?.name ?: "DeckLoom", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable { folderList = true }) },
            navigationIcon = { if (currentId != 0L) IconButton(onClick = { up() }) { Icon(Icons.Default.ArrowBack, "親フォルダへ") } },
            actions = {
                IconButton(onClick = onSearch) { Icon(Icons.Default.Search, "カード検索") }
                IconButton(onClick = { createFolder = true }) { Icon(Icons.Default.CreateNewFolder, "ここにフォルダを作成") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "設定") }
                Box {
                    IconButton(onClick = { homeMenu = true }) { Icon(Icons.Default.MoreVert, "フォルダとデッキの管理") }
                    DropdownMenu(homeMenu, { homeMenu = false }) {
                        DropdownMenuItem(text = { Text("フォルダ一覧・検索") }, onClick = { homeMenu = false; folderList = true })
                        if (current != null) DropdownMenuItem(text = { Text("このフォルダを管理") }, onClick = { homeMenu = false; actionFolder = current })
                        DropdownMenuItem(text = { Text("一括インポート") }, onClick = { homeMenu = false; onImport() })
                    }
                }
            },
        ) },
        bottomBar = {
            Surface(tonalElevation = 2.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Icon(Icons.Default.FileDownload, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("インポート", maxLines = 2)
                    }
                    Button(onClick = { createDialog = true }, modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 48.dp), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("デッキを作成", maxLines = 2)
                    }
                }
            }
        },
        snackbarHost = { message?.let { text -> LaunchedEffect(text) { kotlinx.coroutines.delay(2800); message = null }; Snackbar { Text(text) } } },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp), contentPadding = PaddingValues(12.dp, 4.dp, 4.dp, 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!status.ready || status.updating) item("db-status") { Text(status.message, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 4.dp)) }
                item("folder-path") {
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { folderList = true }.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.FolderOpen, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(FolderTree.path(parentId, folders), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, "階層を選択", Modifier.size(18.dp))
                    }
                }
                if (children.isNotEmpty()) item("folders-$currentId") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        LazyRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end = 16.dp)) {
                            items(children, key = { it.id }) { folder ->
                                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.widthIn(max = 172.dp).combinedClickable(onClick = { currentId = folder.id }, onLongClick = { actionFolder = folder })) {
                                    Row(Modifier.heightIn(min = 48.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                        Icon(Icons.Default.Folder, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                                        Text(folder.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f, fill = false))
                                        Text(decks.count { it.folderId == folder.id }.toString(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                        IconButton(onClick = { folderList = true }) { Icon(Icons.Default.FolderOpen, "フォルダ一覧・階層検索") }
                    }
                }
                item("deck-count") {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${current?.name ?: "最上位"}のデッキ", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${shown.size}件", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (shown.isEmpty()) item("empty") {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (decks.isEmpty()) "まだデッキがありません" else "このフォルダにデッキはありません")
                        Button(onClick = { createDialog = true }) { Text("ここにデッキを追加") }
                    }
                }
                items(shown, key = { it.deck.id }) { entry ->
                    val deck = entry.deck
                    val commanders = entry.cards.filter { it.deckRole != DeckRoles.CANDIDATE && DeckSpecialRoles.startsInCommandZone(it.specialRole) }.sortedByDescending { it.specialRole == DeckSpecialRoles.COMMANDER }.take(2)
                    val siblings = decks.filter { it.folderId == deck.folderId }
                    val position = siblings.indexOfFirst { it.id == deck.id }
                    OutlinedCard(Modifier.fillMaxWidth().combinedClickable(onClick = { onDeck(deck.id) }, onLongClick = { deckMenu = deck.id }), colors = CardDefaults.outlinedCardColors(containerColor = MaterialTheme.colorScheme.surface), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.width(if (commanders.size > 1) 86.dp else 70.dp).height(100.dp)) {
                                if (commanders.isEmpty()) Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.small) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Style, "統率者未指定") } }
                                commanders.forEachIndexed { index, card ->
                                    val path = card.imagePath.takeIf { it.isNotBlank() && File(it).exists() } ?: vm.deckPreferredImagePath(card)
                                    Box(Modifier.width(70.dp).height(98.dp).offset(x = (index * 16).dp)) {
                                        if (path.isNotBlank()) AsyncImage(model = File(path), contentDescription = CardNames.clean(card.displayName), modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                        else Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surfaceVariant) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Style, "統率者画像なし") } }
                                        Surface(Modifier.align(Alignment.BottomStart).padding(3.dp), color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.small) { Icon(Icons.Default.Star, if (card.specialRole == DeckSpecialRoles.COMMANDER) "統率者" else "相棒 / 背景", Modifier.padding(3.dp).size(14.dp)) }
                                    }
                                }
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(deck.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (deck.note.isNotBlank()) Text(deck.note, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val colors = "WUBRG".filter { color -> commanders.any { color in it.colorIdentity } }
                                if (colors.isNotBlank()) ManaText(colors.map { "{$it}" }.joinToString(""), style = MaterialTheme.typography.labelSmall)
                                Text("${entry.cards.filter { DeckRoles.countsTowardDeck(it.deckRole) }.sumOf { it.quantity }}/100枚 · 候補 ${entry.cards.filter { it.deckRole == DeckRoles.CANDIDATE }.sumOf { it.quantity }}枚", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box {
                                IconButton(onClick = { deckMenu = deck.id }) { Icon(Icons.Default.MoreVert, "デッキメニュー") }
                                DropdownMenu(deckMenu == deck.id, { deckMenu = null }) {
                                    DropdownMenuItem(text = { Text("移動・一口メモ") }, onClick = { deckMenu = null; organize = deck })
                                    DropdownMenuItem(text = { Text("上へ") }, enabled = position > 0, onClick = { deckMenu = null; vm.reorderDeck(deck.id, -1) { message = it } })
                                    DropdownMenuItem(text = { Text("下へ") }, enabled = position >= 0 && position < siblings.lastIndex, onClick = { deckMenu = null; vm.reorderDeck(deck.id, 1) { message = it } })
                                    DropdownMenuItem(text = { Text("コピー") }, onClick = { deckMenu = null; vm.copyDeck(deck.id, onDone = { message = "コピーしました" }, onError = { message = it }) })
                                    DropdownMenuItem(text = { Text("削除", color = MaterialTheme.colorScheme.error) }, onClick = { deckMenu = null; deletingDeck = deck })
                                }
                            }
                        }
                    }
                }
            }
            VerticalFastScrollbar(listState)
        }
    }
    if (folderList) FolderPickerDialog(folders, parentId, "フォルダ一覧", onDismiss = { folderList = false }, onSelect = { currentId = it ?: 0L; folderList = false })
    actionFolder?.let { folder ->
        val siblings = folders.filter { it.parentId == folder.parentId }
        val index = siblings.indexOfFirst { it.id == folder.id }
        DeckLoomAlertDialog(onDismissRequest = { actionFolder = null }, title = { Text(folder.name) }, text = {
            Column {
                Text(FolderTree.path(folder.parentId, folders), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { editFolder = folder; actionFolder = null }) { Text("名前を変更") }
                TextButton(onClick = { movingFolder = folder; actionFolder = null }) { Text("別のフォルダへ移動") }
                Row {
                    TextButton(enabled = index > 0, onClick = { vm.reorderFolder(folder.id, -1) { message = it }; actionFolder = null }) { Text("左へ") }
                    TextButton(enabled = index >= 0 && index < siblings.lastIndex, onClick = { vm.reorderFolder(folder.id, 1) { message = it }; actionFolder = null }) { Text("右へ") }
                }
                TextButton(onClick = { deletingFolder = folder; actionFolder = null }) { Text("フォルダを削除", color = MaterialTheme.colorScheme.error) }
            }
        }, confirmButton = { TextButton(onClick = { actionFolder = null }) { Text("閉じる") } })
    }
    movingFolder?.let { folder -> FolderPickerDialog(folders, folder.parentId, "フォルダの移動先", movingFolderId = folder.id, onDismiss = { movingFolder = null }, onSelect = { id -> vm.moveFolder(folder.id, id, onDone = { movingFolder = null; message = "移動しました" }, onError = { message = it }) }) }
    if (createFolder || editFolder != null) {
        var name by remember(editFolder?.id) { mutableStateOf(editFolder?.name.orEmpty()) }
        var saving by remember { mutableStateOf(false) }
        DeckLoomAlertDialog(onDismissRequest = { if (!saving) { createFolder = false; editFolder = null } }, title = { Text(if (editFolder == null) "フォルダ作成" else "フォルダ名を変更") }, text = { Column {
            Text(FolderTree.path(if (editFolder == null) parentId else editFolder?.parentId, folders), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(name, { name = it }, label = { Text("フォルダ名") }, singleLine = true)
        } }, confirmButton = { Button(enabled = name.isNotBlank() && !saving, onClick = {
            saving = true
            val done = { createFolder = false; editFolder = null; saving = false }
            val error: (String) -> Unit = { saving = false; message = it }
            val editing = editFolder
            if (editing == null) vm.createFolder(name, done, error, parentId) else vm.renameFolder(editing.id, name, done, error)
        }) { Text("保存") } }, dismissButton = { TextButton(enabled = !saving, onClick = { createFolder = false; editFolder = null }) { Text("閉じる") } })
    }
    deletingFolder?.let { folder -> DeckLoomAlertDialog(onDismissRequest = { deletingFolder = null }, title = { Text("フォルダを削除") }, text = { Text("「${folder.name}」のデッキと子フォルダは「${FolderTree.path(folder.parentId, folders)}」へ移動します。デッキ自体は残ります。") }, confirmButton = {
        TextButton(onClick = { vm.deleteFolder(folder.id, onDone = { if (currentId == folder.id) currentId = folder.parentId ?: 0L; deletingFolder = null }, onError = { message = it }) }) { Text("削除") }
    }, dismissButton = { TextButton(onClick = { deletingFolder = null }) { Text("閉じる") } }) }
    organize?.let { deck ->
        var note by remember(deck.id) { mutableStateOf(deck.note) }
        var target by remember(deck.id) { mutableStateOf(deck.folderId) }
        var picker by remember { mutableStateOf(false) }
        DeckLoomAlertDialog(onDismissRequest = { organize = null }, title = { Text("移動・一口メモ") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(deck.name)
            OutlinedButton(onClick = { picker = true }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text(FolderTree.path(target, folders)) }
            OutlinedTextField(note, { note = it.take(200) }, label = { Text("一口メモ（任意）") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        } }, confirmButton = { Button(onClick = { vm.organizeDeck(deck.id, target, note, onDone = { organize = null }, onError = { message = it }) }) { Text("保存") } }, dismissButton = { TextButton(onClick = { organize = null }) { Text("閉じる") } })
        if (picker) FolderPickerDialog(folders, target, "デッキの移動先", onDismiss = { picker = false }, onSelect = { target = it; picker = false })
    }
    if (createDialog) CreateDeckDialog(vm, onDismiss = { createDialog = false }, onBulk = { createDialog = false; onImport() }, onCreate = { name, firstCard, commander ->
        vm.createDeck(name, firstCard, commander, onCreated = { id ->
            if (parentId != null) vm.organizeDeck(id, parentId, "", onDone = { createDialog = false; onDeck(id) }, onError = { message = it; createDialog = false })
            else { createDialog = false; onDeck(id) }
        }, onError = { message = it })
    })
    deletingDeck?.let { deck -> DeckLoomAlertDialog(onDismissRequest = { deletingDeck = null }, title = { Text("デッキを削除") }, text = { Text("「${deck.name}」を削除します。この操作は元に戻せません。") }, confirmButton = { Button(onClick = { vm.deleteDeck(deck.id, onDone = { deletingDeck = null }, onError = { message = it }) }) { Text("削除") } }, dismissButton = { TextButton(onClick = { deletingDeck = null }) { Text("キャンセル") } }) }
}

@Composable
private fun FolderPickerDialog(
    folders: List<DeckFolderEntity>, selectedId: Long?, title: String,
    onDismiss: () -> Unit, onSelect: (Long?) -> Unit, movingFolderId: Long? = null,
) {
    var query by remember { mutableStateOf("") }
    val paths = folders.filter { movingFolderId == null || FolderTree.canMove(movingFolderId, it.id, folders) }
        .map { it.id to FolderTree.path(it.id, folders) }.sortedBy { it.second }
    val options = (listOf(null to "デッキ（最上位）") + paths).filter { query.isBlank() || it.second.contains(query, ignoreCase = true) }
    DeckLoomAlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = {
        Column {
            OutlinedTextField(query, { query = it }, singleLine = true, placeholder = { Text("フォルダ名・階層を検索") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth())
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                items(options, key = { it.first ?: 0L }) { (id, path) ->
                    ListItem(headlineContent = { Text(path) }, leadingContent = { Icon(Icons.Default.Folder, null) }, trailingContent = { if (selectedId == id) Icon(Icons.Default.Check, "現在のフォルダ") }, modifier = Modifier.clickable { onSelect(id) })
                }
                if (options.isEmpty()) item { Text("該当するフォルダはありません", Modifier.padding(12.dp)) }
            }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("閉じる") } })
}

@Composable
private fun CreateDeckDialog(
    vm: AppViewModel,
    onDismiss: () -> Unit,
    onBulk: () -> Unit,
    onCreate: (name: String, firstCard: String?, commander: Boolean) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var cardName by remember { mutableStateOf("") }
    var commander by remember { mutableStateOf(false) }

    DeckLoomAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("デッキ追加") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("デッキ名") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("最初の1枚は任意。入力するとローカルカード名DBから候補を出します。", style = MaterialTheme.typography.bodySmall)
                CardNameSearchField(
                    vm = vm,
                    value = cardName,
                    onValueChange = { cardName = it },
                    label = "最初のカード（任意）",
                    onChosen = { cardName = it.displayName },
                )
                if (cardName.isNotBlank()) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(checked = commander, onCheckedChange = { commander = it })
                        Text("統率者として追加")
                    }
                }
                TextButton(onClick = onBulk, modifier = Modifier.fillMaxWidth()) { Text("100枚を一括インポート →") }
            }
        },
        confirmButton = {
            Button(onClick = { onCreate(name.ifBlank { "新しいデッキ" }, cardName.ifBlank { null }, commander) }) {
                Text("作成")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("キャンセル") } },
    )
}
