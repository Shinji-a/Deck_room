package jp.deckloom.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** One receipt for the latest operation. Scaffold positions it above the fixed bottom bar. */
@Composable
fun OperationNoticeHost(vm: AppViewModel, visible: Boolean = true) {
    val notice by vm.editNotice.collectAsState()
    LaunchedEffect(notice?.id, visible) {
        val item = notice
        if (visible && item != null) {
            delay(if (item.undo != null) 8_000 else 4_000)
            vm.dismissEditNotice(item.id)
        }
    }
    if (visible) notice?.let { item ->
        Snackbar(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                .semantics { liveRegion = LiveRegionMode.Polite },
            action = {
                if (item.undo != null) TextButton(onClick = { vm.undoEdit(item.id) }) {
                    Text("元に戻す", color = MaterialTheme.colorScheme.inversePrimary)
                }
            },
            dismissAction = {
                IconButton(onClick = { vm.dismissEditNotice(item.id) }) {
                    Icon(Icons.Default.Close, "通知を閉じる")
                }
            },
        ) {
            Text(item.message, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}
