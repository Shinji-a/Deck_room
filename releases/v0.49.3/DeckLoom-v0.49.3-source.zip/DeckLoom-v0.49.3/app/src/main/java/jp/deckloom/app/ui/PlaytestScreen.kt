package jp.deckloom.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.BackHandler
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import coil3.compose.AsyncImage
import jp.deckloom.app.data.TokenCandidate
import jp.deckloom.app.playtest.PlayCard
import jp.deckloom.app.playtest.Zone
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

private data class DragVisual(val card: PlayCard, val position: Offset)
private data class DropSpec(val zone: Zone, val toBottom: Boolean = false)

private const val BOARD_CARD_W = 82f
private const val BOARD_CARD_H = 116f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaytestScreen(vm: AppViewModel, deckId: Long, onBack: () -> Unit) {
    val session = remember(deckId) { vm.playtest(deckId) }
    val state by session.state.collectAsState()
    val history by session.history.collectAsState()
    LaunchedEffect(deckId) { vm.ensurePlaytest(deckId) }

    var selected by remember { mutableStateOf<PlayCard?>(null) }
    var tokenDialog by remember { mutableStateOf(false) }
    var tokenCandidates by remember { mutableStateOf<List<TokenCandidate>>(emptyList()) }
    var topDialog by remember { mutableStateOf(false) }
    var browserZone by remember { mutableStateOf<Zone?>(null) }
    var menuExpanded by remember { mutableStateOf(false) }
    var handMenuExpanded by remember { mutableStateOf(false) }
    var browserDragging by remember { mutableStateOf(false) }
    var cancelRect by remember { mutableStateOf(Rect.Zero) }
    var viewMenu by remember { mutableStateOf(false) }
    var lifeDialog by remember { mutableStateOf(false) }
    var newGameDialog by remember { mutableStateOf(false) }
    var drag by remember { mutableStateOf<DragVisual?>(null) }
    val dropRects = remember { mutableStateMapOf<String, Rect>() }
    val density = LocalDensity.current

    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var panMode by remember { mutableStateOf(false) }
    var battlefieldRect by remember { mutableStateOf(Rect.Zero) }
    var handDropIndex by remember { mutableIntStateOf(0) }
    var handWindowStart by remember { mutableIntStateOf(0) }

    LaunchedEffect(tokenDialog) {
        if (tokenDialog) tokenCandidates = vm.tokenCandidates(deckId)
    }
    LaunchedEffect(state.zone(Zone.HAND).size) {
        val maxStart = (state.zone(Zone.HAND).size - 8).coerceAtLeast(0)
        handWindowStart = handWindowStart.coerceIn(0, maxStart)
    }
    LaunchedEffect(state.zone(Zone.HAND).firstOrNull()?.uid) {
        // Draws and moves to hand become the newest (leftmost) card and should be visible immediately.
        handWindowStart = 0
    }

    fun fitBattlefield() {
        val cards = state.zone(Zone.BATTLEFIELD)
        if (battlefieldRect.width <= 0f || battlefieldRect.height <= 0f || cards.isEmpty()) {
            zoom = 1f; panX = 0f; panY = 0f; return
        }
        val minX = cards.minOf { it.boardX }
        val minY = cards.minOf { it.boardY }
        val maxX = cards.maxOf { it.boardX + BOARD_CARD_W }
        val maxY = cards.maxOf { it.boardY + BOARD_CARD_H }
        val contentW = (maxX - minX + 40f).coerceAtLeast(BOARD_CARD_W)
        val contentH = (maxY - minY + 40f).coerceAtLeast(BOARD_CARD_H)
        val viewW = battlefieldRect.width / density.density
        val viewH = battlefieldRect.height / density.density
        val nextZoom = min(viewW / contentW, viewH / contentH).coerceIn(0.35f, 2.0f)
        zoom = nextZoom
        val visibleW = viewW / nextZoom
        val visibleH = viewH / nextZoom
        panX = minX - 20f - ((visibleW - contentW) / 2f).coerceAtLeast(0f)
        panY = minY - 20f - ((visibleH - contentH) / 2f).coerceAtLeast(0f)
    }

    fun finishMainDrag() {
        val dragging = drag ?: return
        val target = PlaytestDropTargets.resolve(dragging.position, dropRects, if (browserDragging) cancelRect else null)
        val spec = target?.let { DropSpec(it, it == Zone.LIBRARY && state.mulliganBottomPending > 0 && dragging.card.zone == Zone.HAND) }
        if (spec != null) {
            when {
                spec.zone == Zone.HAND && dragging.card.zone == Zone.HAND -> session.reorderHand(dragging.card.uid, handDropIndex)
                spec.zone == Zone.BATTLEFIELD -> {
                    val rect = battlefieldRect
                    val boardX = panX + (dragging.position.x - rect.left) / (zoom * density.density) - BOARD_CARD_W / 2f
                    val boardY = panY + (dragging.position.y - rect.top) / (zoom * density.density) - BOARD_CARD_H + 14f
                    if (dragging.card.zone == Zone.BATTLEFIELD) session.positionOnBattlefield(dragging.card.uid, boardX, boardY)
                    else session.move(dragging.card.uid, Zone.BATTLEFIELD, boardX = boardX, boardY = boardY)
                }
                else -> session.move(dragging.card.uid, spec.zone, spec.toBottom)
            }
        }
        drag = null
        browserDragging = false
    }

    @Composable
    fun PlayMenu(expanded: Boolean, close: () -> Unit) {
        DropdownMenu(expanded, close) {
            MenuAction("1枚ドロー") { session.draw(); close() }
            MenuAction("シャッフル") { session.shuffleLibrary(); close() }
            MenuAction("山上5枚を見る") { topDialog = true; close() }
            MenuAction("1枚切削") { session.mill(1); close() }
            MenuAction("トークン") { tokenDialog = true; close() }
            MenuAction("マリガン") { session.mulligan(); close() }
            HorizontalDivider()
            MenuAction("新しいゲーム") { newGameDialog = true; close() }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        BoxWithConstraints {
                            val compactTitle = maxWidth < (120 * density.fontScale).dp
                            Row(Modifier.widthIn(max = (140 * density.fontScale).dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(if (compactTitle) 2.dp else 10.dp)) {
                                Column(Modifier.weight(1f)) {
                                    if (!compactTitle) Text("ターン", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(if (compactTitle) "T${state.turn}" else state.turn.toString(),
                                        style = if (compactTitle) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Row(Modifier.heightIn(min = 48.dp).widthIn(min = 48.dp).clickable { lifeDialog = true }, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        if (!compactTitle) Text("ライフ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(state.life.toString(), style = if (compactTitle) MaterialTheme.typography.titleSmall else MaterialTheme.typography.titleMedium, maxLines = 1)
                                    }
                                    Icon(Icons.Default.ArrowDropDown, "ライフ ${state.life} を変更", Modifier.size(if (compactTitle) 14.dp else 18.dp))
                                }
                            }
                        }
                    },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "デッキへ戻る") } },
                    actions = {
                        IconButton(onClick = { session.undo() }, enabled = history.first) { Icon(Icons.Default.Undo, "元に戻す") }
                        IconButton(onClick = { session.redo() }, enabled = history.second) { Icon(Icons.Default.Redo, "やり直す") }
                        Box {
                            IconButton(onClick = { viewMenu = true }) { Icon(Icons.Default.ZoomIn, "表示・拡大縮小") }
                            DropdownMenu(viewMenu, { viewMenu = false }) {
                                MenuAction("拡大 ＋  (${(zoom * 100).roundToInt()}%)") { zoom = (zoom + 0.05f).coerceAtMost(2.0f) }
                                MenuAction("縮小 −  (${(zoom * 100).roundToInt()}%)") { zoom = (zoom - 0.05f).coerceAtLeast(0.35f) }
                                MenuAction("100%に戻す") { zoom = 1f; panX = 0f; panY = 0f }
                                MenuAction("戦場に合わせる") { fitBattlefield(); viewMenu = false }
                                MenuAction(if (panMode) "✓ 戦場を移動する" else "戦場を移動する") { panMode = !panMode }
                            }
                        }
                        Box {
                            IconButton(onClick = { menuExpanded = true }) { Icon(Icons.Default.MoreVert, "一人回しメニュー") }
                            PlayMenu(menuExpanded) { menuExpanded = false }
                        }
                    },
                )
            },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (state.mulliganBottomPending > 0) {
                    Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                        Text("マリガン処理: 手札から山下へ ${state.mulliganBottomPending} 枚", modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.labelMedium)
                    }
                }

                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val sideBySide = maxHeight < 620.dp && maxWidth >= 760.dp
                    val compactHand = maxHeight < 440.dp

                    @Composable
                    fun Board(modifier: Modifier) {
                        BattlefieldCanvas(
                            cards = state.zone(Zone.BATTLEFIELD), zoom = zoom, panX = panX, panY = panY, panMode = panMode,
                            draggingUid = drag?.card?.uid,
                            onRect = { battlefieldRect = it; dropRects["battlefield"] = it },
                            onPan = { dxPx, dyPx -> panX -= dxPx / (zoom * density.density); panY -= dyPx / (zoom * density.density) },
                            onTap = { session.toggleTap(it.uid) }, onLongPress = { selected = it },
                            onDragStart = { card, pos -> drag = DragVisual(card, pos) },
                            onDrag = { delta -> drag = drag?.copy(position = drag!!.position + delta) }, onDragEnd = { finishMainDrag() }, onDragCancel = { drag = null },
                            modifier = modifier,
                        )
                    }

                    @Composable
                    fun HandAndZones(modifier: Modifier) {
                        Column(modifier) {
                            val handHovered = drag?.position?.let { dropRects["hand"]?.contains(it) == true } == true
                            HorizontalDivider(thickness = if (handHovered) 4.dp else 2.dp, color = if (handHovered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                            HandStrip(
                                compact = compactHand,
                                cards = state.zone(Zone.HAND), windowStart = handWindowStart,
                                dragPosition = drag?.position,
                                onRect = { dropRects["hand"] = it }, onDropIndex = { handDropIndex = it },
                                onOpenList = { browserZone = Zone.HAND },
                                onOpenMenu = { handMenuExpanded = true },
                                menuContent = { PlayMenu(handMenuExpanded) { handMenuExpanded = false } },
                                onNextTurn = { session.nextTurn() },
                                onWindowStartChange = { handWindowStart = it.coerceIn(0, (state.zone(Zone.HAND).size - 8).coerceAtLeast(0)) },
                                onTap = { selected = it }, onLongPress = { selected = it },
                                onDragStart = { card, pos -> drag = DragVisual(card, pos) },
                                onDrag = { delta -> drag = drag?.copy(position = drag!!.position + delta) }, onDragEnd = { finishMainDrag() }, onDragCancel = { drag = null },
                            )
                            BottomZones(
                                state = state, dragPosition = drag?.position, dropRects = dropRects,
                                onOpen = { browserZone = it },
                                onDragTop = { card, pos -> drag = DragVisual(card, pos) },
                                onDrag = { delta -> drag = drag?.copy(position = drag!!.position + delta) }, onDragEnd = { finishMainDrag() }, onDragCancel = { drag = null },
                            )
                        }
                    }

                    if (sideBySide) {
                        Row(Modifier.fillMaxSize()) {
                            Board(Modifier.weight(1f).fillMaxHeight().padding(4.dp, 2.dp))
                            VerticalDivider()
                            HandAndZones(Modifier.widthIn(min = 340.dp, max = 440.dp).fillMaxHeight())
                        }
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            Board(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp))
                            HandAndZones(Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
        browserZone?.let { zone ->
            ZoneBrowserOverlay(
                zone = zone, cards = state.zone(zone), dragging = browserDragging,
                onDismiss = { browserZone = null }, onDetail = { selected = it },
                onDragStart = { card, position -> browserDragging = true; drag = DragVisual(card, position) },
                onDrag = { delta -> drag = drag?.let { it.copy(position = it.position + delta) } },
                onDragEnd = { finishMainDrag() }, onDragCancel = { drag = null; browserDragging = false },
            )
        }
        if (browserDragging) {
            val hovered = drag?.position?.let { cancelRect.contains(it) } == true
            Surface(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 4.dp)
                .zIndex(6000f).onGloballyPositioned { cancelRect = it.boundsInRoot() },
                shape = MaterialTheme.shapes.large,
                color = if (hovered) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.errorContainer) {
                Text("ここに放してキャンセル", modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp))
            }
        }
        drag?.let { DragGhost(it) }
    }

    if (lifeDialog) DeckLoomAlertDialog(
        onDismissRequest = { lifeDialog = false }, title = { Text("ライフ ${state.life}") },
        text = { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf(-5, -1, 1, 5).forEach { amount ->
                FilledTonalButton(onClick = { session.setLife(amount) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(if (amount > 0) "+$amount" else amount.toString()) }
            }
        } },
        confirmButton = { DialogCloseRow(onClose = { lifeDialog = false }) },
    )
    if (newGameDialog) DeckLoomAlertDialog(
        onDismissRequest = { newGameDialog = false }, title = { Text("新しいゲーム") },
        text = { Text("現在の盤面とUndo/Redo履歴を終了して、最初から始めます。") },
        confirmButton = { TextButton(onClick = { vm.newGame(deckId); zoom = 1f; panX = 0f; panY = 0f; panMode = false; newGameDialog = false }) { Text("開始") } },
        dismissButton = { TextButton(onClick = { newGameDialog = false }) { Text("キャンセル") } },
    )

    selected?.let { card ->
        val current = state.cards.firstOrNull { it.uid == card.uid } ?: card
        PlayCardDetailDialog(
            card = current, onDismiss = { selected = null },
            onMove = { zone, bottom -> session.move(current.uid, zone, bottom); selected = null },
            onCounter = { session.counter(current.uid, it) },
            onToggleMarker = { session.toggleMarker(current.uid) },
            onToggleBack = { session.toggleBackFace(current.uid) },
            onToggleFaceDown = { session.toggleFaceDown(current.uid) },
            onCastCommander = { session.castCommander(); selected = null },
            onDeleteToken = { session.deleteToken(current.uid); selected = null },
        )
    }
    if (tokenDialog) TokenDialog(
        vm = vm,
        candidates = tokenCandidates,
        onDismiss = { tokenDialog = false },
        onCreateCustom = { session.createToken(it) },
        onCreateCandidate = { token, cachedPath ->
            val tokenName = token.displayName + if (token.power.isNotBlank() || token.toughness.isNotBlank()) " ${token.power}/${token.toughness}" else ""
            val uid = session.createToken(tokenName, cachedPath)
            if (cachedPath.isBlank() && token.imageUrl.isNotBlank()) {
                vm.loadTokenImage(
                    token,
                    onDone = { path -> session.setTokenImage(uid, path) },
                    onError = { /* The token is already on the battlefield. */ },
                )
            }
        },
    )
    if (topDialog) TopFiveDialog(state.zone(Zone.LIBRARY).take(5), onDismiss = { topDialog = false }, onBottom = { session.move(it.uid, Zone.LIBRARY, toBottom = true) })
}

@Composable
private fun MenuAction(label: String, onClick: () -> Unit) { DropdownMenuItem(text = { Text(label) }, onClick = onClick) }

@Composable
private fun BattlefieldCanvas(
    cards: List<PlayCard>, zoom: Float, panX: Float, panY: Float, panMode: Boolean, draggingUid: Long?,
    onRect: (Rect) -> Unit, onPan: (Float, Float) -> Unit, onTap: (PlayCard) -> Unit, onLongPress: (PlayCard) -> Unit,
    onDragStart: (PlayCard, Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onDragCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val fieldModifier = modifier
        .border(1.dp, if (panMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium)
        .clip(MaterialTheme.shapes.medium).clipToBounds().background(MaterialTheme.colorScheme.surface)
        .onGloballyPositioned { onRect(it.boundsInRoot()) }
        .pointerInput(panMode, zoom) {
            if (panMode) detectDragGestures { change, amount -> change.consume(); onPan(amount.x, amount.y) }
        }
    Box(fieldModifier) {
        Text(if (panMode) "PAN MODE  ${cards.size}枚" else "戦場  ${cards.size}枚", style = MaterialTheme.typography.labelSmall, color = if (panMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.TopStart).padding(6.dp).zIndex(10_000f))
        if (cards.isEmpty()) Text("ここへドラッグ", modifier = Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurfaceVariant)
        cards.sortedBy { it.zIndex }.forEach { card ->
            val xPx = with(density) { ((card.boardX - panX) * zoom).dp.toPx() }
            val yPx = with(density) { ((card.boardY - panY) * zoom).dp.toPx() }
            DraggableCard(
                card = card, width = (BOARD_CARD_W * zoom).dp, height = (BOARD_CARD_H * zoom).dp,
                modifier = Modifier.offset { IntOffset(xPx.roundToInt(), yPx.roundToInt()) }.zIndex(card.zIndex.toFloat()).alpha(if (draggingUid == card.uid) 0.30f else 1f),
                dragEnabled = !panMode, onTap = { onTap(card) }, onLongPress = { onLongPress(card) },
                onDragStart = { onDragStart(card, it) }, onDrag = onDrag, onDragEnd = onDragEnd, onDragCancel = onDragCancel,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HandStrip(
    compact: Boolean,
    cards: List<PlayCard>,
    windowStart: Int,
    dragPosition: Offset?,
    onRect: (Rect) -> Unit,
    onDropIndex: (Int) -> Unit,
    onOpenList: () -> Unit,
    onOpenMenu: () -> Unit,
    menuContent: @Composable () -> Unit,
    onNextTurn: () -> Unit,
    onWindowStartChange: (Int) -> Unit,
    onTap: (PlayCard) -> Unit,
    onLongPress: (PlayCard) -> Unit,
    onDragStart: (PlayCard, Offset) -> Unit,
    onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
) {
    var rect by remember { mutableStateOf(Rect.Zero) }
    val density = LocalDensity.current
    val hover = dragPosition?.let { rect.contains(it) } == true
    val maxStart = (cards.size - 8).coerceAtLeast(0)

    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(if (compact) 120.dp else 152.dp)
            .onGloballyPositioned { rect = it.boundsInRoot(); onRect(rect) }
            .background(if (hover) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val visible = cards.drop(windowStart).take(8)
        val cardW = if (compact) 48.dp else 70.dp
        val cardH = if (compact) 68.dp else 98.dp
        val startPad = 8.dp
        val usable = (maxWidth - startPad * 2 - cardW).coerceAtLeast(1.dp)
        val step = if (visible.size <= 1) cardW else minOf(cardW, usable / (visible.size - 1).toFloat())
        val stepPx = with(density) { step.toPx() }.coerceAtLeast(1f)

        LaunchedEffect(dragPosition, rect, windowStart, cards.size, stepPx) {
            if (dragPosition != null && rect.contains(dragPosition)) {
                val localX = dragPosition.x - rect.left - with(density) { startPad.toPx() }
                val idx = (localX / stepPx).roundToInt() + windowStart
                onDropIndex(idx.coerceIn(0, (cards.size - 1).coerceAtLeast(0)))
            }
        }

        // Newest is always left. Older cards are layered over it very slightly so
        // each following title band remains visible instead of disappearing underneath.
        visible.forEachIndexed { index, card ->
            val rise = (index.coerceAtMost(4) * 1f).dp
            DraggableCard(
                card = card,
                width = cardW,
                height = cardH,
                modifier = Modifier
                    .offset(x = startPad + step * index.toFloat(), y = 4.dp - rise)
                    .zIndex(index.toFloat() + 10f),
                onTap = { onTap(card) },
                onLongPress = { onLongPress(card) },
                onDragStart = { onDragStart(card, it) },
                onDrag = onDrag,
                onDragEnd = onDragEnd,
                onDragCancel = onDragCancel,
            )
        }

        Row(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(48.dp)
                .background(MaterialTheme.colorScheme.surface).padding(horizontal = 4.dp).zIndex(900f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onOpenList, modifier = Modifier.width(48.dp), contentPadding = PaddingValues(0.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("手札", style = MaterialTheme.typography.labelSmall)
                    Text(cards.size.toString(), style = MaterialTheme.typography.labelMedium)
                }
            }
            HandScrollController(windowStart, maxStart, onWindowStartChange, Modifier.weight(1f))
            IconButton(onClick = onNextTurn) { Icon(Icons.Default.SkipNext, "次のターン") }
            Box {
                IconButton(onClick = onOpenMenu) { Icon(Icons.Default.MoreVert, "手元のメニュー") }
                menuContent()
            }
        }

        if (hover) {
            Surface(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp).zIndex(950f),
                color = MaterialTheme.colorScheme.primary,
                shape = MaterialTheme.shapes.small,
                shadowElevation = 12.dp,
            ) {
                Text(
                    "手札へ / 手札内並べ替え",
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun HandScrollController(
    windowStart: Int,
    maxStart: Int,
    onWindowStartChange: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = { onWindowStartChange((windowStart - 1).coerceAtLeast(0)) }, enabled = windowStart > 0) { Icon(Icons.Default.ChevronLeft, "新しい手札へ") }
        Slider(value = windowStart.toFloat(), onValueChange = { onWindowStartChange(it.roundToInt()) },
            valueRange = 0f..maxStart.coerceAtLeast(1).toFloat(), enabled = maxStart > 0,
            modifier = Modifier.weight(1f))
        IconButton(onClick = { onWindowStartChange((windowStart + 1).coerceAtMost(maxStart)) }, enabled = windowStart < maxStart) { Icon(Icons.Default.ChevronRight, "古い手札へ") }
    }
}

@Composable
private fun BottomZones(
    state: jp.deckloom.app.playtest.PlaytestState, dragPosition: Offset?, dropRects: MutableMap<String, Rect>,
    onOpen: (Zone) -> Unit, onDragTop: (PlayCard, Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onDragCancel: () -> Unit,
) {
    Row(Modifier.fillMaxWidth().height(64.dp).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        ZoneTile("デッキ", state.zone(Zone.LIBRARY).size, "library", Zone.LIBRARY, state.latest(Zone.LIBRARY), dragPosition, dropRects, onOpen, onDragTop, onDrag, onDragEnd, onDragCancel, Modifier.weight(1f))
        ZoneTile("統率領域", state.zone(Zone.COMMAND).size, "command", Zone.COMMAND, state.latest(Zone.COMMAND), dragPosition, dropRects, onOpen, onDragTop, onDrag, onDragEnd, onDragCancel, Modifier.weight(1f))
        ZoneTile("墓地", state.zone(Zone.GRAVEYARD).size, "graveyard", Zone.GRAVEYARD, state.latest(Zone.GRAVEYARD), dragPosition, dropRects, onOpen, onDragTop, onDrag, onDragEnd, onDragCancel, Modifier.weight(1f))
        ZoneTile("追放", state.zone(Zone.EXILE).size, "exile", Zone.EXILE, state.latest(Zone.EXILE), dragPosition, dropRects, onOpen, onDragTop, onDrag, onDragEnd, onDragCancel, Modifier.weight(1f))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ZoneTile(
    label: String, count: Int, id: String, zone: Zone, topCard: PlayCard?, dragPosition: Offset?, dropRects: MutableMap<String, Rect>,
    onOpen: (Zone) -> Unit, onDragTop: (PlayCard, Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onDragCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var rect by remember { mutableStateOf(Rect.Zero) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val hovered = dragPosition?.let { rect.contains(it) } == true
    Surface(
        modifier = modifier.fillMaxHeight().zIndex(if (hovered) 800f else 1f)
            .onGloballyPositioned { coords -> rect = coords.boundsInRoot(); origin = rect.topLeft; dropRects[id] = rect }
            .combinedClickable(onClick = { onOpen(zone) })
            .pointerInput(topCard?.uid) {
                if (topCard != null) detectDragGestures(
                    onDragStart = { local -> onDragTop(topCard, origin + local) },
                    onDrag = { change, amount -> change.consume(); onDrag(amount) }, onDragEnd = onDragEnd, onDragCancel = onDragCancel,
                )
            },
        shape = MaterialTheme.shapes.medium,
        color = if (hovered) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        shadowElevation = if (hovered) 16.dp else 0.dp,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (hovered) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(count.toString(), style = MaterialTheme.typography.bodySmall, color = if (hovered) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DraggableCard(
    card: PlayCard, width: androidx.compose.ui.unit.Dp, height: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier, dragEnabled: Boolean = true,
    onTap: () -> Unit, onLongPress: () -> Unit, onDragStart: (Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onDragCancel: () -> Unit,
) {
    var origin by remember(card.uid) { mutableStateOf(Offset.Zero) }
    Box(
        modifier.width(width).height(height)
            .onGloballyPositioned { origin = it.boundsInRoot().topLeft }
            .combinedClickable(onClick = onTap, onLongClick = onLongPress)
            .pointerInput(card.uid, dragEnabled) {
                if (dragEnabled) detectDragGestures(
                    onDragStart = { local -> onDragStart(origin + local) },
                    onDrag = { change, amount -> change.consume(); onDrag(amount) }, onDragEnd = onDragEnd, onDragCancel = onDragCancel,
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        CardFace(card, Modifier.fillMaxSize().rotate(if (card.tapped) 90f else 0f))
        if (card.counters != 0) Badge(Modifier.align(Alignment.TopEnd).zIndex(50f)) { Text(if (card.counters > 0) "+${card.counters}" else card.counters.toString()) }
        if (card.marked) Badge(Modifier.align(Alignment.TopStart).zIndex(50f)) { Text("●") }
    }
}

@Composable
private fun CardFace(card: PlayCard, modifier: Modifier = Modifier, useBack: Boolean = false) {
    val mode = if (useBack) "BACK" else card.faceMode
    if (mode == "FACE_DOWN") {
        Box(modifier.background(MaterialTheme.colorScheme.inverseSurface, MaterialTheme.shapes.small), contentAlignment = Alignment.Center) {
            Text("DeckLoom\nCARD", color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.titleSmall)
        }
        return
    }
    val path = if (mode == "BACK" && card.backImagePath.isNotBlank()) card.backImagePath else card.imagePath
    if (path.isNotBlank()) AsyncImage(model = File(path), contentDescription = card.name, modifier = modifier.clip(MaterialTheme.shapes.small), contentScale = ContentScale.Fit)
    else Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text(card.name, modifier = Modifier.padding(5.dp), style = MaterialTheme.typography.bodySmall, maxLines = 5, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun DragGhost(drag: DragVisual) {
    val density = LocalDensity.current
    val halfW = with(density) { 45.dp.toPx() }
    val h = with(density) { 128.dp.toPx() }
    val fingerGap = with(density) { 14.dp.toPx() }
    Box(Modifier.zIndex(5000f).offset { IntOffset((drag.position.x - halfW).roundToInt(), (drag.position.y - h + fingerGap).roundToInt()) }.width(90.dp).height(128.dp).alpha(0.88f)) {
        CardFace(drag.card, Modifier.fillMaxSize().rotate(if (drag.card.tapped) 90f else 0f))
    }
}

@Composable
private fun PlayCardDetailDialog(card: PlayCard, onDismiss: () -> Unit, onMove: (Zone, Boolean) -> Unit, onCounter: (Int) -> Unit, onToggleMarker: () -> Unit, onToggleBack: () -> Unit, onToggleFaceDown: () -> Unit, onCastCommander: () -> Unit, onDeleteToken: () -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.92f), shape = MaterialTheme.shapes.large, tonalElevation = 6.dp) {
            Column(Modifier.fillMaxSize()) {
                Column(Modifier.padding(18.dp, 12.dp, 18.dp, 4.dp)) {
                    Text(card.name, style = MaterialTheme.typography.titleLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { copyPlaytestText(context, "card name", card.name) }) { Text("名前コピー") }
                        if (card.oracleText.isNotBlank()) TextButton(onClick = { copyPlaytestText(context, "card text", card.oracleText) }) { Text("本文コピー") }
                    }
                }
                val listState = rememberLazyListState()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp), contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { CardFace(card, Modifier.fillMaxWidth().aspectRatio(0.716f)) }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (card.backImagePath.isNotBlank()) OutlinedButton(onClick = onToggleBack, modifier = Modifier.weight(1f)) { Text(if (card.faceMode == "BACK") "表面" else "実カード裏面") }
                                OutlinedButton(onClick = onToggleFaceDown, modifier = Modifier.weight(1f)) { Text(if (card.faceMode == "FACE_DOWN") "表向き" else "裏向き") }
                            }
                        }
                        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { SmallAction("+1") { onCounter(1) }; SmallAction("-1") { onCounter(-1) }; SmallAction(if (card.marked) "●解除" else "●マーカー") { onToggleMarker() } } }
                        if (card.zone == Zone.COMMAND) item { Button(onClick = onCastCommander, modifier = Modifier.fillMaxWidth()) { Text("統率者を唱える") } }
                        item {
                            Text("移動", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(4.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MoveButton("手札", Modifier.weight(1f)) { onMove(Zone.HAND, false) }
                                MoveButton("戦場", Modifier.weight(1f)) { onMove(Zone.BATTLEFIELD, false) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MoveButton("墓地", Modifier.weight(1f)) { onMove(Zone.GRAVEYARD, false) }
                                MoveButton("追放", Modifier.weight(1f)) { onMove(Zone.EXILE, false) }
                                MoveButton("統率", Modifier.weight(1f)) { onMove(Zone.COMMAND, false) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MoveButton("山上", Modifier.weight(1f)) { onMove(Zone.LIBRARY, false) }
                                MoveButton("山下", Modifier.weight(1f)) { onMove(Zone.LIBRARY, true) }
                            }
                        }
                        if (card.oracleText.isNotBlank()) item {
                            HorizontalDivider()
                            Text("カードテキスト", style = MaterialTheme.typography.titleSmall)
                            Text(card.oracleText, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (card.token) item { TextButton(onClick = onDeleteToken) { Text("トークンを消す") } }
                    }
                    VerticalFastScrollbar(listState)
                }
                HorizontalDivider()
                DialogCloseRow(onClose = onDismiss)
            }
        }
    }
}

@Composable private fun SmallAction(text: String, onClick: () -> Unit) { FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp), modifier = Modifier.heightIn(min = 48.dp)) { Text(text) } }
@Composable private fun MoveButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) { OutlinedButton(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(label) } }

@Composable
private fun TokenDialog(
    vm: AppViewModel,
    candidates: List<TokenCandidate>,
    onDismiss: () -> Unit,
    onCreateCustom: (String) -> Unit,
    onCreateCandidate: (TokenCandidate, String) -> Unit,
) {
    val fallback = listOf(
        TokenCandidate("fallback:treasure", "Treasure", "宝物"),
        TokenCandidate("fallback:clue", "Clue", "手掛かり"),
        TokenCandidate("fallback:food", "Food", "食物"),
        TokenCandidate("fallback:insect", "Insect", "昆虫", power = "1", toughness = "1"),
        TokenCandidate("fallback:bear", "Bear", "熊", power = "2", toughness = "2"),
        TokenCandidate("fallback:beast", "Beast", "ビースト", power = "4", toughness = "4"),
        TokenCandidate("fallback:plant", "Plant", "植物", power = "0", toughness = "1"),
    )
    val shown = (candidates + fallback).distinctBy { it.displayName to it.power to it.toughness }.take(40)
    var name by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    var scope by rememberSaveable { mutableStateOf("ALL") }
    var images by rememberSaveable { mutableStateOf(false) }
    val filtered = shown.filter { matchesPlaySearch(it.displayName + " " + it.englishName, it.oracleText, query, scope) }
    var created by remember { mutableIntStateOf(0) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(0.92f), shape = MaterialTheme.shapes.large, tonalElevation = 8.dp) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(14.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("トークン作成", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = { images = !images }) { Icon(if (images) Icons.Default.ViewList else Icons.Default.GridView, if (images) "リスト表示" else "画像表示") }
                }
                CardSearchToolbar(query, { query = it }, scope, { scope = it }, "", emptyList(), {}, "トークンを検索", modifier = Modifier.padding(horizontal = 12.dp), showSort = false)
                OutlinedTextField(name, { name = it }, label = { Text("任意トークン名 / P/T") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp))
                if (name.isNotBlank()) {
                    Button(onClick = { onCreateCustom(name); created++ }, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) { Text("この名前で作成") }
                }
                Text(if (created == 0) "タップで1体ずつ追加できます" else "${created}体追加しました・続けて追加できます", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
                Text(if (candidates.isEmpty()) "よく使う候補" else "このデッキのトークン候補", style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                val state = rememberLazyListState()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(state = state, modifier = Modifier.fillMaxSize().padding(end = 12.dp), contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                        items(filtered, key = { it.tokenKey }) { token ->
                            var path by remember(token.tokenKey) { mutableStateOf("") }
                            var loading by remember(token.tokenKey) { mutableStateOf(false) }
                            var failed by remember(token.tokenKey) { mutableStateOf(false) }
                            var retry by remember(token.tokenKey) { mutableIntStateOf(0) }
                            LaunchedEffect(token.tokenKey, token.imageUrl, retry) {
                                if (token.imageUrl.isNotBlank()) {
                                    loading = true; failed = false
                                    try { path = vm.tokenImage(token) }
                                    catch (e: kotlinx.coroutines.CancellationException) { throw e }
                                    catch (_: Exception) { failed = true }
                                    finally { loading = false }
                                }
                            }
                            if (images) {
                                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clickable { onCreateCandidate(token, path); created++ }, horizontalAlignment = Alignment.CenterHorizontally) {
                                    if (path.isNotBlank()) AsyncImage(File(path), token.displayName, Modifier.width(150.dp).height(210.dp), contentScale = ContentScale.Fit)
                                    else Box(Modifier.width(150.dp).height(210.dp).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                                        if (loading) CircularProgressIndicator() else Text(token.displayName, Modifier.padding(12.dp))
                                    }
                                    Text("${token.displayName} ＋1", style = MaterialTheme.typography.labelLarge)
                                    if (failed) TextButton(onClick = { retry++ }) { Text("画像再取得") }
                                }
                            } else ListItem(
                                modifier = Modifier.clickable { onCreateCandidate(token, path); created++ },
                                leadingContent = {
                                    if (path.isNotBlank()) {
                                        AsyncImage(
                                            model = File(path),
                                            contentDescription = token.displayName,
                                            modifier = Modifier.width(46.dp).height(64.dp).clip(MaterialTheme.shapes.small),
                                            contentScale = ContentScale.Fit,
                                        )
                                    } else {
                                        Box(Modifier.width(46.dp).height(64.dp).background(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.shapes.small), contentAlignment = Alignment.Center) {
                                            if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                            else Text(token.power.takeIf { it.isNotBlank() }?.let { p -> "$p/${token.toughness}" } ?: "T", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                },
                                headlineContent = { Text(token.displayName) },
                                supportingContent = {
                                    val text = listOf(token.subtitle, token.oracleText).filter { it.isNotBlank() }.joinToString("\n")
                                    if (text.isNotBlank()) Text(text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                },
                                trailingContent = {
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("＋1", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                                        if (failed) TextButton(onClick = { retry++ }, contentPadding = PaddingValues(0.dp)) { Text("画像再取得", style = MaterialTheme.typography.labelSmall) }
                                    }
                                },
                            )
                            HorizontalDivider()
                        }
                    }
                    VerticalFastScrollbar(state)
                }
                HorizontalDivider()
                DialogCloseRow(onClose = onDismiss)
            }
        }
    }
}

@Composable
private fun TopFiveDialog(cards: List<PlayCard>, onDismiss: () -> Unit, onBottom: (PlayCard) -> Unit) {
    DeckLoomAlertDialog(onDismissRequest = onDismiss, title = { Text("ライブラリー上から最大5枚") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { cards.forEachIndexed { i, card -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("${i + 1}. ${card.name}", modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis); TextButton(onClick = { onBottom(card) }) { Text("下へ") } } } }
    }, confirmButton = { DialogCloseRow(onClose = onDismiss) })
}

/** Same root as the battlefield: gesture coordinates stay valid as the panel fades out. */
@Composable
private fun ZoneBrowserOverlay(
    zone: Zone, cards: List<PlayCard>, dragging: Boolean, onDismiss: () -> Unit, onDetail: (PlayCard) -> Unit,
    onDragStart: (PlayCard, Offset) -> Unit, onDrag: (Offset) -> Unit,
    onDragEnd: () -> Unit, onDragCancel: () -> Unit,
) {
    var query by rememberSaveable(zone) { mutableStateOf("") }
    var scope by rememberSaveable(zone) { mutableStateOf("ALL") }
    var images by rememberSaveable(zone) { mutableStateOf(zone == Zone.LIBRARY || zone == Zone.HAND) }
    val filtered = remember(cards, query, scope) {
        cards.filter { matchesPlaySearch(it.name, it.oracleText, query, scope) }
    }
    val imageGridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    LaunchedEffect(zone, query, scope) { imageGridState.scrollToItem(0); listState.scrollToItem(0) }
    BackHandler { if (dragging) onDragCancel() else onDismiss() }
    Box(Modifier.fillMaxSize().zIndex(2000f), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize()
            .background(if (dragging) Color.Transparent else Color.Black.copy(alpha = 0.48f))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                if (dragging) onDragCancel() else onDismiss()
            })
        // Keep the originating pointerInput mounted until release; removing it cancels the gesture.
        Surface(Modifier.systemBarsPadding().padding(horizontal = 16.dp).widthIn(max = 560.dp)
            .fillMaxWidth().fillMaxHeight(0.92f).alpha(if (dragging) 0f else 1f)
            .then(if (dragging) Modifier.clearAndSetSemantics { } else Modifier),
            shape = MaterialTheme.shapes.large, tonalElevation = 8.dp) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(14.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${zoneLabel(zone)} ${cards.size}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = { images = !images }) { Icon(if (images) Icons.Default.ViewList else Icons.Default.GridView, if (images) "リスト表示" else "画像表示") }
                }
                CardSearchToolbar(query, { query = it }, scope, { scope = it }, "", emptyList(), {}, "検索",
                    modifier = Modifier.padding(horizontal = 12.dp), showSort = false)
                Text("画像をドラッグで移動・タップで詳細", style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
                HorizontalDivider()
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (images) {
                        LazyVerticalGrid(columns = GridCells.Adaptive(112.dp), state = imageGridState, modifier = Modifier.fillMaxSize().padding(end = 12.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(filtered.size, key = { filtered[it].uid }) { index ->
                                val card = filtered[index]
                                // Keep scrollable space around each real image; only the image drags.
                                BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    val width = (maxWidth - 8.dp).coerceIn(48.dp, 156.dp)
                                    DraggableCard(card, width, width / 0.716f, onTap = { onDetail(card) }, onLongPress = { onDetail(card) },
                                        onDragStart = { onDragStart(card, it) }, onDrag = onDrag, onDragEnd = onDragEnd, onDragCancel = onDragCancel)
                                }
                            }
                        }
                        VerticalFastScrollbar(imageGridState)
                    } else {
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp)) {
                            items(filtered, key = { it.uid }) { card ->
                                BrowserTextCard(card, onClick = { onDetail(card) }, onDragStart = { onDragStart(card, it) },
                                    onDrag = onDrag, onDragEnd = onDragEnd, onDragCancel = onDragCancel)
                                HorizontalDivider()
                            }
                        }
                        VerticalFastScrollbar(listState)
                    }
                    if (filtered.isEmpty()) Text("該当するカードがありません", modifier = Modifier.align(Alignment.Center))
                }
                HorizontalDivider()
                DialogCloseRow(onClose = onDismiss)
            }
        }
    }
}

internal fun matchesPlaySearch(name: String, text: String, query: String, scope: String): Boolean =
    query.isBlank() || when (scope) {
        "NAME" -> name.contains(query, true)
        "TEXT" -> text.contains(query, true)
        else -> name.contains(query, true) || text.contains(query, true)
    }

@Composable
private fun BrowserTextCard(card: PlayCard, onClick: () -> Unit, onDragStart: (Offset) -> Unit, onDrag: (Offset) -> Unit, onDragEnd: () -> Unit, onDragCancel: () -> Unit) {
    ListItem(
        modifier = Modifier.clickable(onClick = onClick),
        headlineContent = { Text(card.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = { if (card.oracleText.isNotBlank()) Text(card.oracleText, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        leadingContent = {
            DraggableCard(card, 48.dp, 68.dp, onTap = onClick, onLongPress = onClick,
                onDragStart = onDragStart, onDrag = onDrag, onDragEnd = onDragEnd, onDragCancel = onDragCancel)
        },
        trailingContent = { if (card.counters != 0) Badge { Text(if (card.counters > 0) "+${card.counters}" else card.counters.toString()) } },
    )
}

private fun zoneLabel(zone: Zone): String = when (zone) {
    Zone.LIBRARY -> "デッキ"; Zone.HAND -> "手札"; Zone.BATTLEFIELD -> "戦場"; Zone.GRAVEYARD -> "墓地"; Zone.EXILE -> "追放"; Zone.COMMAND -> "コマンダー"
}

private fun copyPlaytestText(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
