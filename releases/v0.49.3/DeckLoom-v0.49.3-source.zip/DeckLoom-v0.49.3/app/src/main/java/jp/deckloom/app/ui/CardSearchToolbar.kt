package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

/** Identical scope / clear / sort affordances for deck and database search. */
@Composable
fun CardSearchToolbar(
    value: String,
    onValueChange: (String) -> Unit,
    scope: String,
    onScopeChange: (String) -> Unit,
    sort: String,
    sortOptions: List<Pair<String, String>>,
    onSortChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onSearch: () -> Unit = {},
    showSort: Boolean = true,
    groupByCategory: Boolean? = null,
    groupingEnabled: Boolean = true,
    onGroupByCategoryChange: (Boolean) -> Unit = {},
) {
    var scopeOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    val scopes = listOf("ALL" to "名前＋本文", "NAME" to "名前", "TEXT" to "本文")
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = value, onValueChange = onValueChange, singleLine = true, enabled = enabled,
            placeholder = { Text(if (scope == "ALL") placeholder else "${scopes.firstOrNull { it.first == scope }?.second ?: "名前"}を検索") },
            leadingIcon = {
                Box {
                    IconButton(onClick = { scopeOpen = true }, enabled = enabled) {
                        Box(Modifier.size(28.dp)) {
                            Icon(Icons.Default.Search, "検索対象：${scopes.firstOrNull { it.first == scope }?.second}", Modifier.align(Alignment.TopStart).size(22.dp))
                            Icon(Icons.Default.ArrowDropDown, null, Modifier.align(Alignment.BottomEnd).size(14.dp))
                        }
                    }
                    DropdownMenu(scopeOpen, { scopeOpen = false }) {
                        scopes.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(label) }, trailingIcon = { if (scope == key) Icon(Icons.Default.Check, null) }, onClick = { onScopeChange(key); scopeOpen = false })
                        }
                    }
                }
            },
            trailingIcon = { if (value.isNotEmpty()) IconButton(onClick = { onValueChange("") }, enabled = enabled) { Icon(Icons.Default.Close, "検索文字を消す") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier.weight(1f),
        )
        if (showSort) Box {
            IconButton(onClick = { sortOpen = true }, enabled = enabled) { Icon(Icons.Default.Sort, "並び順：${sortOptions.firstOrNull { it.first == sort }?.second.orEmpty()}") }
            DropdownMenu(sortOpen, { sortOpen = false }) {
                groupByCategory?.let { grouped ->
                    DropdownMenuItem(text = { Text("種類別にまとめる") }, enabled = groupingEnabled,
                        leadingIcon = { Checkbox(checked = grouped, onCheckedChange = null, enabled = groupingEnabled) },
                        onClick = { onGroupByCategoryChange(!grouped) })
                    HorizontalDivider()
                }
                sortOptions.forEach { (key, label) ->
                    DropdownMenuItem(text = { Text(label) }, trailingIcon = { if (sort == key) Icon(Icons.Default.Check, null) }, onClick = { onSortChange(key) })
                }
            }
        }
    }
}
