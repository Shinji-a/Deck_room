package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import jp.deckloom.app.data.DeckListCheck
import kotlinx.coroutines.delay

private val sample = """1x Slogurk, the Overslime [Commander]
1x Life from the Loam
1x Read the Runes
1x Simic Growth Chamber
7x Island
13x Forest"""

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportScreen(vm: AppViewModel, onBack: () -> Unit, onCreated: (Long) -> Unit) {
    var name by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var check by remember { mutableStateOf<DeckListCheck?>(null) }

    LaunchedEffect(text) {
        if (text.isBlank()) {
            check = null
            return@LaunchedEffect
        }
        delay(250)
        check = vm.checkDeckList(text)
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("一括インポート") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("デッキリストを貼り付け。ローカルDBで先に照合し、未認識カードがあっても他のカード処理は続行します。")
            OutlinedTextField(name, { name = it }, label = { Text("デッキ名") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(
                text, { text = it }, label = { Text("デッキリスト") }, placeholder = { Text(sample) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp),
            )
            check?.let { result ->
                Surface(shape = MaterialTheme.shapes.medium, tonalElevation = 1.dp) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ローカルDB一致 ${result.matchedCards}/${result.parsedCards}枚", style = MaterialTheme.typography.labelLarge)
                        if (result.unresolvedNames.isNotEmpty()) {
                            Text("DB未認識（インポート後も他カードは処理継続）: ${result.unresolvedNames.joinToString(" / ")}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Text("統率者は 1x Card Name [Commander] で指定できます。日本語・英語どちらも可。正確なカード名を推奨します。", style = MaterialTheme.typography.bodySmall)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Button(
                onClick = {
                    busy = true
                    vm.importDeck(name, text, onCreated = onCreated, onError = { error = it; busy = false })
                },
                enabled = text.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "作成中…" else "インポート") }
        }
    }
}
