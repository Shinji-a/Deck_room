package jp.deckloom.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import kotlin.math.roundToInt
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(vm: AppViewModel, deckId: Long, onBack: () -> Unit) {
    val data by remember(deckId) { vm.observeDeck(deckId) }.collectAsState(initial = null)
    val cards = data?.cards.orEmpty().filter { DeckRoles.countsTowardDeck(it.deckRole) }
    val expanded = cards.flatMap { c -> List(c.quantity) { c } }
    val nonCommander = expanded.filterNot { DeckSpecialRoles.startsInCommandZone(it.specialRole) }
    val lands = nonCommander.count { it.oracleTypeLine.contains("Land", true) }
    val types = listOf("Creature", "Instant", "Sorcery", "Artifact", "Enchantment", "Planeswalker", "Battle")
        .associateWith { t -> nonCommander.count { it.oracleTypeLine.contains(t, true) } }
    val nonLands = nonCommander.filterNot { it.oracleTypeLine.contains("Land", true) }
    val curve = (0..7).associateWith { bucket ->
        nonLands.count { c -> if (bucket == 7) c.cmc >= 7 else c.cmc.roundToInt() == bucket }
    }
    val max = (curve.values.maxOrNull() ?: 1).coerceAtLeast(1)
    val openingLand = if (nonCommander.size >= 7) (0..7).associateWith { k -> hypergeometric(nonCommander.size, lands, 7, k) } else emptyMap()
    val keepableLandRate = (2..4).sumOf { openingLand[it] ?: 0.0 }

    Scaffold(topBar = {
        TopAppBar(title = { Text("統計") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } })
    }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(data?.deck?.name.orEmpty(), style = MaterialTheme.typography.headlineSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text("土地 $lands") })
                AssistChip(onClick = {}, label = { Text("非土地 ${nonLands.size}") })
            }
            Text("カードタイプ", style = MaterialTheme.typography.titleMedium)
            types.forEach { (type, count) -> StatRow(type, count, nonCommander.size.coerceAtLeast(1)) }
            Text("マナカーブ", style = MaterialTheme.typography.titleMedium)
            curve.forEach { (mv, count) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (mv == 7) "7+" else mv.toString(), modifier = Modifier.width(28.dp))
                    Box(Modifier.weight(1f).height(18.dp).background(MaterialTheme.colorScheme.surfaceVariant)) {
                        Box(Modifier.fillMaxWidth(count.toFloat() / max).fillMaxHeight().background(MaterialTheme.colorScheme.primary))
                    }
                    Text(count.toString(), modifier = Modifier.width(28.dp))
                }
            }
            if (openingLand.isNotEmpty()) {
                Text("初手7枚の土地（マリガンなし）", style = MaterialTheme.typography.titleMedium)
                Text("2〜4土地: ${percent(keepableLandRate)}", style = MaterialTheme.typography.bodyLarge)
                Text(
                    "0: ${percent(openingLand[0] ?: 0.0)} / 1: ${percent(openingLand[1] ?: 0.0)} / 2: ${percent(openingLand[2] ?: 0.0)} / 3: ${percent(openingLand[3] ?: 0.0)} / 4: ${percent(openingLand[4] ?: 0.0)} / 5+: ${percent((5..7).sumOf { openingLand[it] ?: 0.0 })}",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun StatRow(label: String, count: Int, total: Int) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, modifier = Modifier.width(116.dp), maxLines = 1)
        LinearProgressIndicator(progress = { count.toFloat() / total }, modifier = Modifier.weight(1f))
        Text(count.toString(), modifier = Modifier.width(28.dp))
    }
}


private fun hypergeometric(population: Int, successes: Int, draws: Int, wanted: Int): Double {
    if (wanted < 0 || wanted > successes || draws - wanted > population - successes) return 0.0
    val denom = choose(population, draws)
    if (denom == 0.0) return 0.0
    return choose(successes, wanted) * choose(population - successes, draws - wanted) / denom
}

private fun choose(n: Int, k: Int): Double {
    if (k < 0 || k > n) return 0.0
    val kk = minOf(k, n - k)
    var result = 1.0
    for (i in 1..kk) result = result * (n - kk + i) / i
    return result
}

private fun percent(value: Double): String = String.format(Locale.US, "%.1f%%", value * 100.0)
