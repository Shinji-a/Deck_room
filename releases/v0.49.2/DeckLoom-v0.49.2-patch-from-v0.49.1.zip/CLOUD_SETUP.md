# クラウド環境のセットアップ

2026-10-10、cloud-environment-onboarding:setupに従い準備しました。選択リポジトリは初期コミットなしの状態だったため、ユーザー添付v0.49 Sourceを `/workspace/Deck_room` に展開しました。変更前にREADME／TODO／PROJECT_STATEを確認しています。Sourceと作業ディレクトリにAGENTS.mdはありませんでした。元ZIPと変更前コピーは `/workspace/baselines/DeckLoom-v0.49` とともに保管しています。

## 構成

| 項目 | 準備した版・場所 |
| --- | --- |
| JDK | Temurin 17.0.18+8、`/workspace/.deckloom-tools/jdk17` |
| Gradle | 既存Wrapper 8.13。配布SHA-256は既存Wrapper設定で検証 |
| Android | Platform 36、Build Tools 35.0.0、platform-tools |
| SDKコマンドラインツール | 19.0、`/workspace/.deckloom-tools/android-sdk` |
| Gradleキャッシュ | `/workspace/.deckloom-tools/gradle-home` |
| Android／Javaのユーザー用領域 | `/workspace/.deckloom-tools/android-user`、`java-home` |
| TLS | JDKの信頼ルートと環境のプロキシCAをローカルtrustStoreで利用。証明書検証を無効化しない |

既存のAGP 8.13.0、Kotlin 2.4.20、KSP 2.3.10およびアプリ依存バージョンを維持しています。環境準備のためにアプリDB取得処理やネットワーク実装を変更していません。署名キー、SDK、キャッシュ、ビルド生成物、端末固有local.propertiesはSource／Patchに含めません。

JDKは[Temurin公式配布](https://github.com/adoptium/temurin17-binaries/releases/tag/jdk-17.0.18%2B8)のSHA-256 `0c94cbb54325c40dcf026143eb621562017db5525727f2d9131a11250f72c450` と照合しました。Googleの `commandlinetools-linux-13114758_latest.zip` は[公式SDKリポジトリ情報](https://dl.google.com/android/repository/repository2-1.xml)のSHA-1 `5fdcc763663eefb86a5b8879697aa6088b041e70` と照合し、取得物のSHA-256は `7ec965280a073311c339e571cd5de778b9975026cfcbe79f2b1cdcb1e15317ee` でした。

## この環境での検証コマンド

```sh
source /workspace/.deckloom-tools/activate.sh
cd /workspace/Deck_room
bash ./gradlew --no-daemon --max-workers=4 \
  -Pkotlin.compiler.execution.strategy=in-process \
  :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
python3 tools/verify_room_schema.py
python3 tools/verify_regex_icu.py
```

SDKとJDKの導入、プロキシTLS、環境変数、ベースのビルドとチェックを再実行できる `install_script` と、起動後の手順 `start_skill` を環境設定案に保存しました。導入スクリプトはこの作業環境でも再実行して成功しています。保存済みの設定案は環境設定画面で内容を確認して保存・公開してください。設定案を保存しただけでは、公開済み設定や実行中環境へ反映したことにはなりません。

Web版参照ホストの許可追加も同じ設定案に保存しています。v0.49.1納品後の再試行ではWebページ・CSS・ページJSをHTTP 200で取得できました。v0.49.2では配色を反映しています。取得元と残る表示確認は[WEB_COLORS.md](WEB_COLORS.md)を参照してください。

Android Studioではプロジェクトを開き、JDK 17とSDK 36を設定します。上記の `/workspace` のパスはこのクラウド環境用で、ローカル端末でそのまま使う必要はありません。実機／エミュレーターの接続、アプリ起動、描画・指操作、従来の署名による更新はここでは検証していません。
