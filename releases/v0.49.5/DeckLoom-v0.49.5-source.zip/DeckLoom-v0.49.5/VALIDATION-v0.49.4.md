# v0.49.4 検証結果

2026-10-10、前回納品のv0.49.3 Sourceを基準にクラウドLinuxで検証しました。Androidの実機／エミュレーターでの画面描画・指操作と、ユーザーのWindows版Android Studioでの新版Sync／Runは未確認です。

| 検証 | 結果 |
| --- | --- |
| 現行Web参照 | HTML・CSS・JSをHTTP 200で取得。390px幅のChromiumでcomputed styleと絞り込みシートの開く状態を確認。外部カードデータは参照実行で遮断しており全動作は未検証 |
| 色の根拠 | 基本パレット・補助色のHEX 35種類が現行CSSに存在。主要文字色22組の静的コントラストは4.5:1以上 |
| `:app:assembleDebug` | Gradle 8.14.4／JDK 17／SDK 36で成功。APKはjp.deckloom.app / 0.49.4 / versionCode 23 |
| `:app:testDebugUnitTest` | 既存57件を実行、失敗0／エラー0／スキップ0。結果XMLの実行時刻も確認 |
| Room照合 | 本番5→6→7→8移行後の5テーブルが生成DDLと一致、foreign_key_check通過 |
| ICU検証 | ICU 76で本番22正規表現がコンパイル可能、マナ抽出9ケース成功。旧版の不正な式の再現も成功 |
| `:app:lintDebug` | 既存FullBackupContentエラー6件・警告31件・ヒント2件で失敗。前版とID・重大度・メッセージ・対象パスが一致、追加指摘なし |
| 変更範囲 | UI・バージョン表記・文書のみ。DB／network／一人回しエンジン／ViewModel・スキーマ・リソース・テスト・依存・Wrapperは前版とバイト一致 |
| 出典 | READMEのカード検索DB・画像利用元とWHISPER転載の記載をそのまま保持 |
| Source／Patch | 元の納品v0.49.3 ZIPへ実際のPatch ZIPを適用し、Source全156ファイルとのバイト一致と両ZIPのCRCを確認 |

## 環境・確認の限界

Temurin JDK 17.0.18+8、Gradle 8.14.4、AGP 8.13.0、Kotlin／Composeプラグイン2.4.20、KSP 2.3.10、Android Platform 36／Build Tools 35.0.0を維持します。前版で解消したGradle 8.13の非推奨警告は再発していません。TLS・チェックサム検証を維持しています。

基準版の変更前ビルド・57件テストはv0.49.3の[検証記録](VALIDATION-v0.49.3.md)を引き継ぎ、今回の画面変更後にAPK生成と57件を再実行しました。戻る等のアイコンはOutlinedのAutoMirrored版へ揃えました。既存menuAnchorの非推奨警告とDeckScreenの到達しない分岐の警告は残っています。Lintを抑制したりバックアップ仕様を変えて成功扱いにはしていません。

Webの参照方法・CSSの上書き・Androidへのスタイル調整は[DESIGN_RULES.md](DESIGN_RULES.md)に記載しました。Web専用エラー表示と現行Webダーク表示は未確認で、色を推測して確定していません。標準SansSerif・sp/dp・Material操作を使うため、WebのフォントやSVGをそのままコピーしたものではありません。

クラウドビルド・JVMテストは実機の見た目やジェスチャーを保証しません。検索シートの表示・下書き破棄／確定・ネストした選択ダイアログ、キーボードとフッター、文字拡大、選択面、通知、左下閉じる、盤面表示量、サムネイル限定ドラッグと別の移動方法は[TODO.md](TODO.md)で確認します。

配布はSource一式と**前回納品v0.49.3 Source専用**Patchのセットです。変更20・追加5・削除0ファイル。SDK・キャッシュ・署名キー・ビルド生成物・端末固有設定・過去の配布ZIPはSourceに含めません。SHA256SUMS-v0.49.4.txtとverification-v0.49.4.jsonに配布物のチェックサム・照合結果を記録しました。適用手順は[RELEASE-v0.49.4.md](RELEASE-v0.49.4.md)を参照してください。
