# v0.49.3 検証結果

2026-10-10、前回納品のv0.49.2 Sourceを基準に、クラウドLinux上で検証しました。ユーザーのWindows版Android Studioと実機／エミュレーターでの新版実行は未確認です。

| 検証 | 結果 |
| --- | --- |
| 変更前v0.49.2 | Gradle 8.13でassembleDebug／testDebugUnitTestタスクが成功（既存出力はUP-TO-DATE）。ユーザーと同じ非推奨警告を再現 |
| Wrapper更新 | Gradle 8.14.4の標準wrapperタスクが成功。gradlew・gradlew.bat・JAR・propertiesを更新 |
| 公式チェックサム | 配布ZIPのSHA-256をWrapperに設定。再生成JARのSHA-256が公式値と一致 |
| `:app:assembleDebug` | Gradle 8.14.4／JDK 17で成功。ビルドとテストの46タスクを実行 |
| `:app:testDebugUnitTest` | 57件を実行、失敗0／エラー0／スキップ0 |
| 非推奨警告 | 完全な成功ログでDeprecatedGradleVersionWarning／Deprecated Gradle Versionがないことを確認 |
| APKメタデータ | jp.deckloom.app / versionName 0.49.3 / versionCode 22 / minSdk宣言26 |
| Room照合 | 本番5→6→7→8移行後の5テーブルが生成DDLと一致し、foreign_key_check通過 |
| ICU検証 | ICU 76で本番22正規表現がコンパイル可能、マナ抽出9ケース成功。過去版の不正な式も再現 |
| `:app:lintDebug` | 既存FullBackupContentエラー6件・警告31件・ヒント2件で失敗。元v0.49と全指摘のID・重大度・メッセージ・対象パスが一致 |
| Source／Patch | 元の納品v0.49.2 ZIPへ実際のPatch ZIPを適用し、Source版151ファイルとのバイト一致とZIPのCRCを確認済み |

## 構成と参照

Gradle **8.14.4**。Temurin JDK 17.0.18+8、AGP 8.13.0、Kotlin／Composeプラグイン2.4.20、KSP 2.3.10、Android Platform 36／Build Tools 35.0.0とアプリ依存は前版のままです。Kotlin 2.5.0への更新と警告抑制フラグは含みません。

- [公式Gradle配布SHA-256](https://services.gradle.org/distributions/gradle-8.14.4-bin.zip.sha256): `f1771298a70f6db5a29daf62378c4e18a17fc33c9ba6b14362e0cdf40610380d`
- [公式Wrapper JAR SHA-256](https://services.gradle.org/distributions/gradle-8.14.4-wrapper.jar.sha256): `7d3a4ac4de1c32b59bc6a4eb8ecb8e612ccd0cf1ae1e99f66902da64df296172`

公式URLからチェックサムを取得し、配布ZIPはWrapper自身が検証してGradle 8.14.4を起動しました。再生成したJARは独立したSHA-256照合も通過しています。TLS・チェックサム検証は維持しています。

今回変更するのはWrapper一式、アプリのバージョン表記と文書です。アプリのソース・リソース・テスト、依存宣言、データ形式、スキーマとREADME出典は前版と同一であることを配布時にも照合しました。Web配色の根拠と専用エラー画面／現行Webダーク描画の未確認範囲は[WEB_COLORS.md](WEB_COLORS.md)を維持します。

既存のCompose非推奨APIなどのコンパイル警告とLintのバックアップ設定の指摘は残っています。Lint baselineや抑制フラグを追加して成功扱いにはしていません。

WindowsのAndroid StudioでGradle Syncを実行したとは扱いません。Gradle JDK 17でSync／Runを行い、警告の解消と同じ署名による更新を確認してください。スクロール・ドラッグ・表示・操作感も実機未確認で、[TODO.md](TODO.md)を確認項目とします。

配布はSourceと前回のv0.49.2 Source専用Patchのセットです。変更9・追加2・削除0ファイル。SDK・キャッシュ・署名キー・ビルド生成物・端末固有設定は含めません。SHA256SUMS-v0.49.3.txtとverification-v0.49.3.jsonにチェックサムと配布照合結果を記録しました。適用方法は[RELEASE-v0.49.3.md](RELEASE-v0.49.3.md)を参照してください。
