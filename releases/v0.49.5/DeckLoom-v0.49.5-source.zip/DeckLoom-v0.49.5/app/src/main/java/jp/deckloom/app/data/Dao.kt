package jp.deckloom.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DeckDao {
    @Query("SELECT * FROM decks ORDER BY sortOrder ASC, createdAt DESC, id DESC")
    fun observeDecks(): Flow<List<DeckEntity>>

    @Query("SELECT * FROM decks ORDER BY sortOrder ASC, createdAt DESC, id DESC")
    suspend fun getDecks(): List<DeckEntity>

    @Query("SELECT * FROM deck_cards ORDER BY isCommander DESC, id ASC")
    fun observeAllCards(): Flow<List<DeckCardEntity>>

    @Query("SELECT * FROM deck_cards ORDER BY id")
    suspend fun getAllCards(): List<DeckCardEntity>

    @Query("SELECT * FROM deck_folders ORDER BY sortOrder, id")
    fun observeFolders(): Flow<List<DeckFolderEntity>>

    @Query("SELECT * FROM deck_folders ORDER BY sortOrder, id")
    suspend fun getFolders(): List<DeckFolderEntity>

    @Query("SELECT * FROM deck_folders WHERE id = :id")
    suspend fun getFolder(id: Long): DeckFolderEntity?

    @Insert
    suspend fun insertFolder(folder: DeckFolderEntity): Long

    @Update
    suspend fun updateFolder(folder: DeckFolderEntity)

    @Query("DELETE FROM deck_folders WHERE id = :id")
    suspend fun deleteFolder(id: Long)

    @Query("SELECT * FROM deck_cards WHERE id = :id")
    suspend fun getCard(id: Long): DeckCardEntity?

    @Query("SELECT * FROM decks WHERE id = :deckId LIMIT 1")
    fun observeDeck(deckId: Long): Flow<DeckEntity?>

    @Query("SELECT * FROM decks WHERE id = :deckId LIMIT 1")
    suspend fun getDeck(deckId: Long): DeckEntity?

    @Query("SELECT * FROM deck_cards WHERE deckId = :deckId ORDER BY isCommander DESC, id ASC")
    fun observeCards(deckId: Long): Flow<List<DeckCardEntity>>

    @Query("SELECT * FROM deck_cards WHERE deckId = :deckId ORDER BY isCommander DESC, id ASC")
    suspend fun getCards(deckId: Long): List<DeckCardEntity>

    @Query("SELECT * FROM deck_cards WHERE cacheState != 'READY' ORDER BY id ASC")
    suspend fun getUnresolvedCards(): List<DeckCardEntity>

    @Insert
    suspend fun insertDeck(deck: DeckEntity): Long

    @Update
    suspend fun updateDeck(deck: DeckEntity)

    @Query("UPDATE decks SET cardSortMode = :mode WHERE id = :id")
    suspend fun updateDeckSort(id: Long, mode: String)

    @Query("UPDATE decks SET groupByCategory = :grouped WHERE id = :id")
    suspend fun updateDeckGrouping(id: Long, grouped: Boolean)

    @Insert
    suspend fun insertCards(cards: List<DeckCardEntity>): List<Long>

    @Update
    suspend fun updateCard(card: DeckCardEntity)

    @Query("UPDATE deck_cards SET imagePath = '', backImagePath = '', cacheState = 'PENDING' WHERE imagePath != '' OR backImagePath != ''")
    suspend fun clearCachedImagePaths()

    @Delete
    suspend fun deleteCard(card: DeckCardEntity)

    @Query("UPDATE deck_cards SET userCategory = :category WHERE id = :cardId")
    suspend fun updateCategory(cardId: Long, category: String)

    @Query("UPDATE deck_cards SET userCategory = :category WHERE id IN (:cardIds)")
    suspend fun updateCategories(cardIds: List<Long>, category: String)

    @Query("UPDATE deck_cards SET isCommander = 0, specialRole = CASE WHEN specialRole = 'COMMANDER' THEN 'NONE' ELSE specialRole END WHERE deckId = :deckId")
    suspend fun clearCommander(deckId: Long)

    @Query("UPDATE deck_cards SET isCommander = 1, specialRole = 'COMMANDER' WHERE id = :cardId")
    suspend fun setCommander(cardId: Long)

    @Delete
    suspend fun deleteDeck(deck: DeckEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSearchCards(cards: List<CardSearchEntity>)

    @Query("SELECT COUNT(*) FROM card_search")
    fun observeSearchCardCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM card_search")
    suspend fun searchCardCount(): Int

    @Query(
        """
        SELECT * FROM card_search
        WHERE normalizedName LIKE :query || '%'
           OR normalizedName LIKE '%' || :query || '%'
        ORDER BY
            CASE WHEN normalizedName LIKE :query || '%' THEN 0 ELSE 1 END,
            LENGTH(displayName) ASC,
            displayName COLLATE NOCASE ASC
        LIMIT :limit
        """
    )
    suspend fun searchCardNames(query: String, limit: Int = 20): List<CardSearchEntity>

    @Query("SELECT * FROM card_search WHERE normalizedName IN (:normalizedNames)")
    suspend fun findExactSearchCards(normalizedNames: List<String>): List<CardSearchEntity>

    @Insert
    suspend fun insertLog(log: DeckChangeLogEntity): Long

    @Query("SELECT * FROM deck_change_log WHERE deckId = :deckId ORDER BY createdAt DESC, id DESC LIMIT :limit")
    fun observeLogs(deckId: Long, limit: Int = 300): Flow<List<DeckChangeLogEntity>>

    @Insert
    suspend fun insertSavedSearch(search: SavedSearchEntity): Long

    @Query("SELECT * FROM saved_searches ORDER BY createdAt DESC LIMIT 100")
    fun observeSavedSearches(): Flow<List<SavedSearchEntity>>

    @Query("SELECT COUNT(*) FROM saved_searches")
    suspend fun savedSearchCount(): Int

    @Query("DELETE FROM saved_searches WHERE id = :id")
    suspend fun deleteSavedSearch(id: Long)

    @Query("DELETE FROM saved_searches WHERE id = (SELECT id FROM saved_searches ORDER BY createdAt ASC LIMIT 1)")
    suspend fun deleteOldestSavedSearch()
}
