package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DialogCloseRow(onClose: () -> Unit, enabled: Boolean = true, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        DeckroomTextButton(onClick = onClose, enabled = enabled, modifier = Modifier.heightIn(min = 48.dp)) { Text("閉じる") }
        Spacer(Modifier.weight(1f))
        actions()
    }
}

/** Dismiss always starts at the left; primary action stays at the right. */
@Composable
fun DeckLoomAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
) {
    AlertDialog(onDismissRequest = onDismissRequest, title = title, text = text,
        shape = MaterialTheme.shapes.extraLarge, containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        confirmButton = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (dismissButton != null) {
                    dismissButton()
                    Spacer(Modifier.weight(1f))
                }
                confirmButton()
            }
        })
}
