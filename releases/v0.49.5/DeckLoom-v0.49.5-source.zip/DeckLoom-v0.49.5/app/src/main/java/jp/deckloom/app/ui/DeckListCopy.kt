package jp.deckloom.app.ui

import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckExports
import jp.deckloom.app.data.DeckRoles

/** Full active-tab list; search/category filters and selection exports stay independent. */
fun deckListForCopy(cards: List<DeckCardEntity>, candidates: Boolean, english: Boolean): String {
    val source = if (candidates) cards.filter { it.deckRole == DeckRoles.CANDIDATE } else cards
    // Existing full-deck formatting excludes candidates. Its explicit-list mode
    // preserves candidate quantities and names without changing stored roles.
    return if (english) DeckExports.exportEnglish(source, selectedOnly = candidates)
    else DeckExports.exportHareruya(source, selectedOnly = candidates)
}
