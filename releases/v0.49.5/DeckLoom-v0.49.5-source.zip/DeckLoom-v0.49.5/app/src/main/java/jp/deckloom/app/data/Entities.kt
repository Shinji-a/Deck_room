package jp.deckloom.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object DeckRoles {
    const val MAIN = "MAIN"
    const val COMMANDER = "COMMANDER"
    const val SECOND_COMMANDER = "SECOND_COMMANDER"
    const val COMPANION = "COMPANION"
    const val CANDIDATE = "CANDIDATE"

    fun countsTowardDeck(role: String): Boolean = role != CANDIDATE
}

object DeckSpecialRoles {
    const val NONE = "NONE"
    const val COMMANDER = "COMMANDER"
    const val COMPANION_BACKGROUND = "COMPANION_BACKGROUND"
    fun startsInCommandZone(role: String): Boolean = role == COMMANDER || role == COMPANION_BACKGROUND
}

@Entity(
    tableName = "deck_folders",
    foreignKeys = [ForeignKey(entity = DeckFolderEntity::class, parentColumns = ["id"], childColumns = ["parentId"], onDelete = ForeignKey.SET_NULL)],
    indices = [Index("parentId")],
)
data class DeckFolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sortOrder: Long = 0,
    @ColumnInfo(defaultValue = "NULL") val parentId: Long? = null,
)

@Entity(
    tableName = "decks",
    foreignKeys = [ForeignKey(entity = DeckFolderEntity::class, parentColumns = ["id"], childColumns = ["folderId"], onDelete = ForeignKey.SET_NULL)],
    indices = [Index("folderId")],
)
data class DeckEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "NULL") val folderId: Long? = null,
    @ColumnInfo(defaultValue = "''") val note: String = "",
    @ColumnInfo(defaultValue = "0") val sortOrder: Long = 0,
    @ColumnInfo(defaultValue = "'REGISTERED'") val cardSortMode: String = "REGISTERED",
    @ColumnInfo(defaultValue = "1") val groupByCategory: Boolean = true,
)

@Entity(
    tableName = "deck_cards",
    foreignKeys = [ForeignKey(
        entity = DeckEntity::class,
        parentColumns = ["id"],
        childColumns = ["deckId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("deckId"), Index(value = ["deckId", "deckRole"])],
)
data class DeckCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val quantity: Int,
    val inputName: String,
    @ColumnInfo(defaultValue = "0") val addedAt: Long = System.currentTimeMillis(),
    val oracleName: String = "",
    @ColumnInfo(defaultValue = "''") val oracleId: String = "",
    val displayName: String = "",
    val printedName: String = "",
    val displayTypeLine: String = "",
    val oracleTypeLine: String = "",
    val oracleText: String = "",
    val manaCost: String = "",
    val cmc: Double = 0.0,
    val colorIdentity: String = "",
    val scryfallId: String = "",
    val imagePath: String = "",
    val backImagePath: String = "",
    @ColumnInfo(defaultValue = "''") val selectedPrintingId: String = "",
    val category: String = "未分類",
    @ColumnInfo(defaultValue = "''") val userCategory: String = "",
    val isCommander: Boolean = false,
    @ColumnInfo(defaultValue = "'MAIN'") val deckRole: String = DeckRoles.MAIN,
    @ColumnInfo(defaultValue = "'NONE'") val specialRole: String = DeckSpecialRoles.NONE,
    val cacheState: String = "PENDING",
    val errorMessage: String = "",
)

@Entity(
    tableName = "deck_change_log",
    foreignKeys = [ForeignKey(
        entity = DeckEntity::class,
        parentColumns = ["id"],
        childColumns = ["deckId"],
        onDelete = ForeignKey.CASCADE,
    )],
    indices = [Index("deckId"), Index(value = ["deckId", "createdAt"])],
)
data class DeckChangeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val deckId: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val action: String,
    val cardName: String = "",
    val quantity: Int = 0,
    val fromRole: String = "",
    val toRole: String = "",
    val note: String = "",
)

@Entity(tableName = "saved_searches", indices = [Index("createdAt")])
data class SavedSearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val description: String,
    val filterJson: String,
)

@Entity(
    tableName = "card_search",
    indices = [
        Index(value = ["normalizedName"]),
        Index(value = ["oracleName"]),
    ],
)
data class CardSearchEntity(
    @PrimaryKey val searchKey: String,
    val normalizedName: String,
    val displayName: String,
    val oracleName: String,
    val language: String = "en",
    val source: String = "catalog",
)

data class DeckWithCards(
    val deck: DeckEntity,
    val cards: List<DeckCardEntity>,
)
