package jp.deckloom.app.data

/** Shared by navigation, destination pickers and transactional move validation. */
object FolderTree {
    fun path(id: Long?, folders: List<DeckFolderEntity>): String {
        val byId = folders.associateBy { it.id }
        val names = mutableListOf<String>()
        val visited = mutableSetOf<Long>()
        var current = id
        while (current != null && visited.add(current)) {
            val folder = byId[current] ?: break
            names += folder.name
            current = folder.parentId
        }
        return (listOf("デッキ") + names.asReversed()).joinToString(" / ")
    }

    fun canMove(id: Long, parentId: Long?, folders: List<DeckFolderEntity>): Boolean {
        val byId = folders.associateBy { it.id }
        if (id !in byId) return false
        val visited = mutableSetOf<Long>()
        var current = parentId
        while (current != null) {
            if (current == id || !visited.add(current)) return false
            current = (byId[current] ?: return false).parentId
        }
        return true
    }
}
