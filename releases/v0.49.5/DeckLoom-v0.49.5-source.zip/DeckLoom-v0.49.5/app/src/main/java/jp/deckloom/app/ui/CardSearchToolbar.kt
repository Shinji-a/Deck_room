package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import jp.deckloom.app.ui.theme.DeckroomSearchShape
import jp.deckloom.app.ui.theme.LocalDeckroomControlColors

/** Identical scope / clear / sort affordances for deck and database search. */
@Composable
fun CardSearchToolbar(
    value: String,
    onValueChange: (String) -> Unit,
    scope: String,
    onScopeChange: (String) -> Unit,
    sort: String,
    sortOptions: List<Pair<String, String>>,
    onSortChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onSearch: () -> Unit = {},
    showSort: Boolean = true,
    groupByCategory: Boolean? = null,
    groupingEnabled: Boolean = true,
    onGroupByCategoryChange: (Boolean) -> Unit = {},
) {
    var scopeOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }
    val scopes = listOf("ALL" to "名前＋本文", "NAME" to "名前", "TEXT" to "本文")
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        DeckroomTextField(
            value = value, onValueChange = onValueChange, singleLine = true, enabled = enabled,
            placeholder = { Text(if (scope == "ALL") placeholder else "${scopes.firstOrNull { it.first == scope }?.second ?: "名前"}を検索") },
            leadingIcon = {
                Box {
                    DeckroomIconButton(onClick = { scopeOpen = true }, enabled = enabled, outlined = false) {
                        Box(Modifier.size(28.dp)) {
                            Icon(Icons.Outlined.Search, "検索対象：${scopes.firstOrNull { it.first == scope }?.second}", Modifier.align(Alignment.TopStart).size(22.dp))
                            Icon(Icons.Outlined.ArrowDropDown, null, Modifier.align(Alignment.BottomEnd).size(14.dp))
                        }
                    }
                    DropdownMenu(scopeOpen, { scopeOpen = false }) {
                        scopes.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(label) }, trailingIcon = { if (scope == key) Icon(Icons.Outlined.Check, null) }, onClick = { onScopeChange(key); scopeOpen = false })
                        }
                    }
                }
            },
            trailingIcon = { if (value.isNotEmpty()) DeckroomIconButton(onClick = { onValueChange("") }, enabled = enabled, outlined = false) { Icon(Icons.Outlined.Close, "検索文字を消す") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            shape = DeckroomSearchShape,
            colors = deckroomTextFieldColors(LocalDeckroomControlColors.current.searchBorder),
            modifier = Modifier.weight(1f),
        )
        if (showSort) Box {
            DeckroomIconButton(onClick = { sortOpen = true }, enabled = enabled) { Icon(Icons.AutoMirrored.Outlined.Sort, "並び順：${sortOptions.firstOrNull { it.first == sort }?.second.orEmpty()}") }
            DropdownMenu(sortOpen, { sortOpen = false }) {
                groupByCategory?.let { grouped ->
                    DropdownMenuItem(text = { Text("種類別にまとめる") }, enabled = groupingEnabled,
                        leadingIcon = { Checkbox(checked = grouped, onCheckedChange = null, enabled = groupingEnabled) },
                        onClick = { onGroupByCategoryChange(!grouped) })
                    HorizontalDivider()
                }
                sortOptions.forEach { (key, label) ->
                    DropdownMenuItem(text = { Text(label) }, trailingIcon = { if (sort == key) Icon(Icons.Outlined.Check, null) }, onClick = { onSortChange(key) })
                }
            }
        }
    }
}
