package jp.deckloom.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import jp.deckloom.app.ui.theme.LocalDeckroomControlColors

/** White controls, thin boundaries and deliberate accents, shared by all screens. */
@Composable
fun DeckroomButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    shape: Shape = MaterialTheme.shapes.small,
    colors: ButtonColors = ButtonDefaults.buttonColors(),
    contentPadding: PaddingValues = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit,
) = Button(onClick, modifier.heightIn(min = 48.dp), enabled = enabled, shape = shape,
    colors = colors, elevation = null, contentPadding = contentPadding, content = content)

@Composable
fun DeckroomOutlinedButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    shape: Shape = MaterialTheme.shapes.small,
    colors: ButtonColors = ButtonDefaults.outlinedButtonColors(
        containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface),
    border: BorderStroke? = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit,
) = OutlinedButton(onClick, modifier.heightIn(min = 48.dp), enabled = enabled, shape = shape,
    colors = colors, border = border, contentPadding = contentPadding, content = content)

@Composable
fun DeckroomTextButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    colors: ButtonColors = ButtonDefaults.textButtonColors(),
    contentPadding: PaddingValues = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
    content: @Composable RowScope.() -> Unit,
) = TextButton(onClick, modifier.heightIn(min = 48.dp), enabled = enabled,
    shape = MaterialTheme.shapes.small, colors = colors, contentPadding = contentPadding, content = content)

@Composable
fun DeckroomTonalButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit,
) = FilledTonalButton(onClick, modifier.heightIn(min = 48.dp), enabled = enabled,
    shape = MaterialTheme.shapes.small, contentPadding = contentPadding, content = content)

/** 36dp visible outline inside a 48dp Android tap target. */
@Composable
fun DeckroomIconButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true,
    outlined: Boolean = true, content: @Composable () -> Unit,
) {
    IconButton(onClick, modifier.sizeIn(minWidth = 48.dp, minHeight = 48.dp), enabled = enabled) {
        Box(Modifier.size(36.dp)
            .background(MaterialTheme.colorScheme.surface, MaterialTheme.shapes.small)
            .then(if (outlined) Modifier.border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.small) else Modifier),
            contentAlignment = Alignment.Center) {
            CompositionLocalProvider(LocalContentColor provides
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = if (enabled) 1f else 0.38f)) { content() }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckroomTopAppBar(
    title: @Composable () -> Unit, modifier: Modifier = Modifier,
    navigationIcon: @Composable () -> Unit = {}, actions: @Composable RowScope.() -> Unit = {},
) {
    Column(modifier) {
        TopAppBar(title = { ProvideTextStyle(MaterialTheme.typography.titleLarge) { title() } },
            navigationIcon = navigationIcon, actions = actions,
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface,
                actionIconContentColor = MaterialTheme.colorScheme.onSurfaceVariant))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
fun DeckroomFooter(content: @Composable () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
        Column {
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            content()
        }
    }
}

@Composable
fun deckroomTextFieldColors(unfocusedBorderColor: Color = MaterialTheme.colorScheme.outlineVariant): TextFieldColors =
    OutlinedTextFieldDefaults.colors(focusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        unfocusedBorderColor = unfocusedBorderColor)

@Composable
fun DeckroomTextField(
    value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, readOnly: Boolean = false,
    textStyle: TextStyle = MaterialTheme.typography.bodyLarge,
    label: (@Composable () -> Unit)? = null, placeholder: (@Composable () -> Unit)? = null,
    leadingIcon: (@Composable () -> Unit)? = null, trailingIcon: (@Composable () -> Unit)? = null,
    supportingText: (@Composable () -> Unit)? = null, isError: Boolean = false,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = false, maxLines: Int = if (singleLine) 1 else Int.MAX_VALUE, minLines: Int = 1,
    shape: Shape = MaterialTheme.shapes.medium,
    colors: TextFieldColors = deckroomTextFieldColors(),
) = OutlinedTextField(value, onValueChange, modifier, enabled = enabled, readOnly = readOnly,
    textStyle = textStyle, label = label, placeholder = placeholder, leadingIcon = leadingIcon,
    trailingIcon = trailingIcon, supportingText = supportingText, isError = isError,
    visualTransformation = visualTransformation, keyboardOptions = keyboardOptions,
    keyboardActions = keyboardActions, singleLine = singleLine, maxLines = maxLines,
    minLines = minLines, shape = shape, colors = colors)

@Composable
fun DeckroomFilterChip(
    selected: Boolean, onClick: () -> Unit, label: @Composable () -> Unit,
    modifier: Modifier = Modifier, enabled: Boolean = true,
) = FilterChip(selected, onClick, label, modifier.heightIn(min = 48.dp), enabled = enabled,
    shape = MaterialTheme.shapes.small,
    colors = FilterChipDefaults.filterChipColors(containerColor = MaterialTheme.colorScheme.surface,
        labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
        selectedContainerColor = LocalDeckroomControlColors.current.selection,
        selectedLabelColor = LocalDeckroomControlColors.current.onSelection),
    border = BorderStroke(1.dp, if (selected) LocalDeckroomControlColors.current.selectionBorder else MaterialTheme.colorScheme.outlineVariant))

@Composable
fun DeckroomSegments(labels: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Row(Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            labels.forEachIndexed { index, label ->
                DeckroomTextButton(onClick = { onSelect(index) }, modifier = Modifier.weight(1f)
                    .semantics { this.selected = selected == index; role = Role.Tab },
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    colors = ButtonDefaults.textButtonColors(
                        containerColor = if (selected == index) LocalDeckroomControlColors.current.selection else MaterialTheme.colorScheme.surfaceContainerLow,
                        contentColor = if (selected == index) LocalDeckroomControlColors.current.onSelection else MaterialTheme.colorScheme.onSurfaceVariant)) {
                    Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun DeckroomListItem(
    headlineContent: @Composable () -> Unit, modifier: Modifier = Modifier,
    supportingContent: (@Composable () -> Unit)? = null,
    leadingContent: (@Composable () -> Unit)? = null, trailingContent: (@Composable () -> Unit)? = null,
    colors: ListItemColors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
    divider: Boolean = false,
) {
    Column {
        ListItem(headlineContent = { ProvideTextStyle(MaterialTheme.typography.titleMedium) { headlineContent() } },
            modifier = modifier, supportingContent = supportingContent?.let { content ->
                { ProvideTextStyle(MaterialTheme.typography.bodySmall) { content() } }
            }, leadingContent = leadingContent, trailingContent = trailingContent, colors = colors)
        if (divider) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}
