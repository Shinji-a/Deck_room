package jp.deckloom.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.material3.*
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavBackStackEntry
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun DeckLoomApp(vm: AppViewModel) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val gate = remember { NavigationGate(android.os.SystemClock::elapsedRealtime) }
    fun accepted(entry: NavBackStackEntry) = gate.accept(entry.id, nav.currentBackStackEntry?.id, entry.lifecycle.currentState == Lifecycle.State.RESUMED)
    fun back(entry: NavBackStackEntry) { if (nav.previousBackStackEntry != null && accepted(entry)) nav.popBackStack() }
    fun open(entry: NavBackStackEntry, route: String, fromImport: Boolean = false) {
        if (accepted(entry)) nav.navigate(route) { launchSingleTop = true; if (fromImport) popUpTo("home") }
    }
    Box(Modifier.fillMaxSize()) {
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { entry ->
            HomeScreen(
                vm,
                onImport = { open(entry, "import") },
                onDeck = { open(entry, "deck/$it") },
                onSearch = { open(entry, "search") },
                onSettings = { open(entry, "settings") },
            )
        }
        composable("settings") { entry ->
            BackHandler { back(entry) }
 SettingsScreen(vm, onBack = { back(entry) }, onHowTo = { open(entry, "howto") }) }
        composable("howto") { entry ->
            BackHandler { back(entry) }
 HowToScreen(onBack = { back(entry) }) }
        composable("import") { entry ->
            BackHandler { back(entry) }
 ImportScreen(vm, onBack = { back(entry) }, onCreated = { open(entry, "deck/$it", fromImport = true) }) }
        composable("search") { entry ->
            BackHandler { back(entry) }
 CardDatabaseSearchScreen(vm, null, onBack = { back(entry) }) }
        composable("search/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
            BackHandler { back(entry) }
            val id = entry.arguments?.getLong("id") ?: return@composable
            CardDatabaseSearchScreen(vm, id, onBack = { back(entry) })
        }
        composable("deck/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
            BackHandler { back(entry) }
            val id = entry.arguments?.getLong("id") ?: return@composable
            DeckScreen(
                vm = vm,
                deckId = id,
                onBack = { back(entry) },
                onPlay = { open(entry, "play/$id") },
                onStats = { open(entry, "stats/$id") },
                onSearchCards = { open(entry, "search/$id") },
                onOpenDeck = { newId -> open(entry, "deck/$newId") },
                onExport = { text ->
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("DeckLoom deck list", text))
                },
            )
        }
        composable("play/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
            BackHandler { back(entry) }
            val id = entry.arguments?.getLong("id") ?: return@composable
            PlaytestScreen(vm, id, onBack = { back(entry) })
        }
        composable("stats/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
            BackHandler { back(entry) }
            val id = entry.arguments?.getLong("id") ?: return@composable
            StatsScreen(vm, id, onBack = { back(entry) })
        }
    }
    }

}
