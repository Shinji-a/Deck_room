package jp.deckloom.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.ViewList
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import jp.deckloom.app.data.DeckValidation
import jp.deckloom.app.data.CardCategories
import jp.deckloom.app.data.DeckCardSorting
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import jp.deckloom.app.network.ScryfallClient
import coil3.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckScreen(
    vm: AppViewModel,
    deckId: Long,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onStats: () -> Unit,
    onSearchCards: () -> Unit,
    onOpenDeck: (Long) -> Unit,
    onExport: (String) -> Unit,
) {
    val flow = remember(deckId) { vm.observeDeck(deckId) }
    val data by flow.collectAsState(initial = null)
    val logs by remember(deckId) { vm.observeLogs(deckId) }.collectAsState(initial = emptyList())
    val progress by vm.cacheProgress.collectAsState()
    val packProgress by vm.imagePackProgress.collectAsState()
    val mediumProgress by vm.mediumImagePackProgress.collectAsState()
    var selected by remember { mutableStateOf<DeckCardEntity?>(null) }
    var selectedIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var grid by rememberSaveable(deckId) { mutableStateOf(false) }
    var category by rememberSaveable(deckId) { mutableStateOf("すべて") }
    var addDialog by remember { mutableStateOf(false) }
    var query by rememberSaveable(deckId) { mutableStateOf("") }
    var queryScope by rememberSaveable(deckId) { mutableStateOf("ALL") }
    var imageStatusOpen by remember { mutableStateOf(false) }
    var deckStatusOpen by remember { mutableStateOf(false) }
    var categoryBatch by remember { mutableStateOf(false) }
    var tab by rememberSaveable(deckId) { mutableIntStateOf(0) }
    val pagerScope = rememberCoroutineScope()
    fun selectTab(value: Int) { tab = value; category = "すべて"; selectedIds = emptySet() }
    var menu by remember { mutableStateOf(false) }
    var playWarning by remember { mutableStateOf(false) }
    var validation by remember { mutableStateOf(DeckValidation(0, 0, emptyList())) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDeckDialog by remember { mutableStateOf(false) }
    var printingFor by remember { mutableStateOf<DeckCardEntity?>(null) }
    var printingOptions by remember { mutableStateOf<List<ScryfallClient.PrintingOption>>(emptyList()) }
    var printingLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val mainListState = rememberLazyListState()
    val candidateListState = rememberLazyListState()
    val mainGridState = rememberLazyGridState()
    val candidateGridState = rememberLazyGridState()

    val deck = data?.deck
    val cards = data?.cards.orEmpty()
    // Deck count is owned by the local deck DB. Card-index/image resolution must
    // never make a 100-card deck temporarily appear as 0/100.
    val mainDeckCount = cards
        .filter { DeckRoles.countsTowardDeck(it.deckRole) }
        .sumOf { it.quantity }
    LaunchedEffect(cards) { validation = vm.validateDeck(cards) }

    val mainCards = cards.filter { it.deckRole != DeckRoles.CANDIDATE }
    val candidateCards = cards.filter { it.deckRole == DeckRoles.CANDIDATE }
    val shownBase = if (tab == 1) candidateCards else mainCards
    fun displayCategory(card: DeckCardEntity): String = CardCategories.display(card)
    val categories = listOf("すべて") + shownBase.map(::displayCategory).distinct().sorted()
    fun matches(card: DeckCardEntity): Boolean {
        val fields = when (queryScope) {
            "NAME" -> listOf(card.displayName, card.oracleName, card.inputName)
            "TEXT" -> listOf(card.oracleText)
            else -> listOf(card.displayName, card.oracleName, card.inputName, card.oracleText)
        }
        return (category == "すべて" || displayCategory(card) == category) && (query.isBlank() || fields.any { deckSearchKey(it).contains(deckSearchKey(query), true) })
    }
    val grouped = category == "すべて" && (deck?.groupByCategory ?: true)
    val filtered = DeckCardSorting.sort(shownBase.filter(::matches), deck?.cardSortMode ?: "REGISTERED", grouped)
    val categoryTransition = remember(deckId) { Animatable(1f) }
    var previousPage by remember(deckId) { mutableStateOf(tab to category) }
    var categorySlideDirection by remember(deckId) { mutableFloatStateOf(1f) }
    val categorySlideDistance = with(LocalDensity.current) { 20.dp.toPx() }
    LaunchedEffect(tab, category) {
        val next = tab to category
        if (next != previousPage) {
            categorySlideDirection = if (tab != previousPage.first) {
                if (tab > previousPage.first) 1f else -1f
            } else {
                if (categories.indexOf(category) >= categories.indexOf(previousPage.second)) 1f else -1f
            }
            previousPage = next
            categoryTransition.snapTo(0f)
            categoryTransition.animateTo(1f, tween(180))
        }
    }
    BackHandler(enabled = selectedIds.isNotEmpty()) { selectedIds = emptySet() }
    LaunchedEffect(categories, data != null) { if (data != null && category !in categories) category = "すべて" }
    val imageRevision by vm.imageRevision.collectAsState()
    val ready = remember(cards, imageRevision, packProgress, mediumProgress) { cards.count { (it.imagePath.isNotBlank() && File(it.imagePath).exists()) || vm.deckPreferredImagePath(it).isNotBlank() } }
    val missing = cards.size - ready
    var previousFilter by rememberSaveable(deckId) { mutableStateOf("$tab|$category|$query|$queryScope") }
    LaunchedEffect(tab, category, query, queryScope) {
        val next = "$tab|$category|$query|$queryScope"
        if (next != previousFilter && tab != 2) {
            (if (tab == 1) candidateListState else mainListState).scrollToItem(0)
            (if (tab == 1) candidateGridState else mainGridState).scrollToItem(0)
        }
        previousFilter = next
    }
    val errors = cards.filter { it.errorMessage.isNotBlank() }

    var headerCollapsed by remember { mutableStateOf(false) }
    val collapseConnection = rememberHeaderScrollConnection { headerCollapsed = it }

    Scaffold(
        topBar = {
            DeckroomTopAppBar(
                title = { Text(if (selectedIds.isNotEmpty()) "選択中 ${selectedIds.size}枚" else deck?.name ?: "デッキ", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { DeckroomIconButton(onClick = { if (selectedIds.isNotEmpty()) selectedIds = emptySet() else onBack() }) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, null) } },
                actions = {
                    if (selectedIds.isNotEmpty()) {
                        var exportMenu by remember { mutableStateOf(false) }
                        Box {
                            DeckroomIconButton(onClick = { exportMenu = true }) { Icon(Icons.Outlined.ContentCopy, "選択カードを出力") }
                            DropdownMenu(exportMenu, { exportMenu = false }) {
                                listOf(false to "晴れる屋形式", true to "英語形式").forEach { (english, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = {
                                        onExport(vm.exportSelected(cards.filter { it.id in selectedIds }, english))
                                        exportMenu = false; vm.showNotice("選択した${selectedIds.size}件をコピーしました")
                                    })
                                }
                            }
                        }
                        DeckroomIconButton(onClick = { selectedIds = emptySet() }) { Icon(Icons.Outlined.Close, "選択を解除") }
                    } else {
                    DeckroomIconButton(onClick = {
                        val listState = if (tab == 1) candidateListState else mainListState
                        val gridState = if (tab == 1) candidateGridState else mainGridState
                        val anchorCardId = if (grid) {
                            val idx = gridState.firstVisibleItemIndex
                            filtered.getOrNull(idx)?.id
                        } else {
                            listState.layoutInfo.visibleItemsInfo.firstNotNullOfOrNull { it.key as? Long }
                        }
                        grid = !grid
                        anchorCardId?.let { id ->
                            pagerScope.launch {
                                val cardIndex = filtered.indexOfFirst { it.id == id }.coerceAtLeast(0)
                                if (grid) gridState.scrollToItem(cardIndex) else {
                                    var listIndex = if (grouped) 0 else cardIndex
                                    if (grouped) run loop@{ filtered.groupBy(::displayCategory).forEach { (_, group) ->
                                        listIndex++
                                        val inGroup = group.indexOfFirst { it.id == id }
                                        if (inGroup >= 0) { listIndex += inGroup; return@loop }
                                        listIndex += group.size
                                    } }
                                    listState.scrollToItem(listIndex.coerceAtLeast(0))
                                }
                            }
                        }
                    }) { Icon(if (grid) Icons.AutoMirrored.Outlined.ViewList else Icons.Outlined.GridView, contentDescription = "表示切替") }
                    DeckroomIconButton(onClick = onSearchCards) { Icon(Icons.Outlined.Search, contentDescription = "カードDB検索") }
                    DeckroomIconButton(onClick = { imageStatusOpen = true }) {
                        BadgedBox(badge = { if (missing > 0) Badge { Text(missing.toString()) } }) {
                            Icon(Icons.Outlined.Refresh, contentDescription = "画像の取得状態：未取得${missing}枚")
                        }
                    }
                    Box {
                        DeckroomIconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "menu") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("統計") }, onClick = { menu = false; onStats() })
                            DropdownMenuItem(text = { Text("デッキの状態") }, onClick = { menu = false; deckStatusOpen = true })
                            val copyTarget = if (tab == 1) "候補" else "メイン"
                            DropdownMenuItem(text = { Text("${copyTarget}の晴れる屋形式（日本語）をコピー") }, onClick = {
                                onExport(deckListForCopy(cards, candidates = tab == 1, english = false))
                                menu = false; vm.showNotice("${copyTarget}の日本語リストをコピーしました")
                            })
                            DropdownMenuItem(text = { Text("${copyTarget}の英語名リストをコピー") }, onClick = {
                                onExport(deckListForCopy(cards, candidates = tab == 1, english = true))
                                menu = false; vm.showNotice("${copyTarget}の英語名リストをコピーしました")
                            })
                            DropdownMenuItem(text = { Text("デッキ名を変更") }, onClick = { menu = false; renameDialog = true })
                            DropdownMenuItem(text = { Text("デッキをコピー") }, onClick = {
                                menu = false
                                vm.copyDeck(deckId, onDone = { id -> vm.showNotice("デッキをコピーしました"); onOpenDeck(id) }, onError = vm::showNotice)
                            })
                            DropdownMenuItem(text = { Text("デッキを削除", color = MaterialTheme.colorScheme.error) }, onClick = { menu = false; deleteDeckDialog = true })
                        }
                    }
                    }
                },
            )
        },
        bottomBar = {
            if (tab != 2) DeckroomFooter {
                Column(Modifier.navigationBarsPadding()) {
                if (selectedIds.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${selectedIds.size}枚を選択", modifier = Modifier.weight(1f))
                    DeckroomTextButton(onClick = { categoryBatch = true }) { Text("カテゴリ") }
                    DeckroomTextButton(onClick = { selectedIds = emptySet() }) { Text("解除") }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    DeckroomOutlinedButton(onClick = {
                        vm.moveCards(deckId, selectedIds.toList(), if (tab == 1) DeckRoles.MAIN else DeckRoles.CANDIDATE, onDone = { selectedIds = emptySet() })
                    }, modifier = Modifier.weight(0.85f), contentPadding = PaddingValues(horizontal = 8.dp)) { Text(if (tab == 1) "メインへ" else "候補へ") }
                    DeckroomButton(onClick = {
                        vm.deleteCards(deckId, selectedIds.toList())
                        selectedIds = emptySet()
                    }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("削除") }
                }
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DeckroomOutlinedButton(onClick = { if (mainDeckCount != 100 || validation.duplicateWarnings.isNotEmpty()) playWarning = true else onPlay() },
                            modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 52.dp), shape = MaterialTheme.shapes.medium, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Icon(Icons.Outlined.PlayArrow, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("一人回し", maxLines = 2)
                        }
                        DeckroomButton(onClick = { addDialog = true }, modifier = Modifier.weight(1f).fillMaxHeight().heightIn(min = 52.dp), shape = MaterialTheme.shapes.medium, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Icon(Icons.Outlined.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("カードを追加", maxLines = 2)
                        }
                    }
                }
                }
            }
        },
        snackbarHost = { OperationNoticeHost(vm, visible = selected == null && !addDialog) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().nestedScroll(collapseConnection)) {
            androidx.compose.animation.AnimatedVisibility(visible = !headerCollapsed, enter = expandVertically(tween(240)), exit = shrinkVertically(tween(240))) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DeckroomSegments(listOf("メイン", "候補", "履歴"), tab, ::selectTab)
                if (tab != 2) {
                    CardSearchToolbar(
                        value = query, onValueChange = { query = it }, scope = queryScope, onScopeChange = { queryScope = it },
                        sort = deck?.cardSortMode ?: "REGISTERED", sortOptions = DeckCardSorting.labels.toList(),
                        onSortChange = { vm.setDeckSort(deckId, it) }, placeholder = "デッキ内検索",
                        groupByCategory = deck?.groupByCategory ?: true, groupingEnabled = category == "すべて",
                        onGroupByCategoryChange = { vm.setDeckGrouping(deckId, it) },
                    )
                    Row(Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        categories.forEach { c ->
                            val count = if (c == "すべて") shownBase.sumOf { it.quantity } else shownBase.filter { displayCategory(it) == c }.sumOf { it.quantity }
                            DeckroomFilterChip(selected = c == category, onClick = { category = c }, label = { Text(if (c == "すべて" && tab == 0) "$c ($mainDeckCount/100)" else "$c ($count)") })
                        }
                    }
                }
                }
            }
            HorizontalDivider()
            val swipeThreshold = with(LocalDensity.current) { 56.dp.toPx() }
            Box(Modifier.weight(1f).fillMaxWidth().clipToBounds().pointerInput(tab, category, categories) {
                if (tab != 2) {
                    var distance = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { distance = 0f },
                        onHorizontalDrag = { change, amount -> change.consume(); distance += amount },
                        onDragCancel = { distance = 0f },
                        onDragEnd = {
                            if (kotlin.math.abs(distance) >= swipeThreshold) {
                                val next = (categories.indexOf(category) + if (distance < 0) 1 else -1).coerceIn(0, categories.lastIndex)
                                category = categories[next]
                                headerCollapsed = false
                            }
                            distance = 0f
                        },
                    )
                }
            }) {
                Box(Modifier.fillMaxSize().graphicsLayer {
                    alpha = categoryTransition.value
                    translationX = (1f - categoryTransition.value) * categorySlideDistance * categorySlideDirection
                }) {
                val page = tab
                if (page == 2) {
                    ChangeLogList(logs)
                } else {
                    val pageBase = if (page == 1) candidateCards else mainCards
                    val pageFiltered = DeckCardSorting.sort(pageBase.filter(::matches), deck?.cardSortMode ?: "REGISTERED", grouped)
                    if (grid) {
                        val gridState = if (page == 1) candidateGridState else mainGridState
                        Box(Modifier.fillMaxSize()) {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(136.dp), state = gridState,
                                modifier = Modifier.fillMaxSize().padding(end = 12.dp),
                                contentPadding = PaddingValues(8.dp, 8.dp, 8.dp, 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                items(pageFiltered.size, key = { pageFiltered[it].id }) { idx ->
                                    val c = pageFiltered[idx]
                                    val checked = c.id in selectedIds
                                    CardThumb(c, fallbackImagePath = vm.deckPreferredImagePath(c), selected = checked,
                                        onLongClick = { selectedIds = if (checked) selectedIds - c.id else selectedIds + c.id },
                                        onClick = { if (selectedIds.isNotEmpty()) selectedIds = if (checked) selectedIds - c.id else selectedIds + c.id else selected = c })
                                }
                            }
                            VerticalFastScrollbar(gridState)
                        }
                    } else {
                        val listState = if (page == 1) candidateListState else mainListState
                        Box(Modifier.fillMaxSize()) {
                            LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
                                val sections = if (grouped) pageFiltered.groupBy(::displayCategory) else linkedMapOf("" to pageFiltered)
                                sections.forEach { (cat, list) ->
                                    if (grouped) item(key = "header-$page-$cat") { Text(cat, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(16.dp, 14.dp, 16.dp, 4.dp)) }
                                    items(list, key = { it.id }) { card ->
                                        val checked = card.id in selectedIds
                                        CardRow(card, fallbackImagePath = vm.deckPreferredImagePath(card), selected = checked,
                                            onLongClick = { selectedIds = if (checked) selectedIds - card.id else selectedIds + card.id },
                                            onClick = { if (selectedIds.isNotEmpty()) selectedIds = if (checked) selectedIds - card.id else selectedIds + card.id else selected = card })
                                    }
                                }
                            }
                            VerticalFastScrollbar(listState)
                        }
                    }
                }
                }
            }
            if (packProgress.active) LinearProgressIndicator(progress = { packProgress.fraction }, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().height(3.dp))
            if (mediumProgress.active) LinearProgressIndicator(progress = { mediumProgress.fraction }, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth().height(3.dp))
        }
    }

    if (imageStatusOpen) DeckLoomAlertDialog(
        onDismissRequest = { imageStatusOpen = false }, title = { Text("画像の取得状態") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("取得済み $ready / ${cards.size}枚 · 未取得 ${missing}枚")
            progress?.let { Text("取得中 ${it.first}/${it.second}") }
            if (errors.isNotEmpty()) Text(errors.take(5).joinToString("\n") { "${it.displayName.ifBlank { it.inputName }}：${it.errorMessage}" }, style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { DeckroomTextButton(onClick = { vm.retryMissingImages(deckId); imageStatusOpen = false; vm.showNotice("未取得・エラーを再取得します") }) { Text("再取得") } },
        dismissButton = { DeckroomTextButton(onClick = { imageStatusOpen = false }) { Text("閉じる") } },
    )
    if (deckStatusOpen) DeckLoomAlertDialog(
        onDismissRequest = { deckStatusOpen = false }, title = { Text("デッキの状態") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("メイン $mainDeckCount/100枚 · 候補 ${candidateCards.sumOf { it.quantity }}枚")
            Text(if (validation.duplicateWarnings.isEmpty()) "枚数制限に違反する重複はありません" else validation.duplicateWarnings.joinToString("\n"))
            if (errors.isNotEmpty()) Text("未解決・取得エラー ${errors.size}枚（更新アイコンから詳細を確認）")
        } },
        confirmButton = { DeckroomTextButton(onClick = { deckStatusOpen = false }) { Text("閉じる") } },
    )

    selected?.let { card ->
        val current = cards.firstOrNull { it.id == card.id } ?: card
        CardDetailDialog(
            current,
            onDismiss = { selected = null },
            fallbackImagePath = vm.deckPreferredImagePath(current),
            onSave = { quantity, category, role, special, done, error -> vm.saveCardEdits(deckId, current.id, quantity, category, role, special, done, error) },
            categoryOptions = cards.map { it.userCategory }.filter { it.isNotBlank() }.distinct().sorted(),
            onDelete = { vm.deleteCard(deckId, current) },
            onChangePrinting = {
                printingFor = current; printingLoading = true
                vm.loadPrintingOptions(current, onDone = { printingOptions = it; printingLoading = false }, onError = { printingLoading = false; vm.showNotice(it) })
            },
            onRetryName = { newName ->
                vm.retryCardWithName(deckId, current, newName,
                    onDone = { vm.showNotice("再照合しました") },
                    onError = vm::showNotice)
            },
        )
    }

    if (categoryBatch) {
        var name by remember { mutableStateOf("") }
        var expanded by remember { mutableStateOf(false) }
        var saving by remember { mutableStateOf(false) }
        DeckLoomAlertDialog(onDismissRequest = { if (!saving) categoryBatch = false }, title = { Text("${selectedIds.size}枚のカテゴリ") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DeckroomTextField(name, { name = it }, label = { Text("ユーザーカテゴリ") }, placeholder = { Text("空欄で自動分類に戻す") }, singleLine = true)
                Box { DeckroomTextButton(onClick = { expanded = true }) { Text("既存カテゴリから選択") }; DropdownMenu(expanded, { expanded = false }) {
                    DropdownMenuItem(text = { Text("自動分類に戻す") }, onClick = { name = ""; expanded = false })
                    cards.map { it.userCategory }.filter { it.isNotBlank() }.distinct().sorted().forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { name = c; expanded = false }) }
                } }
            }
        }, confirmButton = { DeckroomButton(enabled = !saving, onClick = { saving = true; vm.updateCategories(selectedIds.toList(), name, onDone = { selectedIds = emptySet(); categoryBatch = false }, onError = { saving = false; vm.showNotice(it) }) }) { Text("適用") } }, dismissButton = { DeckroomTextButton(enabled = !saving, onClick = { categoryBatch = false }) { Text("閉じる") } })
    }

    printingFor?.let { card ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { printingFor = null }) {
            Surface(Modifier.fillMaxWidth().fillMaxHeight(0.9f), shape = MaterialTheme.shapes.large) {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("絵柄 / 印刷版", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    }
                    if (printingLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    val state = rememberLazyListState()
                    LazyColumn(state = state, modifier = Modifier.weight(1f)) {
                        items(printingOptions, key = { it.scryfallId }) { option ->
                            var thumbPath by remember(option.scryfallId) { mutableStateOf("") }
                            LaunchedEffect(option.scryfallId) { vm.loadPrintingThumbnail(option) { thumbPath = it } }
                            DeckroomListItem(
                                modifier = Modifier.clickable {
                                    vm.selectPrinting(deckId, card, option, onDone = { vm.showNotice("絵柄を変更しました"); printingFor = null }, onError = vm::showNotice)
                                },
                                leadingContent = {
                                    if (thumbPath.isNotBlank()) AsyncImage(model = File(thumbPath), contentDescription = option.label, modifier = Modifier.width(54.dp).height(76.dp), contentScale = ContentScale.Fit)
                                    else Box(Modifier.width(54.dp).height(76.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) }
                                },
                                headlineContent = { Text(option.label, maxLines = 2) },
                                supportingContent = { Text(option.releasedAt) },
                            )
                            HorizontalDivider()
                        }
                    }
                    HorizontalDivider()
                    DialogCloseRow(onClose = { printingFor = null })
                }
            }
        }
    }

    if (addDialog) {
        var addError by remember { mutableStateOf("") }
        var adding by remember { mutableStateOf(false) }
        AddCardsDialog(
            vm = vm,
            defaultRole = if (tab == 1) DeckRoles.CANDIDATE else DeckRoles.MAIN,
            error = addError, adding = adding,
            onDismiss = { if (!adding) addDialog = false },
            onAddOne = { name, quantity, role ->
                adding = true; addError = ""
                vm.addSingleCard(deckId, name, quantity, commander = role == DeckRoles.COMMANDER, role = role,
                    onDone = { addDialog = false }, onError = { adding = false; addError = it })
            },
            onAddBulk = { text, role ->
                adding = true; addError = ""
                vm.addCards(deckId, text, role, onDone = { addDialog = false }, onError = { adding = false; addError = it })
            },
        )
    }

    if (renameDialog) {
        var newName by remember(deck?.name) { mutableStateOf(deck?.name.orEmpty()) }
        DeckLoomAlertDialog(
            onDismissRequest = { renameDialog = false },
            title = { Text("デッキ名を変更") },
            text = { DeckroomTextField(newName, { newName = it }, label = { Text("デッキ名") }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { DeckroomButton(onClick = {
                vm.renameDeck(deckId, newName, onDone = { renameDialog = false; vm.showNotice("デッキ名を変更しました") }, onError = vm::showNotice)
            }, enabled = newName.isNotBlank()) { Text("変更") } },
            dismissButton = { DeckroomTextButton(onClick = { renameDialog = false }) { Text("キャンセル") } },
        )
    }

    if (deleteDeckDialog) {
        DeckLoomAlertDialog(
            onDismissRequest = { deleteDeckDialog = false },
            title = { Text("デッキを削除") },
            text = { Text("「${deck?.name.orEmpty()}」を削除します。この操作は元に戻せません。") },
            confirmButton = { DeckroomButton(onClick = {
                vm.deleteDeck(deckId, onDone = { deleteDeckDialog = false; onBack() }, onError = vm::showNotice)
            }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("削除") } },
            dismissButton = { DeckroomTextButton(onClick = { deleteDeckDialog = false }) { Text("キャンセル") } },
        )
    }

    if (playWarning) {
        DeckLoomAlertDialog(
            onDismissRequest = { playWarning = false },
            title = { Text("デッキ枚数/構築警告") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("現在 ${mainDeckCount}枚です。統率者戦の通常デッキは100枚です。")
                    validation.duplicateWarnings.take(8).forEach { Text("⚠ $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = { DeckroomButton(onClick = { playWarning = false; onPlay() }) { Text("そのまま一人回し") } },
            dismissButton = { DeckroomTextButton(onClick = { playWarning = false }) { Text("戻る") } },
        )
    }
}

@Composable
private fun ChangeLogList(logs: List<jp.deckloom.app.data.DeckChangeLogEntity>) {
    if (logs.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("変更履歴はまだありません") }
        return
    }
    val fmt = remember { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()) }
    val listState = rememberLazyListState()
    Box(Modifier.fillMaxSize()) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize().padding(end = 12.dp)) {
            items(logs, key = { it.id }) { log ->
                val cardTitle = when {
                    log.cardName.isNotBlank() -> log.cardName
                    log.action == "IMPORT" -> "初回インポート"
                    log.action == "COPY" -> "デッキコピー"
                    else -> log.note.ifBlank { log.action }
                }
                val roleText = when {
                    log.fromRole.isNotBlank() && log.toRole.isNotBlank() && log.fromRole != log.toRole ->
                        "${roleLabel(log.fromRole)}→${roleLabel(log.toRole)}"
                    log.toRole.isNotBlank() -> roleLabel(log.toRole)
                    log.fromRole.isNotBlank() -> roleLabel(log.fromRole)
                    else -> ""
                }
                val quantityChange = log.note.takeIf { Regex("""^\d+→\d+$""").matches(it) }
                    ?: when (log.action) {
                        "ADD" -> if (log.quantity > 0) "?→+${log.quantity}" else ""
                        "REMOVE" -> if (log.quantity > 0) "?→-${log.quantity}" else ""
                        else -> ""
                    }
                DeckroomListItem(
                    headlineContent = { Text(cardTitle, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = {
                        Text(buildString {
                            append(fmt.format(Date(log.createdAt)))
                            if (roleText.isNotBlank()) append("  ").append(roleText)
                            if (quantityChange.isNotBlank()) append("  ").append(quantityChange)
                            if (log.note.isNotBlank() && quantityChange == null && log.cardName.isNotBlank()) append("  ").append(log.note)
                        })
                    },
                )
                HorizontalDivider()
            }
        }
        VerticalFastScrollbar(listState)
    }
}

@Composable
private fun AddCardsDialog(
    vm: AppViewModel,
    defaultRole: String,
    error: String,
    adding: Boolean,
    onDismiss: () -> Unit,
    onAddOne: (String, Int, String) -> Unit,
    onAddBulk: (String, String) -> Unit,
) {
    var bulk by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(1) }
    var role by remember(defaultRole) { mutableStateOf(defaultRole) }

    DeckLoomAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (bulk) "一括追加" else "カードを1枚ずつ追加") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!bulk) {
                    CardNameSearchField(vm = vm, value = text, onValueChange = { text = it }, onChosen = { text = it.oracleName.ifBlank { it.displayName } })
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("枚数"); DeckroomOutlinedButton(onClick = { quantity = (quantity - 1).coerceAtLeast(1) }) { Text("−") }; Text(quantity.toString(), style = MaterialTheme.typography.titleMedium); DeckroomOutlinedButton(onClick = { quantity++ }) { Text("＋") }
                    }
                    RoleChoice(role) { role = it }
                    DeckroomTextButton(onClick = { bulk = true; text = "" }, modifier = Modifier.fillMaxWidth()) { Text("一括追加へ切り替え →") }
                } else {
                    Text("複数行を貼り付け。同名カードは既存の枚数へ加算します。日本語・英語どちらも可。正確なカード名を推奨します。")
                    DeckroomTextField(value = text, onValueChange = { text = it }, minLines = 5, maxLines = 12, modifier = Modifier.fillMaxWidth(), placeholder = { Text("1 Life from the Loam\n2 Forest") })
                    RoleChoice(role) { role = it }
                    DeckroomTextButton(onClick = { bulk = false; text = "" }, modifier = Modifier.fillMaxWidth()) { Text("← 1枚追加へ戻る") }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                if (adding) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        },
        confirmButton = { DeckroomButton(onClick = { if (bulk) onAddBulk(text, role) else onAddOne(text, quantity, role) }, enabled = text.isNotBlank() && !adding) { Text("追加") } },
        dismissButton = { DeckroomTextButton(onClick = onDismiss, enabled = !adding) { Text("閉じる") } },
    )
}

@Composable
private fun RoleChoice(role: String, onRole: (String) -> Unit) {
    Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(DeckRoles.MAIN, DeckRoles.CANDIDATE, DeckRoles.COMMANDER, DeckRoles.SECOND_COMMANDER, DeckRoles.COMPANION).forEach { r ->
            DeckroomFilterChip(selected = role == r, onClick = { onRole(r) }, label = { Text(roleLabel(r)) })
        }
    }
}

private fun deckSearchKey(value: String): String = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFKC).replace(Regex("[（(][ぁ-んァ-ヶー]+[）)]"), "").replace(Regex("\\s+"), " ").trim()
