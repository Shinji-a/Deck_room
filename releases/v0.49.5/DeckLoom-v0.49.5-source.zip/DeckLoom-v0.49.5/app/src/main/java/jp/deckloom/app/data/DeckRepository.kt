package jp.deckloom.app.data

import android.content.Context
import android.net.ConnectivityManager
import androidx.room.withTransaction
import jp.deckloom.app.network.CardImageStore
import jp.deckloom.app.network.ScryfallClient
import jp.deckloom.app.network.SmallImagePackStore
import jp.deckloom.app.network.MediumImagePackStore
import jp.deckloom.app.network.ImagePackProgress
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock


data class DeckListCheck(
    val parsedCards: Int,
    val matchedCards: Int,
    val unresolvedNames: List<String>,
)

data class DeckValidation(
    val mainDeckCount: Int,
    val candidateCount: Int,
    val duplicateWarnings: List<String>,
) {
    val exactHundred: Boolean get() = mainDeckCount == 100
}

class DeckRepository(
    private val context: Context,
    private val db: AppDatabase,
    private val scryfall: ScryfallClient,
    private val imageStore: CardImageStore,
    private val smallImagePack: SmallImagePackStore,
    private val mediumImagePack: MediumImagePackStore,
    private val cardIndex: CardIndexStore,
    private val settingsStore: AppSettingsStore,
) {
    private val dao = db.deckDao()
    private val imageLocks = Array(16) { Mutex() }
    private val resolvedImages = android.util.LruCache<String, ScryfallClient.ResolvedCard>(80)
    private val prefs = context.getSharedPreferences("deckloom", Context.MODE_PRIVATE)
    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    val settings = settingsStore.settings
    val imagePackProgress = smallImagePack.progress
    val mediumImagePackProgress = mediumImagePack.progress

    val decks: Flow<List<DeckEntity>> = dao.observeDecks()
    val folders = dao.observeFolders()
    val homeDecks: Flow<List<DeckWithCards>> = combine(decks, dao.observeAllCards()) { items, cards ->
        val grouped = cards.groupBy { it.deckId }
        items.map { DeckWithCards(it, grouped[it.id].orEmpty()) }
    }
    val searchCardCount: Flow<Int> = dao.observeSearchCardCount()
    val savedSearches: Flow<List<SavedSearchEntity>> = dao.observeSavedSearches()

    fun observeDeck(deckId: Long): Flow<DeckWithCards?> = combine(
        dao.observeDeck(deckId),
        dao.observeCards(deckId),
    ) { deck, cards -> deck?.let { DeckWithCards(it, cards) } }

    fun observeLogs(deckId: Long): Flow<List<DeckChangeLogEntity>> = dao.observeLogs(deckId)

    suspend fun getCards(deckId: Long): List<DeckCardEntity> = dao.getCards(deckId)
    suspend fun getPlaytestCards(deckId: Long): List<DeckCardEntity> = dao.getCards(deckId).filter { DeckRoles.countsTowardDeck(it.deckRole) }.map { card ->
        if (card.imagePath.isNotBlank() && File(card.imagePath).exists()) card
        else card.copy(imagePath = preferredPackImagePath(card.selectedPrintingId.ifBlank { card.scryfallId }, if (card.selectedPrintingId.isBlank()) card.oracleId else ""))
    }

    suspend fun createDeck(name: String): Long = db.withTransaction {
        dao.insertDeck(DeckEntity(name = name.ifBlank { "新しいデッキ" }, sortOrder = (dao.getDecks().minOfOrNull { it.sortOrder } ?: 0) - 1))
    }

    suspend fun createFolder(name: String, parentId: Long? = null): Long = db.withTransaction {
        require(name.trim().isNotEmpty()) { "フォルダ名を入力してください" }
        require(parentId == null || dao.getFolder(parentId) != null) { "親フォルダが見つかりません" }
        val order = (dao.getFolders().filter { it.parentId == parentId }.maxOfOrNull { it.sortOrder } ?: -1) + 1
        dao.insertFolder(DeckFolderEntity(name = name.trim(), parentId = parentId, sortOrder = order))
    }

    suspend fun renameFolder(id: Long, name: String) {
        require(name.trim().isNotEmpty()) { "フォルダ名を入力してください" }
        val folder = dao.getFolder(id) ?: return
        dao.updateFolder(folder.copy(name = name.trim()))
    }

    suspend fun deleteFolder(id: Long) = db.withTransaction {
        val folder = dao.getFolder(id) ?: return@withTransaction
        // Reparent contents before deleting. No deck, card, note or history is deleted.
        val folders = dao.getFolders()
        var folderOrder = (folders.filter { it.parentId == folder.parentId }.maxOfOrNull { it.sortOrder } ?: -1) + 1
        folders.filter { it.parentId == id }.forEach {
            dao.updateFolder(it.copy(parentId = folder.parentId, sortOrder = folderOrder++))
        }
        val decks = dao.getDecks()
        var deckOrder = (decks.filter { it.folderId == folder.parentId }.maxOfOrNull { it.sortOrder } ?: -1) + 1
        decks.filter { it.folderId == id }.forEach {
            dao.updateDeck(it.copy(folderId = folder.parentId, sortOrder = deckOrder++))
        }
        dao.deleteFolder(id)
    }

    suspend fun moveFolder(id: Long, parentId: Long?) = db.withTransaction {
        val folders = dao.getFolders()
        require(FolderTree.canMove(id, parentId, folders)) { "自分自身や子フォルダへは移動できません" }
        val folder = folders.first { it.id == id }
        if (folder.parentId == parentId) return@withTransaction
        val order = (folders.filter { it.parentId == parentId }.maxOfOrNull { it.sortOrder } ?: -1) + 1
        dao.updateFolder(folder.copy(parentId = parentId, sortOrder = order))
    }

    suspend fun reorderFolder(id: Long, direction: Int) = db.withTransaction {
        val folder = dao.getFolder(id) ?: return@withTransaction
        val siblings = dao.getFolders().filter { it.parentId == folder.parentId }.toMutableList()
        val from = siblings.indexOfFirst { it.id == id }
        val to = from + direction.coerceIn(-1, 1)
        if (from < 0 || to !in siblings.indices) return@withTransaction
        java.util.Collections.swap(siblings, from, to)
        siblings.forEachIndexed { index, item -> dao.updateFolder(item.copy(sortOrder = index.toLong())) }
    }

    suspend fun organizeDeck(id: Long, folderId: Long?, note: String) = db.withTransaction {
        val deck = dao.getDeck(id) ?: return@withTransaction
        require(folderId == null || dao.getFolder(folderId) != null) { "フォルダが見つかりません" }
        val order = if (deck.folderId == folderId) deck.sortOrder else (dao.getDecks().filter { it.folderId == folderId }.maxOfOrNull { it.sortOrder } ?: -1) + 1
        dao.updateDeck(deck.copy(folderId = folderId, note = note.trim(), sortOrder = order))
    }

    suspend fun reorderDeck(id: Long, direction: Int) = db.withTransaction {
        val deck = dao.getDeck(id) ?: return@withTransaction
        val siblings = dao.getDecks().filter { it.folderId == deck.folderId }.toMutableList()
        val from = siblings.indexOfFirst { it.id == id }
        val to = from + direction.coerceIn(-1, 1)
        if (from < 0 || to !in siblings.indices) return@withTransaction
        java.util.Collections.swap(siblings, from, to)
        siblings.forEachIndexed { index, item -> dao.updateDeck(item.copy(sortOrder = index.toLong())) }
    }

    suspend fun setDeckGrouping(id: Long, grouped: Boolean) = dao.updateDeckGrouping(id, grouped)

    suspend fun <T> editWithUndo(deckId: Long, block: suspend () -> T): Pair<T, DeckUndo?> = db.withTransaction {
        val before = dao.getCards(deckId)
        val value = block()
        val after = dao.getCards(deckId)
        val old = before.associateBy { it.id }; val now = after.associateBy { it.id }
        val changed = (old.keys + now.keys).filter { !DeckEditFields.same(old[it], now[it]) }.toSet()
        value to if (changed.isEmpty()) null else DeckUndo(deckId, before.filter { it.id in changed }, after.filter { it.id in changed })
    }

    suspend fun undo(edit: DeckUndo) = db.withTransaction {
        require(dao.getDeck(edit.deckId) != null) { "デッキが見つかりません" }
        val expected = edit.after.associateBy { it.id }
        val original = edit.before.associateBy { it.id }
        val current = dao.getCards(edit.deckId).associateBy { it.id }
        val ids = expected.keys + original.keys
        require(ids.all { DeckEditFields.same(expected[it], current[it]) }) { "その後に編集されたため取り消せません" }
        val proposed = current.values.filter { it.id !in ids } + original.values
        // Restoring old data must never silently remove a later card or exceed a newly used slot.
        enforceCopies(current.values.toList(), proposed)
        for (id in ids) {
            val old = original[id]; val now = current[id]
            when {
                old == null && now != null -> dao.deleteCard(now)
                old != null && now == null -> dao.insertCards(listOf(old))
                old != null && now != null -> dao.updateCard(DeckEditFields.restore(old, now))
            }
        }
        log(edit.deckId, "UNDO", note = "直前のカード編集を取り消しました")
    }

    private suspend fun copyRule(card: DeckCardEntity, cache: MutableMap<String, CardIndexRecord?> = mutableMapOf()): CopyRuleCard {
        val lookupKey = card.oracleId.ifBlank { normalizeName(card.oracleName.ifBlank { card.inputName }) }
        val record = cache.getOrPut(lookupKey) {
            if (card.oracleId.isNotBlank()) cardIndex.byOracleId(card.oracleId)
            else findLocalRecord(card.oracleName.ifBlank { card.inputName })
        }
        val key = record?.oracleId?.takeIf { it.isNotBlank() } ?: card.oracleId.takeIf { it.isNotBlank() }
            ?: normalizeName(card.oracleName.ifBlank { card.inputName })
        val basic = record?.isBasicLand == true || card.oracleTypeLine.split(' ').any { it.equals("Basic", true) }
        val limit = if (basic) -1 else record?.copyLimit
        return CopyRuleCard(key, card.displayName.ifBlank { card.inputName }, card.quantity, DeckRoles.countsTowardDeck(card.deckRole), limit)
    }

    private suspend fun enforceCopies(before: List<DeckCardEntity>, after: List<DeckCardEntity>) {
        val cache = mutableMapOf<String, CardIndexRecord?>()
        val violations = DeckCopyRules.violations(before.map { copyRule(it, cache) }, after.map { copyRule(it, cache) })
        require(violations.isEmpty()) { violations.take(5).joinToString("\n") }
    }

    suspend fun unknownCopyRules(deckId: Long): Int = dao.getCards(deckId).count { copyRule(it).let { r -> r.active && r.limit == null } }

    private fun nextAddedAt(cards: List<DeckCardEntity>): Long = maxOf(System.currentTimeMillis(), (cards.maxOfOrNull { it.addedAt } ?: 0L) + 1L)

    suspend fun setDeckSort(id: Long, mode: String) {
        if (mode in DeckCardSorting.labels) dao.updateDeckSort(id, mode)
    }

    suspend fun saveCardEdits(id: Long, quantity: Int, category: String, role: String, specialRole: String) = db.withTransaction {
        val current = dao.getCard(id) ?: error("カードが見つかりません")
        require(quantity > 0) { "枚数は1以上にしてください" }
        require(role in setOf(DeckRoles.MAIN, DeckRoles.CANDIDATE))
        require(specialRole in setOf(DeckSpecialRoles.NONE, DeckSpecialRoles.COMMANDER, DeckSpecialRoles.COMPANION_BACKGROUND))
        val actualSpecial = if (role == DeckRoles.CANDIDATE) DeckSpecialRoles.NONE else specialRole
        val cards = dao.getCards(current.deckId)
        val updated = current.copy(quantity = quantity, userCategory = category.trim(), deckRole = role, specialRole = actualSpecial, isCommander = actualSpecial == DeckSpecialRoles.COMMANDER,
            addedAt = if (current.deckRole == DeckRoles.CANDIDATE && role == DeckRoles.MAIN) nextAddedAt(cards) else current.addedAt)
        enforceCopies(cards, cards.filter { it.id != id } + updated)
        if (actualSpecial == DeckSpecialRoles.COMMANDER) dao.clearCommander(current.deckId)
        dao.updateCard(updated)
        log(current.deckId, "EDIT", current.displayName.ifBlank { current.inputName }, quantity, current.deckRole, role, "枚数 ${current.quantity}→$quantity / カテゴリ ${category.ifBlank { "自動分類" }}")
    }

    suspend fun updateCategories(ids: List<Long>, category: String) = dao.updateCategories(ids, category.trim())

    suspend fun renameDeck(deckId: Long, name: String) {
        val deck = dao.getDeck(deckId) ?: error("デッキが見つかりません")
        val clean = name.trim()
        require(clean.isNotBlank()) { "デッキ名を入力してください" }
        dao.updateDeck(deck.copy(name = clean))
        log(deckId, "RENAME", note = "${deck.name} → $clean")
    }

    suspend fun importDeck(name: String, rawList: String): Long {
        val parsed = canonicalize(DeckListParser.parse(rawList))
        require(parsed.isNotEmpty()) { "カード行を読み取れませんでした" }
        return db.withTransaction {
            val deckId = createDeck(name)
            parsed.forEach { line -> addOrIncrement(deckId, line.name, line.quantity, if (line.isCommander) DeckRoles.COMMANDER else DeckRoles.MAIN, line.category) }
            log(deckId, "IMPORT", note = "Initial import - ${parsed.sumOf { it.quantity }} cards")
            deckId
        }
    }

    suspend fun copyDeck(deckId: Long): Long {
        val source = dao.getDeck(deckId) ?: error("デッキが見つかりません")
        val cards = dao.getCards(deckId)
        val newId = dao.insertDeck(source.copy(id = 0, name = "${source.name} - Copy", createdAt = System.currentTimeMillis(), sortOrder = (dao.getDecks().minOfOrNull { it.sortOrder } ?: 0) - 1))
        if (cards.isNotEmpty()) {
            dao.insertCards(cards.map { it.copy(id = 0, deckId = newId) })
        }
        log(newId, "COPY", note = "Created as copy of \"${source.name}\"")
        return newId
    }

    suspend fun addCards(deckId: Long, rawList: String, role: String = DeckRoles.MAIN): Int {
        val normalized = rawList.lineSequence().joinToString("\n") { raw ->
            val line = raw.trim()
            if (line.isBlank() || line.firstOrNull()?.isDigit() == true) line else "1 $line"
        }
        val parsed = canonicalize(DeckListParser.parse(normalized))
        require(parsed.isNotEmpty()) { "カード名を読み取れませんでした" }
        return db.withTransaction {
        var added = 0
        parsed.forEach { line ->
            added += addOrIncrement(deckId, line.name, line.quantity, role = if (line.isCommander) DeckRoles.COMMANDER else role, category = line.category)
        }
        added
        }
    }

    suspend fun addSingleCard(
        deckId: Long,
        name: String,
        quantity: Int = 1,
        commander: Boolean = false,
        role: String = if (commander) DeckRoles.COMMANDER else DeckRoles.MAIN,
    ): Int {
        val clean = name.trim()
        require(clean.isNotBlank()) { "カード名を入力してください" }
        val canonical = canonicalize(listOf(ParsedDeckLine(1, clean, "未分類", false))).first().name
        return addOrIncrement(deckId, canonical, quantity.coerceAtLeast(1), role = if (commander) DeckRoles.COMMANDER else role)
    }

    suspend fun addIndexCards(deckId: Long, records: List<CardIndexRecord>, role: String): Int {
        return db.withTransaction {
            var total = 0
            records.forEach { total += addOrIncrement(deckId, it.englishName, 1, role = role, indexRecord = it) }
            total
        }
    }

    private suspend fun addOrIncrement(
        deckId: Long,
        name: String,
        quantity: Int,
        role: String,
        category: String = "未分類",
        indexRecord: CardIndexRecord? = null,
    ): Int = db.withTransaction {
        val locationRole = if (role == DeckRoles.CANDIDATE) DeckRoles.CANDIDATE else DeckRoles.MAIN
        val specialRole = when (role) {
            DeckRoles.COMMANDER -> DeckSpecialRoles.COMMANDER
            DeckRoles.SECOND_COMMANDER, DeckRoles.COMPANION -> DeckSpecialRoles.COMPANION_BACKGROUND
            else -> DeckSpecialRoles.NONE
        }
        val cards = dao.getCards(deckId)
        val record = indexRecord ?: cardIndex.byOracleName(name)
        val normalized = normalizeName(name)
        val existing = cards.firstOrNull { card ->
            card.deckRole == locationRole && ((record != null && record.oracleId.isNotBlank() && card.oracleId == record.oracleId) || listOf(card.oracleName, card.inputName, card.displayName).any { normalizeName(it) == normalized })
        }
        if (existing != null) {
            val updated = existing.copy(
                quantity = existing.quantity + quantity,
                deckRole = locationRole,
                specialRole = if (specialRole != DeckSpecialRoles.NONE) specialRole else existing.specialRole,
                isCommander = specialRole == DeckSpecialRoles.COMMANDER || existing.specialRole == DeckSpecialRoles.COMMANDER,
                category = existing.category,
            )
            enforceCopies(cards, cards.filter { it.id != existing.id } + updated)
            if (specialRole == DeckSpecialRoles.COMMANDER) dao.clearCommander(deckId)
            dao.updateCard(updated)
            log(deckId, "ADD", updated.displayName.ifBlank { name }, quantity, fromRole = role, toRole = role, note = "${existing.quantity}→${updated.quantity}")
            return@withTransaction quantity
        }

        val entity = if (record != null) {
            DeckCardEntity(
                deckId = deckId,
                quantity = quantity,
                inputName = record.englishName,
                oracleName = record.englishName,
                oracleId = record.oracleId,
                displayName = record.displayName,
                printedName = record.japaneseName,
                displayTypeLine = record.displayTypeLine,
                oracleTypeLine = record.englishTypeLine,
                oracleText = record.displayText,
                manaCost = record.manaCost,
                cmc = record.manaValue,
                colorIdentity = record.colorIdentity,
                scryfallId = record.scryfallId,
                category = inferCategory(record.englishTypeLine),
                userCategory = CardCategories.imported(category),
                isCommander = specialRole == DeckSpecialRoles.COMMANDER,
                deckRole = locationRole,
                specialRole = specialRole,
                cacheState = "PENDING",
            )
        } else {
            DeckCardEntity(
                deckId = deckId,
                quantity = quantity,
                inputName = name,
                displayName = name,
                category = category,
                userCategory = CardCategories.imported(category),
                isCommander = specialRole == DeckSpecialRoles.COMMANDER,
                deckRole = locationRole,
                specialRole = specialRole,
            )
        }
        enforceCopies(cards, cards + entity)
        if (specialRole == DeckSpecialRoles.COMMANDER) dao.clearCommander(deckId)
        val id = dao.insertCards(listOf(entity.copy(addedAt = nextAddedAt(cards)))).firstOrNull()
        if (specialRole == DeckSpecialRoles.COMMANDER && id != null) dao.setCommander(id)
        log(deckId, "ADD", entity.displayName.ifBlank { name }, quantity, fromRole = role, toRole = role, note = "0→${entity.quantity}")
        quantity
    }

    suspend fun adjustQuantity(card: DeckCardEntity, delta: Int) = db.withTransaction {
        val current = dao.getCard(card.id) ?: return@withTransaction
        if (delta == 0) return@withTransaction
        val next = current.quantity + delta
        if (next <= 0) deleteCard(current)
        else saveCardEdits(current.id, next, current.userCategory, current.deckRole, current.specialRole)
    }

    suspend fun moveRole(card: DeckCardEntity, role: String) = db.withTransaction {
        val current = dao.getCard(card.id) ?: return@withTransaction
        val location = if (role == DeckRoles.CANDIDATE) DeckRoles.CANDIDATE else DeckRoles.MAIN
        if (current.deckRole != location) saveCardEdits(current.id, current.quantity, current.userCategory, location, current.specialRole)
    }

    suspend fun setSpecialRole(card: DeckCardEntity, specialRole: String) = db.withTransaction {
        val current = dao.getCard(card.id) ?: return@withTransaction
        saveCardEdits(current.id, current.quantity, current.userCategory, DeckRoles.MAIN, specialRole)
    }

    suspend fun moveCards(ids: List<Long>, role: String) = db.withTransaction {
        ids.forEach { id -> dao.getCard(id)?.let { moveRole(it, role) } }
    }
    suspend fun deleteCards(ids: List<Long>) = db.withTransaction {
        ids.forEach { id -> dao.getCard(id)?.let { deleteCard(it) } }
    }

    suspend fun searchCardNames(query: String, limit: Int = 20): List<CardSearchEntity> {
        val fromIndex = runCatching { cardIndex.searchNames(query, limit) }.getOrDefault(emptyList())
        if (fromIndex.isNotEmpty()) return fromIndex
        val key = normalizeName(query)
        if (key.length < 2) return emptyList()
        val current = dao.searchCardNames(key, limit)
        if (current.isNotEmpty()) return current
        val legacyKey = legacyNormalizeName(query)
        return if (legacyKey != key) dao.searchCardNames(legacyKey, limit) else emptyList()
    }

    suspend fun searchCards(filter: CardSearchFilter, limit: Int = 40, offset: Int = 0): List<CardIndexRecord> = cardIndex.search(filter, limit, offset)
    suspend fun searchCardCount(filter: CardSearchFilter): Int = cardIndex.searchCount(filter)
    suspend fun cardFilterOptions(): CardFilterOptions = cardIndex.filterOptions()

    fun smallImagePath(scryfallId: String, face: Int = 0): String = smallImagePack.smallPath(scryfallId, face)
    fun mediumImagePath(scryfallId: String, face: Int = 0): String = mediumImagePack.mediumPath(scryfallId, face)
    fun preferredPackImagePath(scryfallId: String, oracleId: String = "", face: Int = 0, readable: Boolean = true): String {
        val mode = settings.value.imagePreloadMode
        return when (mode) {
            "MEDIUM" -> mediumImagePack.mediumPathByOracleId(oracleId, scryfallId, face).ifBlank { smallImagePack.smallPath(scryfallId, face) }
            "SMALL" -> smallImagePack.smallPath(scryfallId, face)
            else -> ""
        }
    }

    fun hasMediumImage(card: CardIndexRecord): Boolean = settings.value.imagePreloadMode == "MEDIUM" && mediumImagePack.mediumPathByOracleId(card.oracleId, card.scryfallId).isNotBlank()

    fun searchImagePath(card: CardIndexRecord, face: Int = 0): String = if (face == 1) {
        imageStore.cachedPath(card.scryfallId, "search_back")
            .ifBlank { imageStore.cachedPath(card.scryfallId, "back") }
            .ifBlank { preferredPackImagePath(card.scryfallId, card.oracleId, face = 1) }
            .ifBlank { imageStore.cachedPath(card.scryfallId, "search_back_thumb") }
    } else imageStore.cachedPath(card.scryfallId, "search_front")
        .ifBlank { imageStore.cachedPath(card.scryfallId, "front") }
        .ifBlank { preferredPackImagePath(card.scryfallId, card.oracleId) }
        .ifBlank { imageStore.cachedPath(card.scryfallId, "search_thumb") }

    private suspend fun searchImageRecord(card: CardIndexRecord): ScryfallClient.ResolvedCard {
        return resolvedImages.get(card.scryfallId) ?: scryfall.resolveById(card.scryfallId, localize = false).also { resolvedImages.put(card.scryfallId, it) }
    }

    suspend fun searchHasBackFace(card: CardIndexRecord): Boolean {
        if (card.layout !in setOf("transform", "modal_dfc", "double_faced_token", "reversible_card", "art_series")) return false
        if (searchImagePath(card, 1).isNotBlank()) return true
        if (card.scryfallId.isBlank()) return false
        return imageLocks[(card.scryfallId.hashCode() and Int.MAX_VALUE) % imageLocks.size].withLock {
            searchImageRecord(card).backImageUrl.isNotBlank()
        }
    }

    suspend fun cacheSearchThumbnail(card: CardIndexRecord, face: Int = 0): String = imageLocks[(card.scryfallId.hashCode() and Int.MAX_VALUE) % imageLocks.size].withLock {
        val existing = searchImagePath(card, face)
        if (existing.isNotBlank()) return@withLock existing
        if (card.scryfallId.isBlank()) return@withLock ""
        val resolved = searchImageRecord(card)
        val url = if (face == 1) resolved.backThumbnailUrl.ifBlank { resolved.backImageUrl } else resolved.thumbnailUrl.ifBlank { resolved.imageUrl }
        if (url.isBlank()) return@withLock ""
        imageStore.cache(card.scryfallId, url, if (face == 1) "search_back_thumb" else "search_thumb")
    }

    suspend fun cacheSearchCardImage(card: CardIndexRecord, force: Boolean = false, face: Int = 0): String = imageLocks[(card.scryfallId.hashCode() and Int.MAX_VALUE) % imageLocks.size].withLock {
        if (card.scryfallId.isBlank()) return@withLock searchImagePath(card, face)
        val medium = mediumImagePack.mediumPathByOracleId(card.oracleId, card.scryfallId, face)
        if (!force && settings.value.imagePreloadMode == "MEDIUM" && medium.isNotBlank() && !settings.value.normalOverMedium) return@withLock searchImagePath(card, face)
        val suffix = if (face == 1) "back" else "front"
        imageStore.cachedPath(card.scryfallId, "search_$suffix").takeIf { it.isNotBlank() }?.let { return@withLock it }
        imageStore.cachedPath(card.scryfallId, suffix).takeIf { it.isNotBlank() }?.let { return@withLock it }
        val resolved = searchImageRecord(card)
        val url = if (face == 1) resolved.backImageUrl else resolved.imageUrl
        if (url.isBlank()) return@withLock searchImagePath(card, face)
        imageStore.cache(card.scryfallId, url, "search_$suffix")
    }

    fun setNormalOverMedium(enabled: Boolean) = settingsStore.setNormalOverMedium(enabled)
    fun setSearchDisplayMode(mode: String) = settingsStore.setSearchDisplayMode(mode)
    fun setLastSearchGrid(grid: Boolean) = settingsStore.setLastSearchGrid(grid)

    suspend fun saveSearch(filter: CardSearchFilter) {
        if (dao.savedSearchCount() >= 100) dao.deleteOldestSavedSearch()
        dao.insertSavedSearch(SavedSearchEntity(description = filter.description(), filterJson = filter.toJson()))
    }

    suspend fun deleteSavedSearch(id: Long) = dao.deleteSavedSearch(id)

    suspend fun checkDeckList(rawList: String): DeckListCheck {
        val normalized = rawList.lineSequence().joinToString("\n") { raw ->
            val line = raw.trim()
            if (line.isBlank() || line.firstOrNull()?.isDigit() == true) line else "1 $line"
        }
        val parsed = DeckListParser.parse(normalized)
        if (parsed.isEmpty()) return DeckListCheck(0, 0, emptyList())
        val unresolved = mutableListOf<String>()
        var matched = 0
        val keys = parsed.flatMap { nameVariants(it.name) }
            .flatMap { listOf(normalizeName(it), legacyNormalizeName(it)) }.distinct()
        val exactAliases = dao.findExactSearchCards(keys).map { it.normalizedName }.toSet()
        parsed.forEach { line ->
            val variants = nameVariants(line.name)
            val localHit = findLocalRecord(line.name) != null
            val aliasHit = variants.any { normalizeName(it) in exactAliases || legacyNormalizeName(it) in exactAliases }
            if (localHit || aliasHit) matched += line.quantity else unresolved += line.name
        }
        return DeckListCheck(parsed.sumOf { it.quantity }, matched, unresolved.distinct().take(12))
    }

    private var localizedIndexSha: String? = null

    suspend fun checkCardIndex(force: Boolean = false, manual: Boolean = false, onStatus: (CardIndexStatus) -> Unit = {}): CardIndexStatus {
        val blockMetered = settings.value.blockMeteredCardDbDownload
        val allowDownload = manual || !blockMetered || !isActiveNetworkMetered()
        val status = cardIndex.checkAndUpdate(force = force, allowDownload = allowDownload, onStatus = onStatus)
        // Also repairs saved READY cards on the first check after an app update.
        if (status.ready && (force || localizedIndexSha != status.databaseSha256)) {
            refreshSavedLocalizations()
            localizedIndexSha = status.databaseSha256
        }
        return status
    }
    private suspend fun refreshSavedLocalizations() {
        val records = mutableMapOf<String, CardIndexRecord?>()
        for (snapshot in dao.getAllCards()) {
            if (snapshot.oracleId.isBlank()) continue
            val record = if (records.containsKey(snapshot.oracleId)) records[snapshot.oracleId]
                else cardIndex.byOracleId(snapshot.oracleId).also { records[snapshot.oracleId] = it }
            if (record == null) continue
            db.withTransaction {
                val current = dao.getCard(snapshot.id) ?: return@withTransaction
                if (current.oracleId != record.oracleId) return@withTransaction
                val updated = current.withLocalization(record)
                if (updated != current) dao.updateCard(updated)
            }
        }
    }

    fun localCardIndexStatus(): CardIndexStatus = cardIndex.localStatus()
    fun isActiveNetworkMetered(): Boolean = connectivity.isActiveNetworkMetered
    fun setThemeMode(mode: String) = settingsStore.setThemeMode(mode)
    fun setBlockMeteredCardDbDownload(enabled: Boolean) = settingsStore.setBlockMeteredCardDbDownload(enabled)
    fun setImagePreloadMode(mode: String) = settingsStore.setImagePreloadMode(mode)
    suspend fun imageCacheBytes(): Long = imageStore.cacheBytes()
    suspend fun clearImageCache(): Long {
        dao.clearCachedImagePaths()
        return imageStore.clear()
    }
    fun imagePackInstalled(): Boolean = smallImagePack.installed()
    fun mediumImagePackInstalled(): Boolean = mediumImagePack.installed()
    fun imagePackBytes(): Long = smallImagePack.installedBytes()
    fun imagePackImageCount(): Int = smallImagePack.installedImageCount()
    fun imagePackUpdatedAt(): String = smallImagePack.installedBulkUpdatedAt()
    fun mediumImagePackBytes(): Long = mediumImagePack.installedBytes()
    fun mediumImagePackImageCount(): Int = mediumImagePack.installedImageCount()
    fun mediumImagePackUpdatedAt(): String = mediumImagePack.installedBulkUpdatedAt()
    suspend fun downloadImagePack(): Boolean = smallImagePack.downloadFullPack()
    suspend fun downloadMediumImagePack(): Boolean = mediumImagePack.downloadFullPack()
    suspend fun clearImagePack(): Long = smallImagePack.clear()
    suspend fun clearMediumImagePack(): Long = mediumImagePack.clear()
    suspend fun checkImagePackUpdate(): Boolean {
        val block = settings.value.blockMeteredCardDbDownload
        val metered = isActiveNetworkMetered()
        return when (settings.value.imagePreloadMode) {
            "SMALL" -> smallImagePack.checkAndUpdateIfInstalled(block, metered)
            "MEDIUM" -> mediumImagePack.checkAndUpdateIfInstalled(block, metered)
            else -> false
        }
    }
    suspend fun ensureSearchCatalog(force: Boolean = false): Int {
        if (cardIndex.localStatus().ready) return cardIndex.localStatus().uniqueCards
        val existing = dao.searchCardCount()
        val now = System.currentTimeMillis()
        val lastSync = prefs.getLong("search_catalog_synced_at", 0L)
        val stale = now - lastSync > 7L * 24L * 60L * 60L * 1000L
        if (!force && existing > 0 && !stale) return existing
        val names = scryfall.cardNameCatalog()
        if (names.isEmpty()) return existing
        names.chunked(1_000).forEach { chunk ->
            dao.upsertSearchCards(chunk.map { name -> searchEntity(name, name, "en", "scryfall_catalog") })
        }
        prefs.edit().putLong("search_catalog_synced_at", now).apply()
        return dao.searchCardCount()
    }

    suspend fun deleteCard(card: DeckCardEntity) {
        dao.deleteCard(card)
        log(card.deckId, "REMOVE", card.displayName.ifBlank { card.inputName }, card.quantity, fromRole = card.deckRole, toRole = card.deckRole, note = "${card.quantity}→0")
    }

    suspend fun printingOptions(card: DeckCardEntity): List<ScryfallClient.PrintingOption> {
        val id = card.selectedPrintingId.ifBlank { card.scryfallId }
        if (id.isBlank()) return emptyList()
        return scryfall.printings(id)
    }

    suspend fun cachePrintingThumbnail(option: ScryfallClient.PrintingOption): String =
        imageStore.cache(option.scryfallId, option.thumbnailUrl.ifBlank { option.imageUrl }, "printing_thumb")

    suspend fun selectPrinting(card: DeckCardEntity, option: ScryfallClient.PrintingOption) {
        val front = imageStore.cache(option.scryfallId, option.imageUrl, "front")
        val back = if (option.backImageUrl.isNotBlank()) imageStore.cache(option.scryfallId, option.backImageUrl, "back") else ""
        db.withTransaction {
        val current = dao.getCard(card.id) ?: return@withTransaction
        if (current.inputName != card.inputName) return@withTransaction
        dao.updateCard(current.copy(
            selectedPrintingId = option.scryfallId,
            scryfallId = option.scryfallId,
            imagePath = front,
            backImagePath = back,
            cacheState = "READY",
            errorMessage = "",
        ))
        log(card.deckId, "PRINTING", card.displayName.ifBlank { card.inputName }, card.quantity, note = option.label)
        }
    }

    suspend fun retryCardWithName(card: DeckCardEntity, newName: String) {
        val updated = db.withTransaction {
        val card = dao.getCard(card.id) ?: return@withTransaction null
        val clean = newName.trim()
        require(clean.isNotBlank()) { "カード名を入力してください" }
        val updated = card.copy(
            inputName = clean,
            displayName = clean,
            oracleName = "",
            oracleId = "",
            printedName = "",
            displayTypeLine = "",
            oracleTypeLine = "",
            oracleText = "",
            manaCost = "",
            cmc = 0.0,
            colorIdentity = "",
            scryfallId = "",
            selectedPrintingId = "",
            imagePath = "",
            backImagePath = "",
            cacheState = "PENDING",
            errorMessage = "",
        )
        val cards = dao.getCards(card.deckId)
        enforceCopies(cards, cards.filter { it.id != card.id } + updated)
        dao.updateCard(updated)
        log(card.deckId, "RESOLVE_RETRY", clean, card.quantity, fromRole = card.deckRole, toRole = card.deckRole, note = "名前を修正して再照合")
        updated
        } ?: return
        resolveOne(updated)
    }

    suspend fun resolvePending(onProgress: ((done: Int, total: Int) -> Unit)? = null) {
        resolveCards(dao.getUnresolvedCards(), onProgress)
    }

    suspend fun resolveDeck(deckId: Long, onProgress: ((done: Int, total: Int) -> Unit)? = null) {
        resolveCards(dao.getCards(deckId).filter { it.cacheState != "READY" }, onProgress)
    }

    suspend fun refreshMissingImages(deckId: Long, onProgress: ((done: Int, total: Int) -> Unit)? = null) {
        val cards = dao.getCards(deckId).filter { card -> card.cacheState != "READY" || card.imagePath.isBlank() || !File(card.imagePath).exists() }
        cards.forEach { dao.updateCard(it.copy(cacheState = "PENDING", errorMessage = "")) }
        resolveCards(cards.map { it.copy(cacheState = "PENDING", errorMessage = "") }, onProgress)
    }

    private suspend fun resolveCards(cards: List<DeckCardEntity>, onProgress: ((done: Int, total: Int) -> Unit)? = null) {
        val total = cards.size
        cards.forEachIndexed { index, card ->
            resolveOne(card)
            onProgress?.invoke(index + 1, total)
        }
    }

    private suspend fun resolveOne(card: DeckCardEntity) {
        try {
            val local = cardIndex.byOracleId(card.oracleId) ?: findLocalRecord(card.oracleName.ifBlank { card.inputName })
            val resolved = when {
                card.scryfallId.isNotBlank() -> scryfall.resolveById(card.selectedPrintingId.ifBlank { card.scryfallId }, localize = card.selectedPrintingId.isBlank())
                local != null && local.scryfallId.isNotBlank() -> scryfall.resolveById(local.scryfallId)
                else -> scryfall.resolve(card.inputName)
            }
            val translation = (local?.takeIf { it.oracleId == resolved.oracleId }
                ?: cardIndex.byOracleId(resolved.oracleId))
            saveSearchAliases(resolved)
            val medium = if (settings.value.imagePreloadMode == "MEDIUM" && card.selectedPrintingId.isBlank()) mediumImagePack.mediumPathByOracleId(resolved.oracleId, resolved.scryfallId) else ""
            val useMedium = medium.isNotBlank() && !settings.value.normalOverMedium
            val front = imageStore.cachedPath(resolved.scryfallId, "front").ifBlank {
                imageStore.cachedPath(resolved.scryfallId, "search_front").ifBlank {
                    if (useMedium) medium else imageStore.cache(resolved.scryfallId, resolved.imageUrl, "front")
                }
            }
            val back = if (resolved.backImageUrl.isNotBlank()) {
                if (useMedium) mediumImagePack.mediumPathByOracleId(resolved.oracleId, resolved.scryfallId, 1)
                    .ifBlank { imageStore.cache(resolved.scryfallId, resolved.backImageUrl, "back") }
                else imageStore.cache(resolved.scryfallId, resolved.backImageUrl, "back")
            } else ""
            db.withTransaction {
            val current = dao.getCard(card.id) ?: return@withTransaction
            if (current.inputName != card.inputName || current.selectedPrintingId != card.selectedPrintingId) return@withTransaction
            dao.updateCard(current.copy(
                oracleName = resolved.oracleName,
                oracleId = resolved.oracleId,
                displayName = CardNames.clean(resolved.displayName.ifBlank { resolved.oracleName }),
                printedName = CardNames.clean(resolved.printedName),
                displayTypeLine = resolved.displayTypeLine,
                oracleTypeLine = resolved.oracleTypeLine,
                oracleText = resolved.oracleText,
                manaCost = resolved.manaCost,
                cmc = resolved.cmc,
                colorIdentity = resolved.colorIdentity,
                scryfallId = resolved.scryfallId,
                imagePath = front,
                backImagePath = back,
                category = inferCategory(resolved.oracleTypeLine),
                isCommander = current.specialRole == DeckSpecialRoles.COMMANDER,
                cacheState = "READY",
                errorMessage = "",
            ).let { updated -> translation?.let { updated.withLocalization(it) } ?: updated })
            }
        } catch (t: Throwable) {
            if (t is CancellationException) throw t
            val suggestions = runCatching {
                nameVariants(card.inputName).flatMap { cardIndex.searchNames(it, 5) }
                    .distinctBy { it.oracleName }
                    .take(3)
                    .map { it.displayName }
            }.getOrDefault(emptyList())
            val suffix = if (suggestions.isEmpty()) "" else "\n\n候補:\n${suggestions.joinToString("\n")}"
            db.withTransaction {
                val current = dao.getCard(card.id) ?: return@withTransaction
                if (current.inputName == card.inputName && current.selectedPrintingId == card.selectedPrintingId) dao.updateCard(current.copy(cacheState = "ERROR", errorMessage = friendlyNetworkError(t) + suffix))
            }
        }
    }

    private suspend fun saveSearchAliases(card: ScryfallClient.ResolvedCard) {
        val entries = linkedMapOf<String, CardSearchEntity>()
        fun add(name: String, lang: String) {
            if (name.isBlank()) return
            val entity = searchEntity(name, card.oracleName.ifBlank { name }, lang, "resolved")
            entries[entity.searchKey] = entity
        }
        add(card.oracleName, "en")
        add(card.displayName, if (card.displayName == card.oracleName) "en" else "ja")
        add(card.printedName, "ja")
        if (entries.isNotEmpty()) dao.upsertSearchCards(entries.values.toList())
    }

    suspend fun updateCategory(cardId: Long, category: String) = dao.updateCategory(cardId, category.trim())

    suspend fun setCommander(deckId: Long, cardId: Long) = db.withTransaction {
        val card = dao.getCard(cardId) ?: return@withTransaction
        require(card.deckId == deckId)
        setSpecialRole(card, DeckSpecialRoles.COMMANDER)
    }

    suspend fun deleteDeck(deck: DeckEntity) = dao.deleteDeck(deck)

    suspend fun deleteDeckById(deckId: Long) {
        dao.getDeck(deckId)?.let { dao.deleteDeck(it) }
    }

    fun exportEnglish(cards: List<DeckCardEntity>, selectedOnly: Boolean = false): String = DeckExports.exportEnglish(cards, selectedOnly)
    fun exportHareruya(cards: List<DeckCardEntity>, selectedOnly: Boolean = false): String = DeckExports.exportHareruya(cards, selectedOnly)

    suspend fun validateDeck(cards: List<DeckCardEntity>): DeckValidation {
        val main = cards.filter { DeckRoles.countsTowardDeck(it.deckRole) }
        val candidateCount = cards.filter { it.deckRole == DeckRoles.CANDIDATE }.sumOf { it.quantity }
        val rules = main.map { copyRule(it) }
        val warnings = DeckCopyRules.violations(emptyList(), rules).toMutableList()
        val unknown = rules.count { it.limit == null }
        if (unknown > 0) warnings += "未照合${unknown}件：枚数制限を確認できません"
        return DeckValidation(main.sumOf { it.quantity }, candidateCount, warnings)
    }

    suspend fun tokenCandidates(deckId: Long): List<TokenCandidate> {
        val cards = dao.getCards(deckId).filter { DeckRoles.countsTowardDeck(it.deckRole) }
        val names = cards.map { it.oracleName.ifBlank { it.inputName } }
        val result = linkedMapOf<String, TokenCandidate>()
        cardIndex.tokenCandidates(names).forEach { result[it.tokenKey] = it }

        val text = cards.joinToString("\n") { it.oracleText }
        val common = listOf(
            "Treasure" to listOf("Treasure", "宝物"),
            "Clue" to listOf("Clue", "手掛かり"),
            "Food" to listOf("Food", "食物"),
            "Map" to listOf("Map token", "地図"),
            "Blood" to listOf("Blood token", "血"),
            "Powerstone" to listOf("Powerstone", "パワーストーン"),
            "Incubator" to listOf("Incubator", "培養器"),
        )
        common.forEach { (name, needles) ->
            if (needles.any { text.contains(it, true) }) {
                val candidate = cardIndex.tokenByName(name) ?: TokenCandidate(
                    tokenKey = "fallback:${name.lowercase()}",
                    englishName = name,
                    japaneseName = needles.getOrNull(1).orEmpty(),
                )
                result.putIfAbsent(candidate.tokenKey, candidate)
            }
        }
        // Generic tokens are useful even if the oracle text was not parsed as a direct relation.
        // With schema v3 these also carry Japanese names and Scryfall image URLs.
        common.forEach { (name, needles) ->
            val candidate = cardIndex.tokenByName(name) ?: return@forEach
            result.putIfAbsent(candidate.tokenKey, candidate.copy(japaneseName = candidate.japaneseName.ifBlank { needles.getOrNull(1).orEmpty() }))
        }
        listOf(Triple("Insect", "1", "1"), Triple("Bear", "2", "2"), Triple("Beast", "4", "4"), Triple("Plant", "0", "1")).forEach { (name, power, toughness) ->
            cardIndex.tokenByName(name, power, toughness)?.let { result.putIfAbsent(it.tokenKey, it) }
        }
        return result.values.sortedWith(compareBy<TokenCandidate> { it.japaneseName.isBlank() }.thenBy { it.displayName })
    }

    suspend fun cacheTokenImage(token: TokenCandidate): String {
        if (token.imageUrl.isBlank()) return ""
        val key = token.scryfallId.ifBlank { token.tokenKey }
        return imageStore.cache(key, token.imageUrl, "token")
    }

    private suspend fun canonicalize(lines: List<ParsedDeckLine>): List<ParsedDeckLine> {
        if (lines.isEmpty()) return lines
        val variantsByName = lines.associate { line -> line.name to nameVariants(line.name) }
        val keys = variantsByName.values.flatten()
            .flatMap { listOf(normalizeName(it), legacyNormalizeName(it)) }.distinct()
        val exact = dao.findExactSearchCards(keys).associateBy { it.normalizedName }
        return lines.map { line ->
            val variants = variantsByName[line.name].orEmpty()
            val local = variants.firstNotNullOfOrNull { exact[normalizeName(it)] ?: exact[legacyNormalizeName(it)] }
            if (local != null) line.copy(name = local.oracleName.ifBlank { local.displayName })
            else findLocalRecord(line.name)?.let { line.copy(name = it.englishName) } ?: line
        }
    }

    private suspend fun findLocalRecord(name: String): CardIndexRecord? =
        nameVariants(name).firstNotNullOfOrNull { variant -> cardIndex.byOracleName(variant) }

    private fun nameVariants(value: String): List<String> {
        val raw = value.trim().replace(Regex("\\s+"), " ")
        val nfkc = Normalizer.normalize(raw, Normalizer.Form.NFKC)
        fun withoutReading(text: String): String = text.replace(Regex("[（(][ぁ-んァ-ヶー]+[）)]"), "").trim()
        return listOf(raw, nfkc, withoutReading(raw), withoutReading(nfkc))
            .filter { it.isNotBlank() }.distinct()
    }

    private fun ParsedDeckLine.toEntity(deckId: Long): DeckCardEntity {
        val role = if (isCommander) DeckRoles.COMMANDER else DeckRoles.MAIN
        return DeckCardEntity(
            deckId = deckId,
            quantity = quantity,
            inputName = name,
            displayName = name,
            category = category,
            userCategory = CardCategories.imported(category),
            isCommander = isCommander,
            deckRole = DeckRoles.MAIN,
            specialRole = if (isCommander) DeckSpecialRoles.COMMANDER else DeckSpecialRoles.NONE,
        )
    }

    private fun searchEntity(displayName: String, oracleName: String, language: String, source: String): CardSearchEntity {
        val normalized = normalizeName(displayName)
        return CardSearchEntity(
            searchKey = "$language:$normalized",
            normalizedName = normalized,
            displayName = displayName,
            oracleName = oracleName.ifBlank { displayName },
            language = language,
            source = source,
        )
    }

    private suspend fun log(
        deckId: Long,
        action: String,
        cardName: String = "",
        quantity: Int = 0,
        fromRole: String = "",
        toRole: String = "",
        note: String = "",
    ) {
        dao.insertLog(DeckChangeLogEntity(deckId = deckId, action = action, cardName = cardName, quantity = quantity, fromRole = fromRole, toRole = toRole, note = note))
    }

    private fun normalizeName(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)
    private fun legacyNormalizeName(value: String): String = value.trim().replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)

    private fun friendlyNetworkError(t: Throwable): String {
        val raw = t.message.orEmpty()
        return when {
            raw.contains("Unable to resolve host", true) || raw.contains("No address associated with hostname", true) ->
                "Scryfallの名前解決に失敗しました。通信を確認して更新↻を押してください。Private DNS / VPN / 広告ブロック使用時は api.scryfall.com が遮断されていないか確認してください。\n\n$raw"
            raw.contains("Rate_Limited", true) || raw.contains("HTTP 429", true) ->
                "ScryfallのRate Limitに到達しました。DeckLoomは待って再試行します。しばらくして更新↻を押してください。\n\n$raw"
            else -> raw.ifBlank { t::class.java.simpleName }
        }
    }

    private fun inferCategory(typeLine: String): String = when {
        typeLine.contains("Land", true) -> "Land"
        typeLine.contains("Creature", true) -> "Creature"
        typeLine.contains("Artifact", true) -> "Artifact"
        typeLine.contains("Enchantment", true) -> "Enchantment"
        typeLine.contains("Instant", true) -> "Instant"
        typeLine.contains("Sorcery", true) -> "Sorcery"
        typeLine.contains("Planeswalker", true) -> "Planeswalker"
        typeLine.contains("Battle", true) -> "Battle"
        else -> "Other"
    }
}
