package jp.deckloom.app.playtest

import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import jp.deckloom.app.data.CardNames
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.ArrayDeque
import kotlin.random.Random

enum class Zone { LIBRARY, HAND, BATTLEFIELD, GRAVEYARD, EXILE, COMMAND }

data class PlayCard(
    val uid: Long,
    val sourceId: Long,
    val name: String,
    val imagePath: String,
    val backImagePath: String = "",
    val oracleText: String = "",
    val zone: Zone,
    val tapped: Boolean = false,
    val counters: Int = 0,
    val marked: Boolean = false,
    val faceMode: String = "FRONT", // FRONT / BACK / FACE_DOWN
    val token: Boolean = false,
    val boardX: Float = 80f,
    val boardY: Float = 80f,
    val zIndex: Long = 0L,
    val handOrder: Long = 0L,
)

data class PlaytestState(
    val cards: List<PlayCard> = emptyList(),
    val life: Int = 40,
    val commanderCasts: Int = 0,
    val commanderDamage: List<Int> = listOf(0, 0, 0),
    val turn: Int = 1,
    val mulliganCount: Int = 0,
    val mulliganBottomPending: Int = 0,
) {
    fun zone(zone: Zone): List<PlayCard> {
        val filtered = cards.filter { it.zone == zone }
        return when (zone) {
            Zone.HAND -> filtered.sortedByDescending { it.handOrder }
            Zone.GRAVEYARD, Zone.EXILE -> filtered.asReversed()
            else -> filtered
        }
    }

    fun latest(zone: Zone): PlayCard? = when (zone) {
        Zone.LIBRARY, Zone.HAND, Zone.GRAVEYARD, Zone.EXILE -> zone(zone).firstOrNull()
        else -> zone(zone).lastOrNull()
    }
}

class PlaytestSession {
    private val _state = MutableStateFlow(PlaytestState())
    val state: StateFlow<PlaytestState> = _state.asStateFlow()
    private val undo = ArrayDeque<PlaytestState>()
    private val redo = ArrayDeque<PlaytestState>()
    private val _history = MutableStateFlow(false to false)
    val history: StateFlow<Pair<Boolean, Boolean>> = _history.asStateFlow()
    private fun publishHistory() { _history.value = undo.isNotEmpty() to redo.isNotEmpty() }
    // IDs never repeat, including after undo/new game, so late image downloads cannot
    // attach to a different token.
    private var nextUid = 1L

    fun newGame(deckCards: List<DeckCardEntity>) {
        val expanded = mutableListOf<PlayCard>()
        deckCards.filter { DeckRoles.countsTowardDeck(it.deckRole) }.forEach { card ->
            repeat(card.quantity) {
                expanded += PlayCard(
                    uid = nextUid++,
                    sourceId = card.id,
                    name = CardNames.clean(card.displayName.ifBlank { card.inputName }),
                    imagePath = card.imagePath,
                    backImagePath = card.backImagePath,
                    oracleText = card.oracleText,
                    zone = if (DeckSpecialRoles.startsInCommandZone(card.specialRole) || card.isCommander) Zone.COMMAND else Zone.LIBRARY,
                )
            }
        }
        val command = expanded.filter { it.zone == Zone.COMMAND }
        val library = expanded.filter { it.zone == Zone.LIBRARY }.shuffled(Random(System.nanoTime()))
        _state.value = PlaytestState(cards = command + library)
        undo.clear()
        redo.clear()
        publishHistory()
        draw(7, record = false)
    }

    fun draw(count: Int = 1, record: Boolean = true) = mutate(record) { s ->
        var cards = s.cards
        repeat(count.coerceAtLeast(0)) {
            val top = cards.firstOrNull { it.zone == Zone.LIBRARY } ?: return@repeat
            val order = nextHandOrder(cards)
            cards = cards.map { if (it.uid == top.uid) it.copy(zone = Zone.HAND, tapped = false, handOrder = order) else it }
        }
        s.copy(cards = cards)
    }

    fun mill(count: Int = 1) = mutate { s ->
        var cards = s.cards
        repeat(count.coerceAtLeast(0)) {
            val top = cards.firstOrNull { it.zone == Zone.LIBRARY } ?: return@repeat
            cards = cards.map { if (it.uid == top.uid) it.copy(zone = Zone.GRAVEYARD, tapped = false) else it }
        }
        s.copy(cards = cards)
    }

    fun shuffleLibrary() = mutate { s ->
        val nonLibrary = s.cards.filter { it.zone != Zone.LIBRARY }
        val library = s.cards.filter { it.zone == Zone.LIBRARY }.shuffled(Random(System.nanoTime()))
        s.copy(cards = nonLibrary + library)
    }

    fun mulligan() = mutate { s ->
        val hand = s.cards.filter { it.zone == Zone.HAND }
        val nonHand = s.cards.filter { it.zone != Zone.HAND }
        val returned = hand.map { it.copy(zone = Zone.LIBRARY, tapped = false, handOrder = 0L) }
        var cards = nonHand + returned
        val nonLibrary = cards.filter { it.zone != Zone.LIBRARY }
        val library = cards.filter { it.zone == Zone.LIBRARY }.shuffled(Random(System.nanoTime()))
        cards = nonLibrary + library
        repeat(7) {
            val top = cards.firstOrNull { it.zone == Zone.LIBRARY } ?: return@repeat
            val order = nextHandOrder(cards)
            cards = cards.map { if (it.uid == top.uid) it.copy(zone = Zone.HAND, handOrder = order) else it }
        }
        val nextCount = s.mulliganCount + 1
        s.copy(cards = cards, mulliganCount = nextCount, mulliganBottomPending = (nextCount - 1).coerceAtLeast(0))
    }

    fun nextTurn() = mutate { s ->
        var cards = s.cards.map { card -> if (card.zone == Zone.BATTLEFIELD && card.tapped) card.copy(tapped = false) else card }
        val top = cards.firstOrNull { it.zone == Zone.LIBRARY }
        if (top != null) {
            val order = nextHandOrder(cards)
            cards = cards.map { if (it.uid == top.uid) it.copy(zone = Zone.HAND, handOrder = order) else it }
        }
        s.copy(cards = cards, turn = s.turn + 1, mulliganBottomPending = 0)
    }

    fun move(
        uid: Long,
        zone: Zone,
        toBottom: Boolean = false,
        boardX: Float? = null,
        boardY: Float? = null,
    ) = mutate { s ->
        val target = s.cards.firstOrNull { it.uid == uid } ?: return@mutate s

        if (target.token && target.zone == Zone.BATTLEFIELD && zone != Zone.BATTLEFIELD) {
            return@mutate s.copy(cards = s.cards.filterNot { it.uid == uid })
        }

        val rest = s.cards.filterNot { it.uid == uid }
        val pending = if (s.mulliganBottomPending > 0 && target.zone == Zone.HAND && zone == Zone.LIBRARY && toBottom) {
            s.mulliganBottomPending - 1
        } else s.mulliganBottomPending

        if (zone == Zone.LIBRARY) {
            val moved = target.copy(zone = zone, tapped = false, handOrder = 0L)
            val library = rest.filter { it.zone == Zone.LIBRARY }
            val others = rest.filter { it.zone != Zone.LIBRARY }
            return@mutate s.copy(cards = if (toBottom) others + library + moved else others + moved + library, mulliganBottomPending = pending)
        }

        val maxZ = s.cards.maxOfOrNull { it.zIndex } ?: 0L
        val battlefieldCount = rest.count { it.zone == Zone.BATTLEFIELD }
        // Non-drag moves (deck browser/detail -> battlefield) always spawn from the board's upper-left.
        // A small stagger keeps repeated moves visible without scattering cards across the field.
        val spawnStep = battlefieldCount % 8
        val defaultX = 48f + spawnStep * 12f
        val defaultY = 48f + spawnStep * 10f
        val moved = target.copy(
            zone = zone,
            tapped = if (zone == Zone.BATTLEFIELD) target.tapped else false,
            handOrder = if (zone == Zone.HAND) nextHandOrder(s.cards) else target.handOrder,
            boardX = if (zone == Zone.BATTLEFIELD) boardX ?: target.boardX.takeIf { target.zone == Zone.BATTLEFIELD } ?: defaultX else target.boardX,
            boardY = if (zone == Zone.BATTLEFIELD) boardY ?: target.boardY.takeIf { target.zone == Zone.BATTLEFIELD } ?: defaultY else target.boardY,
            zIndex = if (zone == Zone.BATTLEFIELD) maxZ + 1 else target.zIndex,
        )
        s.copy(cards = rest + moved, mulliganBottomPending = pending)
    }

    fun reorderHand(uid: Long, targetIndex: Int) = mutate { s ->
        val hand = s.zone(Zone.HAND).toMutableList()
        val card = hand.firstOrNull { it.uid == uid } ?: return@mutate s
        hand.removeAll { it.uid == uid }
        hand.add(targetIndex.coerceIn(0, hand.size), card)
        val base = (s.cards.maxOfOrNull { it.handOrder } ?: 0L) + hand.size + 1L
        val orders = hand.mapIndexed { index, c -> c.uid to (base - index) }.toMap()
        s.copy(cards = s.cards.map { c -> orders[c.uid]?.let { c.copy(handOrder = it) } ?: c })
    }

    fun positionOnBattlefield(uid: Long, x: Float, y: Float) = mutate { s ->
        val maxZ = s.cards.maxOfOrNull { it.zIndex } ?: 0L
        s.copy(cards = s.cards.map { card ->
            if (card.uid == uid && card.zone == Zone.BATTLEFIELD) card.copy(
                boardX = x.coerceIn(-500f, 2500f),
                boardY = y.coerceIn(-500f, 2500f),
                zIndex = maxZ + 1,
            ) else card
        })
    }

    fun toggleTap(uid: Long) = mutate { s -> s.copy(cards = s.cards.map { if (it.uid == uid) it.copy(tapped = !it.tapped) else it }) }
    fun counter(uid: Long, delta: Int) = mutate { s -> s.copy(cards = s.cards.map { if (it.uid == uid) it.copy(counters = it.counters + delta) else it }) }
    fun toggleMarker(uid: Long) = mutate { s -> s.copy(cards = s.cards.map { if (it.uid == uid) it.copy(marked = !it.marked) else it }) }
    fun toggleBackFace(uid: Long) = mutate { s -> s.copy(cards = s.cards.map { card ->
        if (card.uid != uid || card.backImagePath.isBlank()) card
        else card.copy(faceMode = if (card.faceMode == "BACK") "FRONT" else "BACK")
    }) }
    fun toggleFaceDown(uid: Long) = mutate { s -> s.copy(cards = s.cards.map { card ->
        if (card.uid != uid) card else card.copy(faceMode = if (card.faceMode == "FACE_DOWN") "FRONT" else "FACE_DOWN")
    }) }
    fun untapAll() = mutate { s -> s.copy(cards = s.cards.map { if (it.zone == Zone.BATTLEFIELD) it.copy(tapped = false) else it }) }
    fun setLife(delta: Int) = mutate { it.copy(life = it.life + delta) }

    fun commanderDamage(index: Int, delta: Int) = mutate { s ->
        val next = s.commanderDamage.toMutableList()
        if (index in next.indices) next[index] = (next[index] + delta).coerceAtLeast(0)
        s.copy(commanderDamage = next)
    }

    fun castCommander() = mutate { s ->
        val commander = s.cards.firstOrNull { it.zone == Zone.COMMAND } ?: return@mutate s
        val maxZ = s.cards.maxOfOrNull { it.zIndex } ?: 0L
        s.copy(
            cards = s.cards.map { if (it.uid == commander.uid) it.copy(zone = Zone.BATTLEFIELD, boardX = 48f, boardY = 48f, zIndex = maxZ + 1) else it },
            commanderCasts = s.commanderCasts + 1,
        )
    }

    fun createToken(name: String, imagePath: String = ""): Long {
        val uid = nextUid++
        mutate { s ->
        val maxZ = s.cards.maxOfOrNull { it.zIndex } ?: 0L
        val count = s.cards.count { it.zone == Zone.BATTLEFIELD }
        s.copy(cards = s.cards + PlayCard(
            uid = uid,
            sourceId = -uid,
            name = name.ifBlank { "Token" },
            imagePath = imagePath,
            zone = Zone.BATTLEFIELD,
            token = true,
            boardX = 48f + (count % 8) * 12f,
            boardY = 48f + (count % 8) * 10f,
            zIndex = maxZ + 1,
        ))
        }
        return uid
    }

    fun setTokenImage(uid: Long, path: String) {
        if (path.isBlank()) return
        fun attach(s: PlaytestState) = s.copy(cards = s.cards.map { if (it.uid == uid && it.token) it.copy(imagePath = path) else it })
        // An image download is presentation, not a new undoable play action.
        _state.value = attach(_state.value)
        val history = undo.map(::attach)
        undo.clear(); undo.addAll(history)
        val future = redo.map(::attach)
        redo.clear(); redo.addAll(future)
    }

    fun deleteToken(uid: Long) = mutate { s ->
        val target = s.cards.firstOrNull { it.uid == uid } ?: return@mutate s
        if (!target.token) return@mutate s
        s.copy(cards = s.cards.filterNot { it.uid == uid })
    }

    fun undo() {
        if (undo.isEmpty()) return
        redo.addLast(_state.value)
        _state.value = undo.removeLast()
        publishHistory()
    }

    fun redo() {
        if (redo.isEmpty()) return
        undo.addLast(_state.value)
        _state.value = redo.removeLast()
        publishHistory()
    }

    private fun mutate(record: Boolean = true, block: (PlaytestState) -> PlaytestState) {
        val old = _state.value
        val next = block(old)
        if (next == old) return
        if (record) {
            undo.addLast(old)
            while (undo.size > 100) undo.removeFirst()
            redo.clear()
        }
        _state.value = next
        publishHistory()
    }

    private fun nextHandOrder(cards: List<PlayCard>): Long = (cards.maxOfOrNull { it.handOrder } ?: 0L) + 1L
}
