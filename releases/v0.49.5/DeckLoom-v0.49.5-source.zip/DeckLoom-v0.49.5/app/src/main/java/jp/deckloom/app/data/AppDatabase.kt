package jp.deckloom.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        DeckEntity::class,
        DeckFolderEntity::class,
        DeckCardEntity::class,
        CardSearchEntity::class,
        DeckChangeLogEntity::class,
        SavedSearchEntity::class,
    ],
    version = 8,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun deckDao(): DeckDao
}
