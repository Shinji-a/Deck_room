package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FlipCameraAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import jp.deckloom.app.data.CardIndexRecord
import kotlinx.coroutines.CancellationException
import java.io.File

@Composable
fun SearchCardImage(vm: AppViewModel, card: CardIndexRecord, modifier: Modifier = Modifier, compact: Boolean = false,
    faceOverride: Int? = null, onFaceChange: ((Int) -> Unit)? = null,
    showFaceToggle: Boolean = true, onHasBackChange: (Boolean) -> Unit = {}) {
    val revision by vm.imageRevision.collectAsState()
    val settings by vm.settings.collectAsState()
    var localFace by rememberSaveable(card.scryfallId) { mutableIntStateOf(0) }
    val face = faceOverride ?: localFace
    fun flip() { val next = 1 - face; if (onFaceChange != null) onFaceChange(next) else localFace = next }
    var hasBack by remember(card.scryfallId) { mutableStateOf(false) }
    LaunchedEffect(hasBack) { onHasBackChange(hasBack) }
    var retry by remember(card.scryfallId) { mutableIntStateOf(0) }
    var path by remember(card.scryfallId, face) { mutableStateOf(vm.searchPreferredImagePath(card, face)) }
    var loading by remember(card.scryfallId, face) { mutableStateOf(false) }
    var error by remember(card.scryfallId, face) { mutableStateOf("") }
    var decodeFailed by remember(card.scryfallId, face, path, retry) { mutableStateOf(false) }
    LaunchedEffect(card.scryfallId, revision, retry, settings.imagePreloadMode) {
        try { hasBack = vm.searchHasBackFace(card) }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { /* Keep a cached face usable when offline. */ }
    }
    LaunchedEffect(card.scryfallId, face, revision, settings.imagePreloadMode, retry) {
        val cached = vm.searchPreferredImagePath(card, face)
        if (cached.isNotBlank()) { path = cached; error = ""; return@LaunchedEffect }
        loading = true
        try { path = vm.searchThumbnail(card, face); error = if (path.isBlank()) "画像なし" else "" }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { error = if (card.scryfallId.isBlank()) "画像なし" else "取得失敗" }
        finally { loading = false }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        if (path.isNotBlank() && !decodeFailed) {
            key(path, retry) {
                AsyncImage(model = File(path), contentDescription = "${card.displayName}・${if (face == 0) "表面" else "裏面"}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit, onError = { decodeFailed = true })
            }
        } else Column(Modifier.fillMaxWidth().padding(if (compact) 0.dp else 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!compact) Text(card.displayName, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
            when {
                loading -> Text(if (compact) "…" else "画像取得中", style = MaterialTheme.typography.labelSmall)
                card.scryfallId.isBlank() || error == "画像なし" -> Text(if (compact) "—" else "画像なし", style = MaterialTheme.typography.labelSmall)
                else -> DeckroomTextButton(onClick = { error = ""; retry++ }, contentPadding = PaddingValues()) { Text(if (compact) "↻" else "${if (decodeFailed) "表示失敗" else error.ifBlank { "未取得" }} · 再試行", style = MaterialTheme.typography.labelSmall) }
            }
        }
        if (hasBack && showFaceToggle) {
            val position = if (compact) Modifier.align(Alignment.BottomStart) else Modifier.align(Alignment.CenterStart).padding(start = 4.dp, top = 40.dp)
            Surface(modifier = position, color = MaterialTheme.colorScheme.surfaceContainerHigh, shape = MaterialTheme.shapes.small) {
                if (compact) DeckroomIconButton(onClick = { flip() }) { Icon(Icons.Outlined.FlipCameraAndroid, if (face == 0) "裏面を見る" else "表面を見る", Modifier.size(18.dp)) }
                else DeckroomTextButton(onClick = { flip() }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Icon(Icons.Outlined.FlipCameraAndroid, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp))
                    Text(if (face == 0) "裏面" else "表面", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
