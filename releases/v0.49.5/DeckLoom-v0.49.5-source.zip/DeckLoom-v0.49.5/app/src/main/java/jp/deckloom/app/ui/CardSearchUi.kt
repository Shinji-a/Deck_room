package jp.deckloom.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import jp.deckloom.app.data.CardSearchEntity
import kotlinx.coroutines.delay

@Composable
fun CardNameSearchField(
    vm: AppViewModel,
    value: String,
    onValueChange: (String) -> Unit,
    label: String = "カード名",
    onChosen: (CardSearchEntity) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    var suggestions by remember { mutableStateOf<List<CardSearchEntity>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var chosenValue by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(value, chosenValue) {
        if (value == chosenValue) {
            suggestions = emptyList()
            loading = false
            return@LaunchedEffect
        }
        if (value.trim().length < 2) {
            suggestions = emptyList()
            loading = false
            return@LaunchedEffect
        }
        loading = true
        delay(120)
        suggestions = vm.searchCardNames(value)
        loading = false
    }

    Column(modifier) {
        DeckroomTextField(
            value = value,
            onValueChange = { chosenValue = null; onValueChange(it) },
            label = { Text(label) },
            supportingText = {
                if (loading) Text("ローカルDB検索中…")
                else if (value.length >= 2 && suggestions.isEmpty()) Text("候補なし。入力名のままScryfall照合もできます。")
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        if (suggestions.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
            ) {
                items(suggestions, key = { it.searchKey }) { item ->
                    DeckroomListItem(
                        modifier = Modifier.clickable {
                            chosenValue = item.displayName
                            onValueChange(item.displayName)
                            onChosen(item)
                            suggestions = emptyList()
                        },
                        headlineContent = {
                            Text(item.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                        supportingContent = {
                            val sub = if (item.displayName == item.oracleName) item.language.uppercase() else item.oracleName
                            Text(sub, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
