package jp.deckloom.app.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import jp.deckloom.app.playtest.Zone

internal object PlaytestDropTargets {
    fun resolve(position: Offset, targets: Map<String, Rect>, cancel: Rect? = null): Zone? {
        if (cancel?.contains(position) == true) return null
        return listOf("hand" to Zone.HAND, "library" to Zone.LIBRARY, "command" to Zone.COMMAND,
            "graveyard" to Zone.GRAVEYARD, "exile" to Zone.EXILE, "battlefield" to Zone.BATTLEFIELD)
            .firstOrNull { (key, _) -> targets[key]?.contains(position) == true }?.second
    }
}
