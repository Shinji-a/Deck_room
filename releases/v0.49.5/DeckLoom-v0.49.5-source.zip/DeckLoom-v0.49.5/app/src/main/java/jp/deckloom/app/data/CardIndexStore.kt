package jp.deckloom.app.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.util.zip.GZIPInputStream

private const val MANIFEST_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/card-index-latest/manifest.json"
private const val DB_GZ_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/card-index-latest/deckloom-card-index.sqlite.gz"

data class CardIndexStatus(
    val ready: Boolean = false,
    val checking: Boolean = false,
    val updating: Boolean = false,
    val message: String = "検索DB未準備",
    val schemaVersion: Int = 0,
    val bulkUpdatedAt: String = "",
    val databaseSha256: String = "",
    val uniqueCards: Int = 0,
    val updateAvailable: Boolean = false,
)

data class CardIndexRecord(
    val oracleId: String,
    val scryfallId: String,
    val englishName: String,
    val japaneseName: String,
    val englishTypeLine: String,
    val japaneseTypeLine: String,
    val englishOracleText: String,
    val japaneseText: String,
    val manaCost: String,
    val manaValue: Double,
    val colors: String,
    val colorIdentity: String,
    val power: String,
    val toughness: String,
    val loyalty: String,
    val defense: String,
    val layout: String,
    val keywords: List<String>,
    val rarity: String,
    val setCode: String,
    val legalCommander: String,
    val copyLimit: Int,
    val copyLimitReason: String,
    val isBasicLand: Boolean,
    val isCreature: Boolean,
    val isLand: Boolean,
    val isArtifact: Boolean,
    val isEnchantment: Boolean,
    val isInstant: Boolean,
    val isSorcery: Boolean,
    val isPlaneswalker: Boolean,
    val isBattle: Boolean,
    val isLegendary: Boolean,
    val isCompanion: Boolean,
    val isBackground: Boolean,
    val firstReleasedAt: String = "",
    val powerNumeric: Double? = null,
    val toughnessNumeric: Double? = null,
    val relatedPartsJson: String,
    val facesJson: String = "",
    val japaneseFacesJson: String = "",
) {
    val displayName: String get() = CardLocalization.field(japaneseName, englishName, japaneseFacesJson, facesJson, "printed_name", "name", " // ")
    val displayTypeLine: String get() = CardLocalization.field(japaneseTypeLine, englishTypeLine, japaneseFacesJson, facesJson, "printed_type_line", "type_line", " // ")
    val displayText: String get() = CardLocalization.field(japaneseText, englishOracleText,
        japaneseFacesJson, facesJson, "printed_text", "oracle_text", "\n//\n", preferFaceText = true)
}

data class FilterOption(
    val value: String,
    val label: String,
)

data class TokenCandidate(
    val tokenKey: String,
    val englishName: String,
    val japaneseName: String = "",
    val typeLine: String = "",
    val power: String = "",
    val toughness: String = "",
    val imageUrl: String = "",
    val scryfallId: String = "",
    val oracleText: String = "",
) {
    val displayName: String get() = CardNames.clean(japaneseName.ifBlank { englishName })
    val subtitle: String get() = buildString {
        if (power.isNotBlank() || toughness.isNotBlank()) append("$power/$toughness ")
        append(typeLine)
    }.trim()
}

data class CardFilterOptions(
    val subtypes: List<FilterOption> = emptyList(),
    val keywords: List<FilterOption> = emptyList(),
    val sets: List<FilterOption> = emptyList(),
)

data class CardSearchFilter(
    val text: String = "",
    val textScope: String = "ALL", // ALL, NAME, TEXT
    val sortMode: String = "NAME", // NAME, RELEASE_NEW/OLD, MV_ASC/DESC, POWER_ASC/DESC, TOUGHNESS_ASC/DESC
    val colorIdentity: String = "",
    val colorMode: String = "CONTAINS", // CONTAINS, MATCH, EXACT_MULTI
    val typeText: String = "", // backward compatibility for saved v0.4 searches
    val typeTerms: List<String> = emptyList(),
    val subtypeTerms: List<String> = emptyList(),
    val manaMin: Double? = null,
    val manaMax: Double? = null,
    val powerMin: Double? = null,
    val powerMax: Double? = null,
    val toughnessMin: Double? = null,
    val toughnessMax: Double? = null,
    val rarity: String = "",
    val setCode: String = "", // saved-search backward compatibility
    val setCodes: List<String> = emptyList(),
    val commanderLegalOnly: Boolean = false,
    val legendaryOnly: Boolean = false,
    val creatureOnly: Boolean = false,
    val landOnly: Boolean = false,
    val artifactOnly: Boolean = false,
    val enchantmentOnly: Boolean = false,
    val instantOnly: Boolean = false,
    val sorceryOnly: Boolean = false,
    val planeswalkerOnly: Boolean = false,
    val battleOnly: Boolean = false,
    val keyword: String = "", // backward compatibility
    val keywordTerms: List<String> = emptyList(),
    val excludeName: String = "",
    val excludeType: String = "",
    val excludeSubtype: String = "",
    val excludeText: String = "",
) {
    fun description(): String {
        val parts = mutableListOf<String>()
        if (text.isNotBlank()) parts += "「$text」"
        if (colorIdentity.isNotBlank()) {
            val mode = when (colorMode) {
                "MATCH" -> "一致"
                "EXACT_MULTI" -> "一致多色"
                else -> "含む"
            }
            parts += "固有色 $mode $colorIdentity"
        }
        val types = buildList {
            if (creatureOnly) add("クリーチャー")
            if (artifactOnly) add("アーティファクト")
            if (enchantmentOnly) add("エンチャント")
            if (instantOnly) add("インスタント")
            if (sorceryOnly) add("ソーサリー")
            if (landOnly) add("土地")
            if (planeswalkerOnly) add("PW")
            if (battleOnly) add("バトル")
            addAll(typeTerms)
        }
        if (types.isNotEmpty()) parts += types.joinToString("+")
        if (subtypeTerms.isNotEmpty()) parts += "サブ:${subtypeTerms.joinToString(",")}"
        if (typeText.isNotBlank()) parts += typeText
        if (manaMin != null || manaMax != null) parts += "MV ${manaMin?.trimNumber() ?: "-"}〜${manaMax?.trimNumber() ?: "-"}"
        if (powerMin != null || powerMax != null) parts += "P ${powerMin?.trimNumber() ?: "-"}〜${powerMax?.trimNumber() ?: "-"}"
        if (toughnessMin != null || toughnessMax != null) parts += "T ${toughnessMin?.trimNumber() ?: "-"}〜${toughnessMax?.trimNumber() ?: "-"}"
        val selectedSets = (setCodes + listOfNotNull(setCode.takeIf { it.isNotBlank() })).distinct()
        if (selectedSets.isNotEmpty()) parts += "収録:${selectedSets.joinToString(",") { it.uppercase() }}"
        if (rarity.isNotBlank()) parts += rarity
        if (commanderLegalOnly) parts += "Commander可"
        if (legendaryOnly) parts += "伝説"
        val kws = (keywordTerms + listOfNotNull(keyword.takeIf { it.isNotBlank() })).distinct()
        if (kws.isNotEmpty()) parts += "能力:${kws.joinToString(",")}"
        return parts.joinToString(" / ").ifBlank { "条件なし" }
    }

    fun toJson(): String = JSONObject().apply {
        put("text", text)
        put("textScope", textScope)
        put("sortMode", sortMode)
        put("colorIdentity", colorIdentity)
        put("colorMode", colorMode)
        put("typeText", typeText)
        put("typeTerms", JSONArray(typeTerms))
        put("subtypeTerms", JSONArray(subtypeTerms))
        manaMin?.let { put("manaMin", it) }
        manaMax?.let { put("manaMax", it) }
        powerMin?.let { put("powerMin", it) }
        powerMax?.let { put("powerMax", it) }
        toughnessMin?.let { put("toughnessMin", it) }
        toughnessMax?.let { put("toughnessMax", it) }
        put("rarity", rarity)
        put("setCode", setCode)
        put("setCodes", JSONArray(setCodes))
        put("commanderLegalOnly", commanderLegalOnly)
        put("legendaryOnly", legendaryOnly)
        put("creatureOnly", creatureOnly)
        put("landOnly", landOnly)
        put("artifactOnly", artifactOnly)
        put("enchantmentOnly", enchantmentOnly)
        put("instantOnly", instantOnly)
        put("sorceryOnly", sorceryOnly)
        put("planeswalkerOnly", planeswalkerOnly)
        put("battleOnly", battleOnly)
        put("keyword", keyword)
        put("keywordTerms", JSONArray(keywordTerms))
        put("excludeName", excludeName)
        put("excludeType", excludeType)
        put("excludeSubtype", excludeSubtype)
        put("excludeText", excludeText)
    }.toString()

    companion object {
        fun fromJson(raw: String): CardSearchFilter = runCatching {
            val o = JSONObject(raw)
            fun strings(key: String): List<String> {
                val arr = o.optJSONArray(key) ?: return emptyList()
                return buildList { for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(::add) }
            }
            CardSearchFilter(
                text = o.optString("text"),
                textScope = o.optString("textScope", "ALL"),
                sortMode = o.optString("sortMode", "NAME"),
                colorIdentity = o.optString("colorIdentity"),
                colorMode = o.optString("colorMode", "CONTAINS").let { if (it == "WITHIN") "MATCH" else it },
                typeText = o.optString("typeText"),
                typeTerms = strings("typeTerms"),
                subtypeTerms = strings("subtypeTerms"),
                manaMin = if (o.has("manaMin")) o.optDouble("manaMin") else null,
                manaMax = if (o.has("manaMax")) o.optDouble("manaMax") else null,
                powerMin = if (o.has("powerMin")) o.optDouble("powerMin") else null,
                powerMax = if (o.has("powerMax")) o.optDouble("powerMax") else null,
                toughnessMin = if (o.has("toughnessMin")) o.optDouble("toughnessMin") else null,
                toughnessMax = if (o.has("toughnessMax")) o.optDouble("toughnessMax") else null,
                rarity = o.optString("rarity"),
                setCode = o.optString("setCode"),
                setCodes = strings("setCodes"),
                commanderLegalOnly = o.optBoolean("commanderLegalOnly"),
                legendaryOnly = o.optBoolean("legendaryOnly"),
                creatureOnly = o.optBoolean("creatureOnly"),
                landOnly = o.optBoolean("landOnly"),
                artifactOnly = o.optBoolean("artifactOnly"),
                enchantmentOnly = o.optBoolean("enchantmentOnly"),
                instantOnly = o.optBoolean("instantOnly"),
                sorceryOnly = o.optBoolean("sorceryOnly"),
                planeswalkerOnly = o.optBoolean("planeswalkerOnly"),
                battleOnly = o.optBoolean("battleOnly"),
                keyword = o.optString("keyword"),
                keywordTerms = strings("keywordTerms"),
                excludeName = o.optString("excludeName"),
                excludeType = o.optString("excludeType"),
                excludeSubtype = o.optString("excludeSubtype"),
                excludeText = o.optString("excludeText"),
            )
        }.getOrDefault(CardSearchFilter())
    }
}

private fun Double.trimNumber(): String = if (this % 1.0 == 0.0) toInt().toString() else toString()

class CardIndexStore(private val context: Context) {
    private val dir = File(context.filesDir, "card_index").apply { mkdirs() }
    private val dbFile = File(dir, "deckloom-card-index.sqlite")
    private val manifestFile = File(dir, "manifest.json")
    @Volatile private var cachedFilterOptions: CardFilterOptions? = null

    fun localStatus(): CardIndexStatus {
        if (!dbFile.exists() || !manifestFile.exists()) return CardIndexStatus()
        return runCatching {
            val manifest = JSONObject(manifestFile.readText())
            CardIndexStatus(
                ready = manifest.optInt("schema_version") >= 2,
                message = "検索DB ${manifest.optInt("unique_cards")}枚",
                schemaVersion = manifest.optInt("schema_version"),
                bulkUpdatedAt = manifest.optString("scryfall_bulk_updated_at"),
                databaseSha256 = manifest.optString("database_sha256"),
                uniqueCards = manifest.optInt("unique_cards"),
            )
        }.getOrDefault(CardIndexStatus())
    }

    suspend fun checkAndUpdate(force: Boolean = false, allowDownload: Boolean = true, onStatus: (CardIndexStatus) -> Unit = {}): CardIndexStatus = withContext(Dispatchers.IO) {
        val current = localStatus()
        onStatus(current.copy(checking = true, message = "検索DB更新確認中…"))
        try {
            val remoteRaw = getText(MANIFEST_URL)
            val remote = JSONObject(remoteRaw)
            val remoteSchema = remote.optInt("schema_version")
            if (remoteSchema < 2) error("GitHub検索DBはまだschema v2ではありません")
            val remoteUpdated = remote.optString("scryfall_bulk_updated_at")
            val remoteDbSha256 = remote.optString("database_sha256")
            // Prefer the actual database artifact hash for update decisions. This keeps the
            // daily manifest check tiny while avoiding a ~20 MB download when a daily build
            // produced the exact same database bytes. Older manifests without the hash fall
            // back to the Scryfall bulk timestamp.
            val sameDatabase = if (remoteDbSha256.isNotBlank() && current.databaseSha256.isNotBlank()) {
                current.databaseSha256.equals(remoteDbSha256, ignoreCase = true)
            } else {
                current.bulkUpdatedAt == remoteUpdated
            }
            val same = current.ready && current.schemaVersion == remoteSchema && sameDatabase
            if (!force && same) {
                return@withContext current.copy(checking = false, updateAvailable = false, message = "検索DBは最新です (${current.uniqueCards}枚)")
                    .also(onStatus)
            }
            if (!allowDownload) {
                return@withContext current.copy(
                    checking = false,
                    updating = false,
                    updateAvailable = true,
                    message = "検索DB更新あり（従量制通信のため自動DL保留）",
                ).also(onStatus)
            }

            onStatus(current.copy(checking = false, updating = true, updateAvailable = true, message = "検索DBダウンロード中…"))
            val gzTmp = File(dir, "index.sqlite.gz.tmp")
            val dbTmp = File(dir, "index.sqlite.tmp")
            download(DB_GZ_URL, gzTmp)

            val expectedGz = remote.optString("database_gzip_sha256")
            if (expectedGz.isNotBlank() && sha256(gzTmp) != expectedGz) error("検索DB(gzip)のSHA-256が一致しません")

            GZIPInputStream(BufferedInputStream(FileInputStream(gzTmp))).use { input ->
                BufferedOutputStream(FileOutputStream(dbTmp)).use { output -> input.copyTo(output) }
            }
            val expectedDb = remote.optString("database_sha256")
            if (expectedDb.isNotBlank() && sha256(dbTmp) != expectedDb) error("検索DBのSHA-256が一致しません")

            val testDb = SQLiteDatabase.openDatabase(dbTmp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            testDb.rawQuery("PRAGMA quick_check", null).use { c ->
                if (!c.moveToFirst() || c.getString(0) != "ok") error("検索DBのquick_checkに失敗しました")
            }
            testDb.close()

            if (dbFile.exists()) dbFile.delete()
            if (!dbTmp.renameTo(dbFile)) {
                dbTmp.copyTo(dbFile, overwrite = true)
                dbTmp.delete()
            }
            manifestFile.writeText(remote.toString(2))
            cachedFilterOptions = null
            gzTmp.delete()

            CardIndexStatus(
                ready = true,
                updating = false,
                message = "検索DB更新完了 (${remote.optInt("unique_cards")}枚)",
                schemaVersion = remoteSchema,
                bulkUpdatedAt = remoteUpdated,
                databaseSha256 = remoteDbSha256,
                uniqueCards = remote.optInt("unique_cards"),
                updateAvailable = false,
            ).also(onStatus)
        } catch (t: Throwable) {
            val fallback = localStatus()
            fallback.copy(
                checking = false,
                updating = false,
                message = if (fallback.ready) "更新確認失敗。既存DBを使用: ${t.message}" else "検索DB取得失敗: ${t.message}",
            ).also(onStatus)
        }
    }

    suspend fun searchNames(query: String, limit: Int = 20): List<CardSearchEntity> = withContext(Dispatchers.IO) {
        if (!dbFile.exists() || query.trim().length < 2) return@withContext emptyList()
        val q = "%${query.trim()}%"
        withDb { db ->
            val sql = """
                SELECT oracle_id, english_name, COALESCE(japanese_name,''), preferred_scryfall_id
                FROM cards
                WHERE english_name LIKE ? COLLATE NOCASE OR japanese_name LIKE ?
                ORDER BY CASE WHEN japanese_name LIKE ? OR english_name LIKE ? COLLATE NOCASE THEN 0 ELSE 1 END,
                         CASE WHEN japanese_name IS NULL OR japanese_name = '' THEN 1 ELSE 0 END,
                         LENGTH(COALESCE(NULLIF(japanese_name,''), english_name)),
                         COALESCE(NULLIF(japanese_name,''), english_name) COLLATE NOCASE, english_name
                LIMIT ?
            """.trimIndent()
            val starts = "${query.trim()}%"
            db.rawQuery(sql, arrayOf(q, q, starts, starts, limit.toString())).use { c ->
                buildList {
                    while (c.moveToNext()) {
                        val oracleId = c.getString(0)
                        val en = c.getString(1)
                        val ja = c.getString(2)
                        val display = ja.ifBlank { en }
                        add(CardSearchEntity(
                            searchKey = "index:$oracleId",
                            normalizedName = display.lowercase(),
                            displayName = display,
                            oracleName = en,
                            language = if (ja.isNotBlank()) "ja" else "en",
                            source = "github_index_v2",
                        ))
                    }
                }
            }
        }
    }


    suspend fun filterOptions(): CardFilterOptions = withContext(Dispatchers.IO) {
        cachedFilterOptions?.let { return@withContext it }
        if (!dbFile.exists()) return@withContext CardFilterOptions()
        val schema = localStatus().schemaVersion
        withDb { db ->
            val subtypes = if (schema >= 3) {
                buildList {
                    db.rawQuery(
                        "SELECT canonical, COALESCE(NULLIF(japanese,''), canonical) FROM display_terms WHERE category='subtype' ORDER BY COALESCE(NULLIF(japanese,''), canonical), canonical",
                        null,
                    ).use { c -> while (c.moveToNext()) add(FilterOption(c.getString(0).orEmpty(), c.getString(1).orEmpty())) }
                }
            } else {
                val subtypeLabels = linkedMapOf<String, String>()
                db.rawQuery("SELECT english_type_line, COALESCE(japanese_type_line,'') FROM cards", null).use { c ->
                    while (c.moveToNext()) {
                        val enSubs = subtypeTokens(c.getString(0).orEmpty(), japanese = false)
                        val jaSubs = subtypeTokens(c.getString(1).orEmpty(), japanese = true)
                        enSubs.forEachIndexed { index, en ->
                            val ja = jaSubs.getOrNull(index).orEmpty()
                            val label = ja.ifBlank { subtypeJapaneseFallback(en) }
                            val existing = subtypeLabels[en]
                            if (existing == null || existing == en) subtypeLabels[en] = label
                        }
                    }
                }
                subtypeLabels.entries.map { FilterOption(it.key, it.value) }.sortedWith(compareBy<FilterOption> { it.label }.thenBy { it.value })
            }

            val keywords = if (schema >= 3) {
                buildList {
                    db.rawQuery(
                        "SELECT canonical, COALESCE(NULLIF(japanese,''), canonical) FROM display_terms WHERE category='keyword' ORDER BY COALESCE(NULLIF(japanese,''), canonical), canonical",
                        null,
                    ).use { c -> while (c.moveToNext()) {
                        val canonical = c.getString(0).orEmpty()
                        val rawLabel = c.getString(1).orEmpty()
                        val label = rawLabel.takeIf { it.isNotBlank() && it != canonical } ?: keywordJapaneseLabel(canonical)
                        add(FilterOption(canonical, label))
                    } }
                }
            } else {
                val seen = linkedSetOf<String>()
                db.rawQuery("SELECT keywords_json FROM cards", null).use { c ->
                    while (c.moveToNext()) {
                        val raw = c.getString(0).orEmpty()
                        if (raw.isNotBlank()) runCatching {
                            val arr = JSONArray(raw)
                            for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotBlank() }?.let(seen::add)
                        }
                    }
                }
                seen.map { FilterOption(it, keywordJapaneseLabel(it)) }.sortedWith(compareBy<FilterOption> { it.label }.thenBy { it.value })
            }

            val sets = buildList {
                db.rawQuery(
                    "SELECT DISTINCT set_code, set_name FROM card_sets WHERE set_code IS NOT NULL AND set_code != '' ORDER BY set_name COLLATE NOCASE",
                    null,
                ).use { c ->
                    while (c.moveToNext()) {
                        val code = c.getString(0).orEmpty()
                        val name = c.getString(1).orEmpty()
                        if (code.isNotBlank()) add(FilterOption(code, if (name.isBlank()) code.uppercase() else "$name (${code.uppercase()})"))
                    }
                }
            }

            CardFilterOptions(subtypes = subtypes, keywords = keywords, sets = sets)
                .also { cachedFilterOptions = it }
        }
    }

    suspend fun search(filter: CardSearchFilter, limit: Int = 40, offset: Int = 0): List<CardIndexRecord> = withContext(Dispatchers.IO) {
        if (!dbFile.exists()) return@withContext emptyList()
        val schema = localStatus().schemaVersion
        withDb { db ->
            val where = mutableListOf<String>()
            val args = mutableListOf<String>()
            val textTerms = filter.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            textTerms.forEach { term ->
                val q = "%$term%"
                when (filter.textScope) {
                    "NAME" -> {
                        if (schema >= 4) { where += "(english_name LIKE ? COLLATE NOCASE OR japanese_name LIKE ? OR EXISTS (SELECT 1 FROM card_aliases a WHERE a.oracle_id = cards.oracle_id AND (a.alias LIKE ? OR a.alias_folded LIKE ?)))"; repeat(4) { args += q } }
                        else { where += "(english_name LIKE ? COLLATE NOCASE OR japanese_name LIKE ?)"; args += q; args += q }
                    }
                    "TEXT" -> { where += "(english_oracle_text LIKE ? COLLATE NOCASE OR japanese_text LIKE ?)"; args += q; args += q }
                    else -> {
                        if (schema >= 4) {
                            where += "(english_name LIKE ? COLLATE NOCASE OR japanese_name LIKE ? OR english_type_line LIKE ? COLLATE NOCASE OR japanese_type_line LIKE ? OR english_oracle_text LIKE ? COLLATE NOCASE OR japanese_text LIKE ? OR EXISTS (SELECT 1 FROM card_aliases a WHERE a.oracle_id = cards.oracle_id AND (a.alias LIKE ? OR a.alias_folded LIKE ?)))"
                            repeat(8) { args += q }
                        } else {
                            where += "(english_name LIKE ? COLLATE NOCASE OR japanese_name LIKE ? OR english_type_line LIKE ? COLLATE NOCASE OR japanese_type_line LIKE ? OR english_oracle_text LIKE ? COLLATE NOCASE OR japanese_text LIKE ?)"
                            repeat(6) { args += q }
                        }
                    }
                }
            }

            if (filter.colorIdentity.isNotBlank()) {
                val selected = normalizeColors(filter.colorIdentity)
                val includeColorless = 'C' in filter.colorIdentity.uppercase()
                val colorClauses = mutableListOf<String>()
                val colorArgs = mutableListOf<String>()
                when (filter.colorMode) {
                    "EXACT_MULTI" -> {
                        if (selected.isNotBlank()) {
                            colorClauses += "color_identity = ?"
                            colorArgs += selected
                        } else if (includeColorless) colorClauses += "color_identity = ''"
                    }
                    "MATCH" -> {
                        if (selected.isNotBlank()) {
                            val forbidden = "WUBRG".filter { it !in selected }
                            val parts = mutableListOf("color_identity != ''")
                            if (forbidden.isNotBlank()) {
                                parts += "color_identity NOT GLOB ?"
                                colorArgs += "*[${forbidden}]*"
                            }
                            colorClauses += "(${parts.joinToString(" AND ")})"
                        }
                        if (includeColorless) colorClauses += "color_identity = ''"
                    }
                    else -> { // CONTAINS
                        if (selected.isNotBlank()) {
                            val parts = selected.map { "color_identity LIKE ?" }
                            colorArgs += selected.map { "%$it%" }
                            colorClauses += "(${parts.joinToString(" AND ")})"
                        }
                        if (includeColorless) colorClauses += "color_identity = ''"
                    }
                }
                if (colorClauses.isNotEmpty()) {
                    where += "(${colorClauses.joinToString(" OR ")})"
                    args += colorArgs
                }
            }

            fun excludeTerms(raw: String, columns: List<String>) {
                raw.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.forEach { term ->
                    val clauses = columns.map { "$it LIKE ?" }
                    where += "NOT (${clauses.joinToString(" OR ")})"
                    repeat(columns.size) { args += "%$term%" }
                }
            }
            excludeTerms(filter.excludeName, listOf("english_name COLLATE NOCASE", "japanese_name"))
            excludeTerms(filter.excludeType, listOf("english_type_line COLLATE NOCASE", "japanese_type_line"))
            excludeTerms(filter.excludeSubtype, listOf("english_type_line COLLATE NOCASE", "japanese_type_line"))
            excludeTerms(filter.excludeText, listOf("english_oracle_text COLLATE NOCASE", "japanese_text"))

            if (filter.typeText.isNotBlank()) {
                where += "(english_type_line LIKE ? COLLATE NOCASE OR japanese_type_line LIKE ?)"
                val q = "%${filter.typeText.trim()}%"
                args += q; args += q
            }
            filter.typeTerms.distinct().forEach { term -> where += "english_type_line LIKE ? COLLATE NOCASE"; args += "%$term%" }
            filter.subtypeTerms.distinct().forEach { subtype -> where += "english_type_line LIKE ? COLLATE NOCASE"; args += "%$subtype%" }
            filter.manaMin?.let { where += "mana_value >= ?"; args += it.toString() }
            filter.manaMax?.let { where += "mana_value <= ?"; args += it.toString() }
            filter.powerMin?.let {
                where += if (schema >= 3) "power_numeric IS NOT NULL AND power_numeric >= ?" else "CAST(power AS REAL) >= ?"
                args += it.toString()
            }
            filter.powerMax?.let {
                where += if (schema >= 3) "power_numeric IS NOT NULL AND power_numeric <= ?" else "CAST(power AS REAL) <= ?"
                args += it.toString()
            }
            filter.toughnessMin?.let {
                where += if (schema >= 3) "toughness_numeric IS NOT NULL AND toughness_numeric >= ?" else "CAST(toughness AS REAL) >= ?"
                args += it.toString()
            }
            filter.toughnessMax?.let {
                where += if (schema >= 3) "toughness_numeric IS NOT NULL AND toughness_numeric <= ?" else "CAST(toughness AS REAL) <= ?"
                args += it.toString()
            }
            if (filter.rarity.isNotBlank()) { where += "latest_rarity = ?"; args += filter.rarity.lowercase() }
            val selectedSets = (filter.setCodes + listOfNotNull(filter.setCode.takeIf { it.isNotBlank() }))
                .map { it.lowercase() }.distinct()
            if (selectedSets.isNotEmpty()) {
                where += "EXISTS (SELECT 1 FROM card_sets s WHERE s.oracle_id = cards.oracle_id AND s.set_code IN (${selectedSets.joinToString(",") { "?" }}))"
                args += selectedSets
            }
            if (filter.commanderLegalOnly) where += "legal_commander = 'legal'"
            if (filter.legendaryOnly) where += "is_legendary = 1"
            if (filter.creatureOnly) where += "is_creature = 1"
            if (filter.landOnly) where += "is_land = 1"
            if (filter.artifactOnly) where += "is_artifact = 1"
            if (filter.enchantmentOnly) where += "is_enchantment = 1"
            if (filter.instantOnly) where += "is_instant = 1"
            if (filter.sorceryOnly) where += "is_sorcery = 1"
            if (filter.planeswalkerOnly) where += "is_planeswalker = 1"
            if (filter.battleOnly) where += "is_battle = 1"
            val keywordTerms = (filter.keywordTerms + listOfNotNull(filter.keyword.takeIf { it.isNotBlank() })).distinct()
            keywordTerms.forEach { keyword -> where += "keywords_json LIKE ? COLLATE NOCASE"; args += "%\"$keyword\"%" }

            val nameOrder = "CASE WHEN japanese_name IS NULL OR japanese_name = '' THEN 1 ELSE 0 END, COALESCE(NULLIF(japanese_name,''), english_name) COLLATE NOCASE, english_name COLLATE NOCASE"
            val order = when (filter.sortMode) {
                "RELEASE_NEW" -> (if (schema >= 3) "first_released_at" else "latest_released_at") + " DESC, $nameOrder"
                "RELEASE_OLD" -> (if (schema >= 3) "first_released_at" else "latest_released_at") + " ASC, $nameOrder"
                "MV_ASC" -> "mana_value ASC, $nameOrder"
                "MV_DESC" -> "mana_value DESC, $nameOrder"
                "POWER_ASC" -> if (schema >= 3) "CASE WHEN power_numeric IS NULL THEN 1 ELSE 0 END, power_numeric ASC, $nameOrder" else "CAST(power AS REAL) ASC, $nameOrder"
                "POWER_DESC" -> if (schema >= 3) "CASE WHEN power_numeric IS NULL THEN 1 ELSE 0 END, power_numeric DESC, $nameOrder" else "CAST(power AS REAL) DESC, $nameOrder"
                "TOUGHNESS_ASC" -> if (schema >= 3) "CASE WHEN toughness_numeric IS NULL THEN 1 ELSE 0 END, toughness_numeric ASC, $nameOrder" else "CAST(toughness AS REAL) ASC, $nameOrder"
                "TOUGHNESS_DESC" -> if (schema >= 3) "CASE WHEN toughness_numeric IS NULL THEN 1 ELSE 0 END, toughness_numeric DESC, $nameOrder" else "CAST(toughness AS REAL) DESC, $nameOrder"
                else -> nameOrder
            }

            val sql = buildString {
                append("SELECT * FROM cards")
                if (where.isNotEmpty()) append(" WHERE ").append(where.joinToString(" AND "))
                append(" ORDER BY ").append(order).append(", oracle_id ASC LIMIT ? OFFSET ?")
            }
            args += limit.toString()
            args += offset.toString()
            db.rawQuery(sql, args.toTypedArray()).use { c -> buildList { while (c.moveToNext()) add(c.toRecord()) } }
        }
    }

    suspend fun searchCount(filter: CardSearchFilter): Int = withContext(Dispatchers.IO) {
        var total = 0
        var offset = 0
        val batchSize = 1000
        while (true) {
            val batch = search(filter, batchSize, offset)
            total += batch.size
            if (batch.size < batchSize) break
            offset += batchSize
        }
        total
    }

    suspend fun byOracleId(oracleId: String): CardIndexRecord? = withContext(Dispatchers.IO) {
        if (!dbFile.exists() || oracleId.isBlank()) return@withContext null
        withDb { db ->
            db.rawQuery("SELECT * FROM cards WHERE oracle_id = ? LIMIT 1", arrayOf(oracleId)).use { c ->
                if (c.moveToFirst()) c.toRecord() else null
            }
        }
    }

    suspend fun byOracleName(name: String): CardIndexRecord? = withContext(Dispatchers.IO) {
        if (!dbFile.exists()) return@withContext null
        val normalized = normalizeLookupName(name)
        withDb { db ->
            val schema = localStatus().schemaVersion
            val sql = if (schema >= 4) {
                """SELECT c.* FROM cards c
                   WHERE c.english_name = ? COLLATE NOCASE OR c.japanese_name = ?
                      OR EXISTS (SELECT 1 FROM card_aliases a WHERE a.oracle_id = c.oracle_id AND (a.alias = ? OR a.alias_folded = ?))
                   ORDER BY CASE WHEN c.english_name = ? COLLATE NOCASE OR c.japanese_name = ? THEN 0 ELSE 1 END
                   LIMIT 1""".trimIndent()
            } else "SELECT * FROM cards WHERE english_name = ? COLLATE NOCASE OR japanese_name = ? LIMIT 1"
            val args = if (schema >= 4) arrayOf(name, normalized, normalized, normalized.casefoldCompat(), name, normalized) else arrayOf(name, normalized)
            db.rawQuery(sql, args).use { c -> if (c.moveToFirst()) c.toRecord() else null }
        }
    }

    private fun normalizeLookupName(value: String): String = value.trim()
        .replace(Regex("[（(][ぁ-ゖゝゞー]+[）)]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun String.casefoldCompat(): String = lowercase(java.util.Locale.ROOT)

    suspend fun tokenCandidates(cardNames: List<String>): List<TokenCandidate> = withContext(Dispatchers.IO) {
        if (!dbFile.exists() || cardNames.isEmpty()) return@withContext emptyList()
        val schema = localStatus().schemaVersion
        val results = linkedMapOf<String, TokenCandidate>()
        withDb { db ->
            cardNames.distinct().forEach { name ->
                db.rawQuery(
                    "SELECT related_parts_json FROM cards WHERE english_name = ? COLLATE NOCASE OR japanese_name = ? LIMIT 1",
                    arrayOf(name, name),
                ).use { c ->
                    if (!c.moveToFirst()) return@use
                    val raw = c.getString(0).orEmpty()
                    if (raw.isBlank()) return@use
                    try {
                        val arr = JSONArray(raw)
                        for (i in 0 until arr.length()) {
                            val part = arr.optJSONObject(i) ?: continue
                            if (part.optString("component") != "token") continue
                            val id = part.optString("id")
                            val fallbackName = part.optString("name")
                            if (schema >= 3 && id.isNotBlank()) {
                                val token = tokenByScryfallId(db, id)
                                if (token != null) {
                                    results[token.tokenKey] = token
                                    continue
                                }
                            }
                            if (fallbackName.isNotBlank()) {
                                val key = "legacy:${fallbackName.lowercase()}"
                                results.putIfAbsent(key, TokenCandidate(key, fallbackName))
                            }
                        }
                    } catch (_: Throwable) {
                        // Old/partial index rows can have malformed related data; ignore just that row.
                    }
                }
            }
        }
        results.values.sortedWith(compareBy<TokenCandidate> { it.japaneseName.isBlank() }.thenBy { it.displayName })
    }

    suspend fun tokenByName(name: String, power: String? = null, toughness: String? = null): TokenCandidate? = withContext(Dispatchers.IO) {
        if (!dbFile.exists() || localStatus().schemaVersion < 3 || name.isBlank()) return@withContext null
        val query = TokenQueries.byName(name, power, toughness)
        withDb { db ->
            db.rawQuery(query.sql, query.args.toTypedArray()).use { c ->
                if (c.moveToFirst()) c.toTokenCandidate() else null
            }
        }
    }

    private fun tokenByScryfallId(db: SQLiteDatabase, scryfallId: String): TokenCandidate? {
        db.rawQuery(
            """SELECT t.token_key, t.english_name, COALESCE(t.japanese_name,''),
                COALESCE(NULLIF(t.japanese_type_line,''), t.english_type_line), COALESCE(t.power,''), COALESCE(t.toughness,''),
                COALESCE(NULLIF(t.japanese_image_normal,''), t.preferred_image_normal),
                COALESCE(NULLIF(t.japanese_scryfall_id,''), t.preferred_scryfall_id),
                COALESCE(NULLIF(t.japanese_text,''), t.english_oracle_text,'')
                FROM token_aliases a JOIN tokens t ON t.token_key = a.token_key
                WHERE a.scryfall_id = ? LIMIT 1""".trimIndent(),
            arrayOf(scryfallId),
        ).use { c -> return if (c.moveToFirst()) c.toTokenCandidate() else null }
    }

    private fun android.database.Cursor.toTokenCandidate(): TokenCandidate = TokenCandidate(
        tokenKey = getString(0).orEmpty(),
        englishName = getString(1).orEmpty(),
        japaneseName = getString(2).orEmpty(),
        typeLine = getString(3).orEmpty(),
        power = getString(4).orEmpty(),
        toughness = getString(5).orEmpty(),
        imageUrl = getString(6).orEmpty(),
        scryfallId = getString(7).orEmpty(),
        oracleText = getString(8).orEmpty(),
    )

    private fun android.database.Cursor.toRecord(): CardIndexRecord {
        fun idx(name: String): Int = getColumnIndex(name)
        fun s(name: String): String = idx(name).takeIf { it >= 0 }?.let { getString(it) }.orEmpty()
        fun i(name: String): Int = idx(name).takeIf { it >= 0 }?.let { getInt(it) } ?: 0
        fun d(name: String): Double = idx(name).takeIf { it >= 0 }?.let { getDouble(it) } ?: 0.0
        fun dn(name: String): Double? = idx(name).takeIf { it >= 0 }?.let { if (isNull(it)) null else getDouble(it) }
        val keywords = runCatching {
            val a = JSONArray(s("keywords_json")); List(a.length()) { a.optString(it) }.filter { it.isNotBlank() }
        }.getOrDefault(emptyList())
        return CardIndexRecord(
            oracleId = s("oracle_id"), scryfallId = s("preferred_scryfall_id"), englishName = s("english_name"), japaneseName = s("japanese_name"),
            englishTypeLine = s("english_type_line"), japaneseTypeLine = s("japanese_type_line"), englishOracleText = s("english_oracle_text"), japaneseText = s("japanese_text"),
            manaCost = s("mana_cost"), manaValue = d("mana_value"), colors = s("colors"), colorIdentity = s("color_identity"), power = s("power"), toughness = s("toughness"), loyalty = s("loyalty"), defense = s("defense"),
            layout = s("layout"), keywords = keywords, rarity = s("latest_rarity"), setCode = s("latest_set_code"), legalCommander = s("legal_commander"),
            copyLimit = i("copy_limit"), copyLimitReason = s("copy_limit_reason"), isBasicLand = i("is_basic_land") == 1,
            isCreature = i("is_creature") == 1, isLand = i("is_land") == 1, isArtifact = i("is_artifact") == 1, isEnchantment = i("is_enchantment") == 1,
            isInstant = i("is_instant") == 1, isSorcery = i("is_sorcery") == 1, isPlaneswalker = i("is_planeswalker") == 1, isBattle = i("is_battle") == 1,
            isLegendary = i("is_legendary") == 1, isCompanion = i("is_companion") == 1, isBackground = i("is_background") == 1,
            firstReleasedAt = s("first_released_at"), powerNumeric = dn("power_numeric"), toughnessNumeric = dn("toughness_numeric"),
            relatedPartsJson = s("related_parts_json"),
            facesJson = s("faces_json"), japaneseFacesJson = s("japanese_faces_json"),
        )
    }

    private inline fun <T> withDb(block: (SQLiteDatabase) -> T): T {
        val db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try { block(db) } finally { db.close() }
    }

    private fun getText(url: String): String {
        val conn = open(url)
        try { return conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
    }

    private fun download(url: String, dest: File) {
        val conn = open(url)
        try {
            BufferedInputStream(conn.inputStream).use { input -> BufferedOutputStream(FileOutputStream(dest)).use { output -> input.copyTo(output) } }
        } finally { conn.disconnect() }
    }

    private fun open(url: String): HttpURLConnection {
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 15_000
        conn.readTimeout = 120_000
        conn.setRequestProperty("Accept", "application/json, application/octet-stream;q=0.9, */*;q=0.8")
        conn.setRequestProperty("User-Agent", "DeckLoom/0.49 Android local-deck-manager")
        val code = conn.responseCode
        if (code !in 200..299) {
            val body = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            conn.disconnect()
            error("GitHub Card Index HTTP $code: $body")
        }
        return conn
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }


    private fun subtypeTokens(typeLine: String, japanese: Boolean): List<String> {
        if (!typeLine.contains("—")) return emptyList()
        val sub = typeLine.substringAfter("—").trim()
        if (sub.isBlank()) return emptyList()
        return if (japanese) {
            sub.split(Regex("[・/／\\s]+")).map { it.trim() }.filter { it.isNotBlank() }
        } else {
            sub.split(Regex("\\s+")).map { it.trim() }.filter { it.isNotBlank() }
        }
    }

    private fun subtypeJapaneseFallback(value: String): String = when (value.lowercase()) {
        "advisor" -> "アドバイザー"
        "angel" -> "天使"
        "ape" -> "類人猿"
        "assassin" -> "暗殺者"
        "avatar" -> "アバター"
        "bear" -> "熊"
        "beast" -> "ビースト"
        "bird" -> "鳥"
        "cat" -> "猫"
        "cleric" -> "クレリック"
        "construct" -> "構築物"
        "demon" -> "デーモン"
        "dinosaur" -> "恐竜"
        "dog" -> "犬"
        "dragon" -> "ドラゴン"
        "druid" -> "ドルイド"
        "dwarf" -> "ドワーフ"
        "elemental" -> "エレメンタル"
        "elf" -> "エルフ"
        "faerie" -> "フェアリー"
        "fish" -> "魚"
        "goblin" -> "ゴブリン"
        "god" -> "神"
        "golem" -> "ゴーレム"
        "human" -> "人間"
        "insect" -> "昆虫"
        "knight" -> "騎士"
        "merfolk" -> "マーフォーク"
        "monk" -> "モンク"
        "ooze" -> "ウーズ"
        "pirate" -> "海賊"
        "plant" -> "植物"
        "rogue" -> "ならず者"
        "samurai" -> "侍"
        "shaman" -> "シャーマン"
        "slime" -> "スライム"
        "snake" -> "蛇"
        "soldier" -> "兵士"
        "spider" -> "蜘蛛"
        "spirit" -> "スピリット"
        "vampire" -> "吸血鬼"
        "warrior" -> "戦士"
        "wizard" -> "ウィザード"
        "wolf" -> "狼"
        "zombie" -> "ゾンビ"
        else -> value
    }

    private fun keywordJapaneseLabel(value: String): String = when (value.lowercase()) {
        "affinity" -> "親和"
        "afterlife" -> "死後"
        "backup" -> "賛助"
        "banding" -> "バンド"
        "bargain" -> "協約"
        "battle cry" -> "喊声"
        "bestow" -> "授与"
        "blitz" -> "奇襲"
        "bloodthirst" -> "狂喜"
        "boast" -> "誇示"
        "buyback" -> "バイバック"
        "cascade" -> "続唱"
        "casualty" -> "犠牲"
        "champion" -> "覇権"
        "changeling" -> "多相"
        "cipher" -> "暗号"
        "conspire" -> "共謀"
        "convok e" -> "召集"
        "convoke" -> "召集"
        "crew" -> "搭乗"
        "cycling" -> "サイクリング"
        "deathtouch" -> "接死"
        "defender" -> "防衛"
        "delve" -> "探査"
        "demonstrate" -> "実演"
        "double strike" -> "二段攻撃"
        "dredge" -> "発掘"
        "echo" -> "エコー"
        "embalm" -> "不朽"
        "emerge" -> "現出"
        "enchant" -> "エンチャント"
        "encore" -> "再演"
        "equip" -> "装備"
        "escape" -> "脱出"
        "eternalize" -> "永遠"
        "evoke" -> "想起"
        "exalted" -> "賛美"
        "exploit" -> "濫用"
        "extort" -> "強請"
        "fabricate" -> "製造"
        "first strike" -> "先制攻撃"
        "flash" -> "瞬速"
        "flashback" -> "フラッシュバック"
        "flying" -> "飛行"
        "forecast" -> "予見"
        "fortify" -> "城砦化"
        "frenzy" -> "激情"
        "graft" -> "移植"
        "gravestorm" -> "墓地ストーム"
        "haste" -> "速攻"
        "haunt" -> "憑依"
        "hexproof" -> "呪禁"
        "hideaway" -> "秘匿"
        "horsemanship" -> "馬術"
        "improvise" -> "即席"
        "indestructible" -> "破壊不能"
        "infect" -> "感染"
        "kicker" -> "キッカー"
        "landwalk" -> "土地渡り"
        "level up" -> "Lvアップ"
        "lifelink" -> "絆魂"
        "living weapon" -> "生体武器"
        "madness" -> "マッドネス"
        "megamorph" -> "大変異"
        "menace" -> "威迫"
        "mentor" -> "教導"
        "miracle" -> "奇跡"
        "modular" -> "接合"
        "morph" -> "変異"
        "mutate" -> "変容"
        "ninjutsu" -> "忍術"
        "outlast" -> "長久"
        "overload" -> "超過"
        "persist" -> "頑強"
        "phasing" -> "フェイズ・アウト"
        "poisonous" -> "有毒"
        "prowess" -> "果敢"
        "protection" -> "プロテクション"
        "provoke" -> "挑発"
        "reach" -> "到達"
        "rebound" -> "反復"
        "recover" -> "復活"
        "reinforce" -> "補強"
        "renown" -> "高名"
        "replicate" -> "複製"
        "retrace" -> "回顧"
        "riot" -> "暴動"
        "soulbond" -> "結魂"
        "spectacle" -> "絢爛"
        "split second" -> "刹那"
        "storm" -> "ストーム"
        "sunburst" -> "烈日"
        "surveil" -> "諜報"
        "suspend" -> "待機"
        "totem armor" -> "族霊鎧"
        "training" -> "訓練"
        "trample" -> "トランプル"
        "transmute" -> "変成"
        "tribute" -> "貢納"
        "undying" -> "不死"
        "unearth" -> "蘇生"
        "unleash" -> "解鎖"
        "vanishing" -> "消失"
        "vigilance" -> "警戒"
        "ward" -> "護法"
        "wither" -> "萎縮"
        else -> value
    }

    private fun normalizeColors(raw: String): String = "WUBRG".filter { it in raw.uppercase() }
}
