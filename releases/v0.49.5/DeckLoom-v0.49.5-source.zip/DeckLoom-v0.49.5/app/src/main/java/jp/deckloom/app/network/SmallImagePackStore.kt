package jp.deckloom.app.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.util.zip.ZipInputStream

private const val IMAGE_MANIFEST_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/image-pack-latest/image-pack-meta.json"
private const val IMAGE_PACK_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/image-pack-latest/deckloom-small-images.zip"
private const val DELTA_MANIFEST_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/image-pack-latest/delta-manifest.json"
private const val DELTA_PACK_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/image-pack-latest/deckloom-small-images-delta.zip"

data class ImagePackProgress(
    val state: String = "IDLE", // IDLE/CHECKING/DOWNLOADING/INSTALLING/READY/ERROR
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val message: String = "",
) {
    val fraction: Float get() = if (totalBytes > 0L) (downloadedBytes.toDouble() / totalBytes).coerceIn(0.0, 1.0).toFloat() else 0f
    val active: Boolean get() = state in setOf("CHECKING", "DOWNLOADING", "INSTALLING")
}

class SmallImagePackStore(private val context: Context) {
    private val root = File(context.filesDir, "small_image_pack")
    private val imagesDir = File(root, "images")
    private val manifestFile = File(root, "image-manifest.json")
    private val prefs = context.getSharedPreferences("deckloom_image_pack", Context.MODE_PRIVATE)
    private val _progress = MutableStateFlow(if (manifestFile.exists()) ImagePackProgress("READY", message = "軽量画像パック導入済み") else ImagePackProgress())
    val progress: StateFlow<ImagePackProgress> = _progress.asStateFlow()

    fun installed(): Boolean = manifestFile.exists() && imagesDir.exists()
    fun installedBytes(): Long = imagesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun installedImageCount(): Int = runCatching { JSONObject(manifestFile.readText()).optInt("image_count", 0) }.getOrDefault(0)
    fun installedBulkUpdatedAt(): String = runCatching { JSONObject(manifestFile.readText()).optString("scryfall_bulk_updated_at") }.getOrDefault("")

    fun smallPath(scryfallId: String, face: Int = 0): String {
        if (scryfallId.isBlank() || !installed()) return ""
        val suffix = "$scryfallId-f$face.jpg"
        val candidates = if (face == 0) listOf("card_primary", "token_primary", "card_extra_face", "token_extra_face") else listOf("card_extra_face", "token_extra_face", "card_primary", "token_primary")
        return candidates.asSequence().map { File(imagesDir, "$it/$suffix") }.firstOrNull { it.exists() && it.length() > 0L }?.absolutePath.orEmpty()
    }

    suspend fun checkAndUpdateIfInstalled(blockMetered: Boolean, isMetered: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!installed()) return@withContext false
        try {
            val remote = fetchManifest() ?: return@withContext false
            val localSha = runCatching { JSONObject(manifestFile.readText()).optString("archive_sha256") }.getOrDefault("")
            val remoteSha = remote.optString("archive_sha256")
            if (remoteSha.isNotBlank() && remoteSha == localSha) {
                _progress.value = ImagePackProgress("READY", message = "軽量画像パックは最新です")
                return@withContext false
            }
            if (blockMetered && isMetered) {
                _progress.value = ImagePackProgress("READY", message = "従量制通信のため画像更新を保留中")
                return@withContext false
            }
            val delta = fetchJson(DELTA_MANIFEST_URL)
            if (delta != null && delta.optString("from_archive_sha256") == localSha && delta.optString("to_archive_sha256") == remoteSha) installDelta(delta, remote)
            else install(remote)
            true
        } catch (t: Throwable) {
            _progress.value = ImagePackProgress("ERROR", message = t.message ?: "軽量画像パック更新に失敗しました")
            throw t
        }
    }

    suspend fun downloadFullPack(): Boolean = withContext(Dispatchers.IO) {
        try {
            val remote = fetchManifest() ?: return@withContext false
            install(remote)
            true
        } catch (t: Throwable) {
            _progress.value = ImagePackProgress("ERROR", message = t.message ?: "軽量画像パックの取得に失敗しました")
            throw t
        }
    }

    suspend fun clear(): Long = withContext(Dispatchers.IO) {
        val bytes = if (root.exists()) root.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L
        root.deleteRecursively()
        prefs.edit().clear().apply()
        _progress.value = ImagePackProgress()
        bytes
    }

    private fun fetchManifest(): JSONObject? {
        _progress.value = ImagePackProgress("CHECKING", message = "軽量画像パックを確認中…")
        return runCatching {
            val conn = open(IMAGE_MANIFEST_URL)
            try { JSONObject(conn.inputStream.bufferedReader().use { it.readText() }) } finally { conn.disconnect() }
        }.onFailure { _progress.value = ImagePackProgress("ERROR", message = it.message ?: "manifest取得失敗") }.getOrNull()
    }

    private fun fetchJson(url: String): JSONObject? = runCatching {
        val conn = open(url)
        try { JSONObject(conn.inputStream.bufferedReader().use { it.readText() }) } finally { conn.disconnect() }
    }.getOrNull()

    private fun installDelta(delta: JSONObject, targetManifest: JSONObject) {
        val tmpZip = File(context.cacheDir, "deckloom-small-images-delta.download")
        val staging = File(context.cacheDir, "deckloom-small-images-delta-staging")
        tmpZip.delete(); staging.deleteRecursively(); staging.mkdirs()
        val expected = delta.optLong("archive_bytes", 0L)
        _progress.value = ImagePackProgress("DOWNLOADING", 0L, expected, "追加画像をダウンロード中")
        downloadToFile(DELTA_PACK_URL, tmpZip, expected, "追加画像をダウンロード中")
        val expectedSha = delta.optString("archive_sha256")
        if (expectedSha.isNotBlank() && sha256(tmpZip) != expectedSha) error("Delta SHA-256 mismatch")
        _progress.value = ImagePackProgress("INSTALLING", message = "追加画像を反映中…")
        unzip(tmpZip, staging)
        val changedRoot = File(staging, "images").takeIf { it.exists() } ?: staging
        changedRoot.walkTopDown().filter { it.isFile }.forEach { src ->
            val rel = src.relativeTo(changedRoot)
            val dst = File(imagesDir, rel.path); dst.parentFile?.mkdirs(); src.copyTo(dst, overwrite = true)
        }
        val removed = delta.optJSONArray("removed_paths")
        if (removed != null) for (i in 0 until removed.length()) File(imagesDir, removed.optString(i)).delete()
        manifestFile.writeText(targetManifest.toString())
        tmpZip.delete(); staging.deleteRecursively()
        _progress.value = ImagePackProgress("READY", message = "軽量画像パック更新済み")
    }

    private fun downloadToFile(url: String, dest: File, expected: Long, message: String) {
        val conn = open(url)
        try {
            val total = conn.contentLengthLong.takeIf { it > 0L } ?: expected
            var done = 0L
            BufferedInputStream(conn.inputStream).use { input -> FileOutputStream(dest).use { output ->
                val buf = ByteArray(128 * 1024)
                while (true) { val n = input.read(buf); if (n < 0) break; output.write(buf, 0, n); done += n; _progress.value = ImagePackProgress("DOWNLOADING", done, total, message) }
            } }
        } finally { conn.disconnect() }
    }

    private fun unzip(zipFile: File, dest: File) {
        ZipInputStream(BufferedInputStream(zipFile.inputStream())).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val out = File(dest, entry.name).canonicalFile
                require(out.path.startsWith(dest.canonicalPath + File.separator)) { "Invalid ZIP path" }
                if (entry.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { zip.copyTo(it) } }
                zip.closeEntry()
            }
        }
    }

    private fun install(manifest: JSONObject) {
        root.parentFile?.mkdirs()
        val tmpZip = File(context.cacheDir, "deckloom-small-images.download")
        val staging = File(context.cacheDir, "deckloom-small-images-staging")
        staging.deleteRecursively(); staging.mkdirs()
        tmpZip.delete()
        val expected = manifest.optLong("archive_bytes", 0L)
        _progress.value = ImagePackProgress("DOWNLOADING", 0L, expected, "軽量画像パックをダウンロード中")
        downloadToFile(IMAGE_PACK_URL, tmpZip, expected, "軽量画像パックをダウンロード中")
        val expectedSha = manifest.optString("archive_sha256")
        if (expectedSha.isNotBlank() && sha256(tmpZip) != expectedSha) {
            tmpZip.delete(); _progress.value = ImagePackProgress("ERROR", message = "画像パックのSHA-256検証に失敗")
            error("Image pack SHA-256 mismatch")
        }
        _progress.value = ImagePackProgress("INSTALLING", message = "軽量画像を準備中…")
        unzip(tmpZip, staging)
        val stagedImages = File(staging, "images").takeIf { it.exists() } ?: staging
        val newRoot = File(context.filesDir, "small_image_pack_new")
        newRoot.deleteRecursively(); newRoot.mkdirs()
        stagedImages.copyRecursively(File(newRoot, "images"), overwrite = true)
        File(newRoot, "image-manifest.json").writeText(manifest.toString())
        val backupRoot = File(context.filesDir, "small_image_pack_old")
        backupRoot.deleteRecursively()
        if (root.exists()) require(root.renameTo(backupRoot)) { "Failed to stage current image pack" }
        try {
            require(newRoot.renameTo(root)) { "Failed to install image pack" }
            backupRoot.deleteRecursively()
        } catch (t: Throwable) {
            root.deleteRecursively()
            if (backupRoot.exists()) backupRoot.renameTo(root)
            throw t
        }
        tmpZip.delete(); staging.deleteRecursively()
        prefs.edit().putLong("installed_at", System.currentTimeMillis()).apply()
        _progress.value = ImagePackProgress("READY", message = "軽量画像パック導入済み")
    }

    private fun open(url: String): HttpURLConnection = (URI(url).toURL().openConnection() as HttpURLConnection).apply {
        connectTimeout = 20_000; readTimeout = 60_000; instanceFollowRedirects = true
        setRequestProperty("User-Agent", "DeckLoom/0.49 Android local-deck-manager")
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val b = ByteArray(1024 * 1024); while (true) { val n = input.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
