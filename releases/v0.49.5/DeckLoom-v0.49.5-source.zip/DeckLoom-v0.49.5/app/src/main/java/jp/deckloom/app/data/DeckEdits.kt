package jp.deckloom.app.data

/** English identity / Oracle identity are resolved by the repository, never translated text. */
data class CopyRuleCard(val key: String, val name: String, val quantity: Int, val active: Boolean, val limit: Int?)
object DeckCopyRules {
    fun violations(before: List<CopyRuleCard>, after: List<CopyRuleCard>): List<String> {
        val old = before.filter { it.active }.groupBy { it.key }.mapValues { it.value.sumOf { c -> c.quantity } }
        return after.filter { it.active }.groupBy { it.key }.values.mapNotNull { group ->
            val total = group.sumOf { it.quantity }
            val limit = group.mapNotNull { it.limit }.minOrNull() ?: return@mapNotNull null
            if (limit >= 0 && total > limit && total > (old[group.first().key] ?: 0))
                "${group.first().name}は${limit}枚までです（追加後${total}枚）。候補へ追加できます。"
            else null
        }
    }
}

data class DeckUndo(val deckId: Long, val before: List<DeckCardEntity>, val after: List<DeckCardEntity>)
object DeckEditFields {
    fun same(a: DeckCardEntity?, b: DeckCardEntity?): Boolean = when {
        a == null || b == null -> a == b
        else -> a.id == b.id && a.deckId == b.deckId && a.quantity == b.quantity &&
            a.inputName == b.inputName && a.userCategory == b.userCategory &&
            a.deckRole == b.deckRole && a.specialRole == b.specialRole && a.isCommander == b.isCommander &&
            a.selectedPrintingId == b.selectedPrintingId && a.addedAt == b.addedAt
    }
    fun restore(old: DeckCardEntity, current: DeckCardEntity): DeckCardEntity = current.copy(
        quantity = old.quantity, inputName = old.inputName, userCategory = old.userCategory, deckRole = old.deckRole, specialRole = old.specialRole,
        isCommander = old.isCommander, selectedPrintingId = old.selectedPrintingId, addedAt = old.addedAt,
    )
}
