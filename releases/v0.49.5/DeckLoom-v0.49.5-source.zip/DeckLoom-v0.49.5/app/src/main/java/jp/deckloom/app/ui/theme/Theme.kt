package jp.deckloom.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalTonalElevationEnabled
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class DeckroomControlColors(
    val brand: Color, val searchBorder: Color,
    val selection: Color, val onSelection: Color, val selectionBorder: Color,
)

private val LightControlColors = DeckroomControlColors(
    brand = Color(0xFF263828), searchBorder = Color(0xFF7C9C65),
    selection = Color(0xFFDCEBCF), onSelection = Color(0xFF2D5523), selectionBorder = Color(0xFF648C36))
private val DarkControlColors = DeckroomControlColors(
    brand = Color(0xFFEDF0EC), searchBorder = Color(0xFF3B4443),
    selection = Color(0xFF343D31), onSelection = Color(0xFFD9F6AC), selectionBorder = Color(0xFFC5EF72))
val LocalDeckroomControlColors = staticCompositionLocalOf { LightControlColors }

// Deckroom CSS fetched 2026-10-10. See WEB_COLORS.md for selectors and limits.
// The final :root is the active light palette; no mock colors are used.
private val DeckroomLightColors = lightColorScheme(
    primary = Color(0xFF547627),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6EEDB),
    onPrimaryContainer = Color(0xFF29451C),
    inversePrimary = Color(0xFFC5EF72),
    secondary = Color(0xFF547627),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE6EEDB),
    onSecondaryContainer = Color(0xFF29451C),
    tertiary = Color(0xFF3E681E),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFEFF2EC),
    onTertiaryContainer = Color(0xFF253227),
    background = Color(0xFFF6F7F4),
    onBackground = Color(0xFF202920),
    surface = Color.White,
    onSurface = Color(0xFF202920),
    surfaceVariant = Color(0xFFEEF1EB),
    onSurfaceVariant = Color(0xFF526153),
    surfaceTint = Color(0xFF547627),
    inverseSurface = Color(0xFF1B1F20),
    inverseOnSurface = Color(0xFFEDF0EC),
    // Use the Web's readable negative-state pair, not its inherited pale red.
    // A dedicated Web error screen has not been observed.
    error = Color(0xFFA04336),
    onError = Color.White,
    errorContainer = Color(0xFFF4E5E1),
    onErrorContainer = Color(0xFFA04336),
    outline = Color(0xFFCBD5C6),
    outlineVariant = Color(0xFFD9E0D5),
    scrim = Color.Black,
    surfaceBright = Color.White,
    surfaceDim = Color(0xFFF0F3ED),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF6F7F4),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEFF2EC),
    surfaceContainerHighest = Color(0xFFEEF1EB),
)

// Preserve Android's DARK/SYSTEM options using the dark base present in the
// same CSS. That base is superseded on the current Web page, so this is an
// Android adaptation, not a claim that the Web currently offers dark mode.
private val DeckroomDarkColors = darkColorScheme(
    primary = Color(0xFFC5EF72),
    onPrimary = Color(0xFF18210C),
    primaryContainer = Color(0xFF343D31),
    onPrimaryContainer = Color(0xFFD9F6AC),
    inversePrimary = Color(0xFF547627),
    secondary = Color(0xFFC5EF72),
    onSecondary = Color(0xFF18210C),
    secondaryContainer = Color(0xFF343D31),
    onSecondaryContainer = Color(0xFFD9F6AC),
    tertiary = Color(0xFFC5EF72),
    onTertiary = Color(0xFF18210C),
    tertiaryContainer = Color(0xFF272D2E),
    onTertiaryContainer = Color(0xFFEDF0EC),
    background = Color(0xFF121516),
    onBackground = Color(0xFFEDF0EC),
    surface = Color(0xFF1B1F20),
    onSurface = Color(0xFFEDF0EC),
    surfaceVariant = Color(0xFF24292A),
    onSurfaceVariant = Color(0xFFA0AAA7),
    surfaceTint = Color(0xFFC5EF72),
    inverseSurface = Color(0xFFFFFFFF),
    inverseOnSurface = Color(0xFF202920),
    error = Color(0xFFEF8888),
    onError = Color(0xFF121516),
    // Keep the verified negative-state pair readable in both modes.
    errorContainer = Color(0xFFF4E5E1),
    onErrorContainer = Color(0xFFA04336),
    outline = Color(0xFF3B4443),
    outlineVariant = Color(0xFF343B3B),
    scrim = Color.Black,
    surfaceBright = Color(0xFF252A2B),
    surfaceDim = Color(0xFF121516),
    surfaceContainerLowest = Color(0xFF121516),
    surfaceContainerLow = Color(0xFF1B1F20),
    surfaceContainer = Color(0xFF1B1F20),
    surfaceContainerHigh = Color(0xFF24292A),
    surfaceContainerHighest = Color(0xFF272D2E),
)

@Composable
fun DeckLoomTheme(themeMode: String = "SYSTEM", content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }
    CompositionLocalProvider(LocalTonalElevationEnabled provides false,
        LocalDeckroomControlColors provides if (dark) DarkControlColors else LightControlColors) {
        MaterialTheme(
            colorScheme = if (dark) DeckroomDarkColors else DeckroomLightColors,
            typography = DeckroomTypography,
            shapes = DeckroomShapes,
            content = content,
        )
    }
}
