package jp.deckloom.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import jp.deckloom.app.data.CardIndexRecord
import jp.deckloom.app.data.CardIndexStatus
import jp.deckloom.app.data.CardFilterOptions
import jp.deckloom.app.data.CardSearchEntity
import jp.deckloom.app.data.CardSearchFilter
import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckListCheck
import jp.deckloom.app.data.DeckRepository
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckValidation
import jp.deckloom.app.data.TokenCandidate
import jp.deckloom.app.network.ScryfallClient
import jp.deckloom.app.playtest.PlaytestSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import jp.deckloom.app.data.DeckUndo

data class EditNotice(val id: Long, val message: String, val undo: DeckUndo? = null)

class AppViewModel(private val repository: DeckRepository) : ViewModel() {
    private val editMutex = Mutex()
    private var noticeSequence = 0L
    private val _editNotice = MutableStateFlow<EditNotice?>(null)
    val editNotice = _editNotice.asStateFlow()
    fun showNotice(message: String) { _editNotice.value = EditNotice(++noticeSequence, message) }
    fun dismissEditNotice(id: Long) { if (_editNotice.value?.id == id) _editNotice.value = null }
    fun undoEdit(id: Long) {
        viewModelScope.launch {
            editMutex.withLock {
                val notice = _editNotice.value?.takeIf { it.id == id } ?: return@withLock
                val edit = notice.undo ?: return@withLock
                runCatching { repository.undo(edit) }
                    .onSuccess { sessions.remove(edit.deckId); _editNotice.value = EditNotice(++noticeSequence, "元に戻しました"); launch { resolveDeck(edit.deckId) } }
                    .onFailure { if (it is CancellationException) throw it; _editNotice.value = EditNotice(++noticeSequence, it.message ?: "取り消せませんでした") }
            }
        }
    }
    private fun <T> edit(deckId: Long, message: String, resolve: Boolean = false,
        onDone: (T) -> Unit = {}, onError: (String) -> Unit = {},
        notifyError: Boolean = true, messageForResult: ((T) -> String)? = null, block: suspend () -> T) {
        viewModelScope.launch {
            editMutex.withLock {
                runCatching { repository.editWithUndo(deckId, block) }.onSuccess { (value, undo) ->
                    sessions.remove(deckId)
                    val unknown = repository.unknownCopyRules(deckId)
                    val suffix = if (unknown > 0) "（上限未確認${unknown}件）" else ""
                    if (undo != null) _editNotice.value = EditNotice(++noticeSequence, (messageForResult?.invoke(value) ?: message) + suffix, undo)
                    onDone(value)
                    if (resolve) launch { resolveDeck(deckId) }
                }.onFailure {
                    if (it is CancellationException) throw it
                    val error = it.message ?: "変更できませんでした"
                    if (notifyError) showNotice(error)
                    onError(error)
                }
            }
        }
    }

    val decks = repository.decks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val homeDecks = repository.homeDecks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val folders = repository.folders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val _imageRevision = MutableStateFlow(0L)
    val imageRevision = _imageRevision.asStateFlow()
    val searchCardCount = repository.searchCardCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    val savedSearches = repository.savedSearches.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings = repository.settings
    val imagePackProgress = repository.imagePackProgress
    val mediumImagePackProgress = repository.mediumImagePackProgress

    private val _cacheProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val cacheProgress: StateFlow<Pair<Int, Int>?> = _cacheProgress.asStateFlow()

    private val _searchSyncing = MutableStateFlow(false)
    val searchSyncing: StateFlow<Boolean> = _searchSyncing.asStateFlow()

    private val _cardIndexStatus = MutableStateFlow(repository.localCardIndexStatus())
    val cardIndexStatus: StateFlow<CardIndexStatus> = _cardIndexStatus.asStateFlow()

    private val sessions = mutableMapOf<Long, PlaytestSession>()

    init {
        viewModelScope.launch {
            _searchSyncing.value = true
            repository.checkCardIndex { _cardIndexStatus.value = it }
            if (!_cardIndexStatus.value.ready) runCatching { repository.ensureSearchCatalog() }
            _searchSyncing.value = false
            runCatching { repository.checkImagePackUpdate() }
        }
        viewModelScope.launch {
            repository.resolvePending { done, total -> _cacheProgress.value = done to total }
            _cacheProgress.value = null
        }
    }

    fun observeDeck(deckId: Long) = repository.observeDeck(deckId)
    fun observeLogs(deckId: Long) = repository.observeLogs(deckId)

    fun refreshSearchCatalog() {
        viewModelScope.launch {
            _searchSyncing.value = true
            repository.checkCardIndex(force = false, manual = true) { _cardIndexStatus.value = it }
            if (!_cardIndexStatus.value.ready) runCatching { repository.ensureSearchCatalog(force = true) }
            _searchSyncing.value = false
        }
    }

    suspend fun searchCardNames(query: String): List<CardSearchEntity> = repository.searchCardNames(query)
    suspend fun searchCards(filter: CardSearchFilter, limit: Int = 40, offset: Int = 0): List<CardIndexRecord> = repository.searchCards(filter, limit, offset)
    suspend fun searchCardCount(filter: CardSearchFilter): Int = repository.searchCardCount(filter)
    suspend fun cardFilterOptions(): CardFilterOptions = repository.cardFilterOptions()
    fun loadSearchCardImage(card: CardIndexRecord, onDone: (String) -> Unit, onError: (String) -> Unit, force: Boolean = false) {
        viewModelScope.launch {
            runCatching { repository.cacheSearchCardImage(card, force) }
                .onSuccess { _imageRevision.value++; onDone(it) }
                .onFailure { onError(it.message ?: "画像取得に失敗しました") }
        }
    }
    suspend fun searchDetailImage(card: CardIndexRecord, face: Int, force: Boolean): String = repository.cacheSearchCardImage(card, force, face)
    suspend fun searchThumbnail(card: CardIndexRecord, face: Int = 0): String = repository.cacheSearchThumbnail(card, face)
    suspend fun searchHasBackFace(card: CardIndexRecord): Boolean = repository.searchHasBackFace(card)
    suspend fun tokenImage(token: TokenCandidate): String = repository.cacheTokenImage(token)
    fun hasMediumImage(card: CardIndexRecord): Boolean = repository.hasMediumImage(card)
    suspend fun checkDeckList(text: String): DeckListCheck = repository.checkDeckList(text)
    suspend fun validateDeck(cards: List<DeckCardEntity>): DeckValidation = repository.validateDeck(cards)
    suspend fun tokenCandidates(deckId: Long): List<TokenCandidate> = repository.tokenCandidates(deckId)
    fun loadTokenImage(token: TokenCandidate, onDone: (String) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { repository.cacheTokenImage(token) }
                .onSuccess(onDone)
                .onFailure { onError(it.message ?: "トークン画像取得に失敗しました") }
        }
    }

    fun searchSmallImagePath(card: CardIndexRecord): String = repository.smallImagePath(card.scryfallId)
    fun deckSmallImagePath(card: DeckCardEntity): String = repository.smallImagePath(card.scryfallId)
    fun searchPreferredImagePath(card: CardIndexRecord, face: Int = 0): String = repository.searchImagePath(card, face)
    fun deckPreferredImagePath(card: DeckCardEntity): String = repository.preferredPackImagePath(card.selectedPrintingId.ifBlank { card.scryfallId }, if (card.selectedPrintingId.isBlank()) card.oracleId else "")
    fun imagePackInstalled(): Boolean = repository.imagePackInstalled()
    fun mediumImagePackInstalled(): Boolean = repository.mediumImagePackInstalled()
    fun imagePackBytes(): Long = repository.imagePackBytes()
    fun imagePackImageCount(): Int = repository.imagePackImageCount()
    fun imagePackUpdatedAt(): String = repository.imagePackUpdatedAt()
    fun mediumImagePackBytes(): Long = repository.mediumImagePackBytes()
    fun mediumImagePackImageCount(): Int = repository.mediumImagePackImageCount()
    fun mediumImagePackUpdatedAt(): String = repository.mediumImagePackUpdatedAt()
    fun downloadImagePack(onDone: () -> Unit = {}, onError: (String) -> Unit = {}) {
        viewModelScope.launch { runCatching { repository.downloadImagePack() }.onSuccess { ok -> if (ok) onDone() else onError("軽量画像パックを取得できませんでした") }.onFailure { onError(it.message ?: "軽量画像パックの取得に失敗しました") } }
    }
    fun clearImagePack(onDone: (Long) -> Unit) { viewModelScope.launch { onDone(repository.clearImagePack()) } }
    fun downloadMediumImagePack(onDone: () -> Unit = {}, onError: (String) -> Unit = {}) { viewModelScope.launch { runCatching { repository.downloadMediumImagePack() }.onSuccess { if (it) onDone() else onError("標準画像パックを取得できませんでした") }.onFailure { onError(it.message ?: "標準画像パックの取得に失敗しました") } } }
    fun clearMediumImagePack(onDone: (Long) -> Unit) { viewModelScope.launch { onDone(repository.clearMediumImagePack()) } }

    fun saveSearch(filter: CardSearchFilter) { viewModelScope.launch { repository.saveSearch(filter) } }
    fun deleteSavedSearch(id: Long) { viewModelScope.launch { repository.deleteSavedSearch(id) } }

    fun isActiveNetworkMetered(): Boolean = repository.isActiveNetworkMetered()
    fun setThemeMode(mode: String) = repository.setThemeMode(mode)
    fun setBlockMeteredCardDbDownload(enabled: Boolean) = repository.setBlockMeteredCardDbDownload(enabled)
    fun setImagePreloadMode(mode: String) = repository.setImagePreloadMode(mode)
    fun setNormalOverMedium(enabled: Boolean) = repository.setNormalOverMedium(enabled)
    fun setSearchDisplayMode(mode: String) = repository.setSearchDisplayMode(mode)
    fun setLastSearchGrid(grid: Boolean) = repository.setLastSearchGrid(grid)

    fun createFolder(name: String, onDone: () -> Unit, onError: (String) -> Unit, parentId: Long? = null) {
        viewModelScope.launch { runCatching { repository.createFolder(name, parentId) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "フォルダ作成に失敗しました") } }
    }
    fun moveFolder(id: Long, parentId: Long?, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.moveFolder(id, parentId) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "フォルダ移動に失敗しました") } }
    }
    fun reorderFolder(id: Long, direction: Int, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.reorderFolder(id, direction) }.onFailure { onError(it.message ?: "並び替えに失敗しました") } }
    }
    fun renameFolder(id: Long, name: String, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.renameFolder(id, name) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "フォルダ名変更に失敗しました") } }
    }
    fun deleteFolder(id: Long, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.deleteFolder(id) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "フォルダ削除に失敗しました") } }
    }
    fun organizeDeck(id: Long, folder: Long?, note: String, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.organizeDeck(id, folder, note) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "保存に失敗しました") } }
    }
    fun reorderDeck(id: Long, direction: Int, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.reorderDeck(id, direction) }.onFailure { onError(it.message ?: "並び替えに失敗しました") } }
    }
    fun setDeckGrouping(id: Long, grouped: Boolean) { viewModelScope.launch { repository.setDeckGrouping(id, grouped) } }
    fun setDeckSort(id: Long, mode: String) { viewModelScope.launch { repository.setDeckSort(id, mode) } }
    fun saveCardEdits(deckId: Long, cardId: Long, quantity: Int, category: String, role: String, special: String, onDone: () -> Unit, onError: (String) -> Unit) {
        edit(deckId, "カードの変更を保存しました", onDone = { onDone() }, onError = onError, notifyError = false) { repository.saveCardEdits(cardId, quantity, category, role, special) }
    }
    fun updateCategories(ids: List<Long>, category: String, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.updateCategories(ids, category) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "カテゴリ変更に失敗しました") } }
    }
    suspend fun imageCacheBytes(): Long = repository.imageCacheBytes()
    fun clearImageCache(onDone: (Long) -> Unit) { viewModelScope.launch { onDone(repository.clearImageCache()) } }

    fun createDeck(name: String, firstCard: String?, commander: Boolean, onCreated: (Long) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            runCatching {
                val deckId = repository.createDeck(name)
                if (!firstCard.isNullOrBlank()) {
                    repository.addSingleCard(deckId, firstCard, commander = commander)
                    launch { resolveDeck(deckId) }
                }
                deckId
            }.onSuccess(onCreated).onFailure { onError(it.message ?: "デッキ作成に失敗しました") }
        }
    }

    fun importDeck(name: String, text: String, onCreated: (Long) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { repository.importDeck(name, text) }
                .onSuccess { deckId -> onCreated(deckId); launch { resolveDeck(deckId) } }
                .onFailure { onError(it.message ?: "インポートに失敗しました") }
        }
    }

    fun addSingleCard(deckId: Long, name: String, quantity: Int, commander: Boolean,
        role: String = if (commander) DeckRoles.COMMANDER else DeckRoles.MAIN,
        onDone: (Int) -> Unit, onError: (String) -> Unit) {
        edit(deckId, "", true, onDone, onError, notifyError = false, messageForResult = { count -> "${if (role == DeckRoles.CANDIDATE) "候補" else "メイン"}に${count}枚追加" }) {
            repository.addSingleCard(deckId, name, quantity, commander, role)
        }
    }
    fun addCards(deckId: Long, text: String, role: String = DeckRoles.MAIN, onDone: (Int) -> Unit, onError: (String) -> Unit) {
        edit(deckId, "", true, onDone, onError, notifyError = false, messageForResult = { count -> "${if (role == DeckRoles.CANDIDATE) "候補" else "メイン"}に${count}枚追加" }) { repository.addCards(deckId, text, role) }
    }
    fun addIndexCards(deckId: Long, records: List<CardIndexRecord>, role: String, onDone: (Int) -> Unit, onError: (String) -> Unit) {
        edit(deckId, "", true, onDone, onError, notifyError = false, messageForResult = { count -> "${if (role == DeckRoles.CANDIDATE) "候補" else "メイン"}に${count}枚追加" }) { repository.addIndexCards(deckId, records, role) }
    }
    fun adjustQuantity(deckId: Long, card: DeckCardEntity, delta: Int) {
        edit(deckId, "枚数を変更しました") { repository.adjustQuantity(card, delta) }
    }
    fun moveRole(deckId: Long, card: DeckCardEntity, role: String) {
        moveCards(deckId, listOf(card.id), role)
    }
    fun moveCards(deckId: Long, ids: List<Long>, role: String, onDone: () -> Unit = {}) {
        edit(deckId, "${ids.size}件を${if (role == DeckRoles.CANDIDATE) "候補" else "メイン"}へ移動しました", onDone = { _: Unit -> onDone() }) { repository.moveCards(ids, role) }
    }
    fun setSpecialRole(deckId: Long, card: DeckCardEntity, specialRole: String) {
        edit(deckId, "役割を変更しました") { repository.setSpecialRole(card, specialRole) }
    }
    fun deleteCard(deckId: Long, card: DeckCardEntity) { deleteCards(deckId, listOf(card.id)) }
    fun deleteCards(deckId: Long, ids: List<Long>) {
        edit(deckId, "${ids.size}件を削除しました") { repository.deleteCards(ids) }
    }

    fun loadPrintingOptions(card: DeckCardEntity, onDone: (List<ScryfallClient.PrintingOption>) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.printingOptions(card) }.onSuccess(onDone).onFailure { onError(it.message ?: "絵柄候補の取得に失敗しました") } }
    }
    fun loadPrintingThumbnail(option: ScryfallClient.PrintingOption, onDone: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.cachePrintingThumbnail(option) }.onSuccess(onDone) }
    }
    fun selectPrinting(deckId: Long, card: DeckCardEntity, option: ScryfallClient.PrintingOption, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.selectPrinting(card, option) }.onSuccess { sessions.remove(deckId); onDone() }.onFailure { onError(it.message ?: "絵柄変更に失敗しました") } }
    }

    fun retryCardWithName(deckId: Long, card: DeckCardEntity, name: String, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            runCatching { repository.retryCardWithName(card, name) }
                .onSuccess { sessions.remove(deckId); onDone() }
                .onFailure { onError(it.message ?: "カード名の再照合に失敗しました") }
        }
    }

    fun copyDeck(deckId: Long, onDone: (Long) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.copyDeck(deckId) }.onSuccess(onDone).onFailure { onError(it.message ?: "デッキコピーに失敗しました") } }
    }

    fun renameDeck(deckId: Long, name: String, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.renameDeck(deckId, name) }.onSuccess { onDone() }.onFailure { onError(it.message ?: "デッキ名変更に失敗しました") } }
    }

    fun deleteDeck(deckId: Long, onDone: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch { runCatching { repository.deleteDeckById(deckId) }.onSuccess { sessions.remove(deckId); onDone() }.onFailure { onError(it.message ?: "デッキ削除に失敗しました") } }
    }

    fun retryMissingImages(deckId: Long) {
        viewModelScope.launch {
            repository.refreshMissingImages(deckId) { done, total -> _cacheProgress.value = done to total }
            _cacheProgress.value = null
        }
    }

    fun updateCategory(cardId: Long, category: String) { viewModelScope.launch { repository.updateCategory(cardId, category) } }

    fun setCommander(deckId: Long, cardId: Long) {
        edit(deckId, "統率者を設定しました") { repository.setCommander(deckId, cardId) }
    }

    fun export(cards: List<DeckCardEntity>): String = repository.exportHareruya(cards)
    fun exportEnglish(cards: List<DeckCardEntity>): String = repository.exportEnglish(cards)
    fun exportSelected(cards: List<DeckCardEntity>, english: Boolean): String = if (english) repository.exportEnglish(cards, true) else repository.exportHareruya(cards, true)
    suspend fun getCards(deckId: Long): List<DeckCardEntity> = repository.getCards(deckId)

    fun playtest(deckId: Long): PlaytestSession = sessions.getOrPut(deckId) { PlaytestSession() }

    fun ensurePlaytest(deckId: Long) {
        val session = playtest(deckId)
        if (session.state.value.cards.isNotEmpty()) return
        viewModelScope.launch { session.newGame(repository.getPlaytestCards(deckId)) }
    }

    fun newGame(deckId: Long) {
        val session = playtest(deckId)
        viewModelScope.launch { session.newGame(repository.getPlaytestCards(deckId)) }
    }

    private suspend fun resolveDeck(deckId: Long) {
        repository.resolveDeck(deckId) { done, total -> _cacheProgress.value = done to total }
        _cacheProgress.value = null
    }
}

class AppViewModelFactory(private val repository: DeckRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AppViewModel(repository) as T
}
