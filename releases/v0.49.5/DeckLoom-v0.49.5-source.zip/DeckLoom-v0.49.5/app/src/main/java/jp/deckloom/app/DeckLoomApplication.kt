package jp.deckloom.app

import android.app.Application
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import jp.deckloom.app.data.AppDatabase
import jp.deckloom.app.data.AppSettingsStore
import jp.deckloom.app.data.CardIndexStore
import jp.deckloom.app.data.DeckRepository
import jp.deckloom.app.network.CardImageStore
import jp.deckloom.app.network.ScryfallClient
import jp.deckloom.app.network.SmallImagePackStore
import jp.deckloom.app.network.MediumImagePackStore

class DeckLoomApplication : Application() {
    lateinit var repository: DeckRepository
        private set
    lateinit var settingsStore: AppSettingsStore
        private set

    override fun onCreate() {
        super.onCreate()
        settingsStore = AppSettingsStore(this)
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "deckloom.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
            .build()
        repository = DeckRepository(
            context = this,
            db = db,
            scryfall = ScryfallClient(),
            imageStore = CardImageStore(this),
            smallImagePack = SmallImagePackStore(this),
            mediumImagePack = MediumImagePackStore(this),
            cardIndex = CardIndexStore(this),
            settingsStore = settingsStore,
        )
    }

    companion object {
        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE decks ADD COLUMN groupByCategory INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN addedAt INTEGER NOT NULL DEFAULT 0")
                // Historical timestamps are unknown; keep their original insertion order.
                db.execSQL("UPDATE deck_cards SET addedAt = id")
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE deck_folders ADD COLUMN parentId INTEGER DEFAULT NULL REFERENCES deck_folders(id) ON UPDATE NO ACTION ON DELETE SET NULL")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_deck_folders_parentId ON deck_folders(parentId)")
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS deck_folders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, sortOrder INTEGER NOT NULL)")
                db.execSQL("ALTER TABLE decks ADD COLUMN folderId INTEGER DEFAULT NULL REFERENCES deck_folders(id) ON UPDATE NO ACTION ON DELETE SET NULL")
                db.execSQL("ALTER TABLE decks ADD COLUMN note TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE decks ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE decks ADD COLUMN cardSortMode TEXT NOT NULL DEFAULT 'REGISTERED'")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_decks_folderId ON decks(folderId)")
                db.execSQL("UPDATE decks SET sortOrder = (SELECT COUNT(*) FROM decks AS other WHERE other.createdAt > decks.createdAt OR (other.createdAt = decks.createdAt AND other.id > decks.id))")
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN userCategory TEXT NOT NULL DEFAULT ''")
                db.execSQL("UPDATE deck_cards SET userCategory = category WHERE category NOT IN ('Land','Creature','Artifact','Enchantment','Instant','Sorcery','Planeswalker','Battle','Other','未分類','')")
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS card_search (
                        searchKey TEXT NOT NULL PRIMARY KEY,
                        normalizedName TEXT NOT NULL,
                        displayName TEXT NOT NULL,
                        oracleName TEXT NOT NULL,
                        language TEXT NOT NULL,
                        source TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_card_search_normalizedName ON card_search(normalizedName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_card_search_oracleName ON card_search(oracleName)")
            }
        }


        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN selectedPrintingId TEXT NOT NULL DEFAULT ''")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN specialRole TEXT NOT NULL DEFAULT 'NONE'")
                db.execSQL("UPDATE deck_cards SET specialRole = 'COMMANDER', deckRole = 'MAIN', isCommander = 1 WHERE deckRole = 'COMMANDER' OR isCommander = 1")
                db.execSQL("UPDATE deck_cards SET specialRole = 'COMPANION_BACKGROUND', deckRole = 'MAIN', isCommander = 0 WHERE deckRole IN ('SECOND_COMMANDER','COMPANION')")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN oracleId TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE deck_cards ADD COLUMN deckRole TEXT NOT NULL DEFAULT 'MAIN'")
                db.execSQL("UPDATE deck_cards SET deckRole = 'COMMANDER' WHERE isCommander = 1")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_deck_cards_deckId_deckRole ON deck_cards(deckId, deckRole)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS deck_change_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        deckId INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL,
                        action TEXT NOT NULL,
                        cardName TEXT NOT NULL,
                        quantity INTEGER NOT NULL,
                        fromRole TEXT NOT NULL,
                        toRole TEXT NOT NULL,
                        note TEXT NOT NULL,
                        FOREIGN KEY(deckId) REFERENCES decks(id) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_deck_change_log_deckId ON deck_change_log(deckId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_deck_change_log_deckId_createdAt ON deck_change_log(deckId, createdAt)")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS saved_searches (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        createdAt INTEGER NOT NULL,
                        description TEXT NOT NULL,
                        filterJson TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_saved_searches_createdAt ON saved_searches(createdAt)")
            }
        }
    }
}
