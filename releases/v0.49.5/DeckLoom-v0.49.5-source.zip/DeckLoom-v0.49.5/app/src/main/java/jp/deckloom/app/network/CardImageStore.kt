package jp.deckloom.app.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException

class CardImageStore(private val context: Context) {
    private val locks = Array(16) { Mutex() }
    private val directory: File by lazy {
        File(context.filesDir, "deck_cards").apply { mkdirs() }
    }

    fun cachedPath(cardId: String, side: String = "front"): String {
        if (cardId.isBlank()) return ""
        return File(directory, "$cardId-$side.jpg").takeIf { it.isFile && it.length() > 0 }?.absolutePath.orEmpty()
    }

    suspend fun cache(cardId: String, url: String, side: String = "front"): String = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext ""
        val safeId = cardId.ifBlank { url.hashCode().toString() }
        val file = File(directory, "$safeId-$side.jpg")
        locks[(file.name.hashCode() and Int.MAX_VALUE) % locks.size].withLock {
        if (file.exists() && file.length() > 0) return@withContext file.absolutePath
        val temporary = File(directory, "${file.name}.part")
        var lastError: Throwable? = null
        repeat(3) { attempt ->
            try {
                download(url, temporary)
                check(temporary.length() > 0 && temporary.renameTo(file)) { "画像を保存できませんでした" }
                return@withContext file.absolutePath
            } catch (t: Throwable) {
                temporary.delete()
                if (!t.isTransientNetworkError() || attempt == 2) throw t
                lastError = t
                delay(450L * (attempt + 1))
            }
        }
        throw lastError ?: IOException("Image download failed")
        }
    }


    suspend fun cacheBytes(): Long = withContext(Dispatchers.IO) {
        directory.listFiles()?.sumOf { if (it.isFile) it.length() else 0L } ?: 0L
    }

    suspend fun clear(): Long = withContext(Dispatchers.IO) {
        val files = directory.listFiles().orEmpty().filter { it.isFile }
        val bytes = files.sumOf { it.length() }
        files.forEach { it.delete() }
        bytes
    }

    private fun download(url: String, file: File) {
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "DeckLoom/0.49 Android local-deck-manager")
            val code = conn.responseCode
            if (code !in 200..299) error("Image HTTP $code")
            conn.inputStream.use { input ->
                file.outputStream().use { output -> input.copyTo(output) }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun Throwable.isTransientNetworkError(): Boolean =
        this is UnknownHostException || this is SocketTimeoutException || this is ConnectException || this is IOException
}
