package jp.deckloom.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private data class ScrollbarMetrics(
    val thumbFraction: Float,
    val positionFraction: Float,
)

@Composable
fun BoxScope.VerticalFastScrollbar(
    state: LazyListState,
    modifier: Modifier = Modifier,
) {
    val total = state.layoutInfo.totalItemsCount
    val visible = state.layoutInfo.visibleItemsInfo.size
    FastScrollbar(
        totalItems = total,
        visibleItems = visible,
        firstVisibleItemIndex = state.firstVisibleItemIndex,
        onScrollToIndex = { state.scrollToItem(it) },
        modifier = modifier,
    )
}

@Composable
fun BoxScope.VerticalFastScrollbar(
    state: LazyGridState,
    modifier: Modifier = Modifier,
) {
    val total = state.layoutInfo.totalItemsCount
    val visible = state.layoutInfo.visibleItemsInfo.size
    FastScrollbar(
        totalItems = total,
        visibleItems = visible,
        firstVisibleItemIndex = state.firstVisibleItemIndex,
        onScrollToIndex = { state.scrollToItem(it) },
        modifier = modifier,
    )
}

@Composable
private fun BoxScope.FastScrollbar(
    totalItems: Int,
    visibleItems: Int,
    firstVisibleItemIndex: Int,
    onScrollToIndex: suspend (Int) -> Unit,
    modifier: Modifier,
) {
    if (totalItems <= 0 || visibleItems <= 0 || totalItems <= visibleItems) return

    val scope = rememberCoroutineScope()
    var trackHeightPx by remember { mutableIntStateOf(1) }
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }

    val metrics = remember(totalItems, visibleItems, firstVisibleItemIndex) {
        val thumb = (visibleItems.toFloat() / totalItems.toFloat()).coerceIn(0.08f, 0.72f)
        val maxFirst = (totalItems - visibleItems).coerceAtLeast(1)
        val pos = (firstVisibleItemIndex.toFloat() / maxFirst.toFloat()).coerceIn(0f, 1f)
        ScrollbarMetrics(thumb, pos)
    }

    LaunchedEffect(metrics.positionFraction, dragging) {
        if (!dragging) dragFraction = metrics.positionFraction
    }

    val thumbHeightPx = (trackHeightPx * metrics.thumbFraction).coerceAtLeast(28f)
    val travelPx = (trackHeightPx - thumbHeightPx).coerceAtLeast(1f)
    val thumbOffsetPx = travelPx * dragFraction

    val draggableState = rememberDraggableState { delta ->
        dragFraction = (dragFraction + delta / travelPx).coerceIn(0f, 1f)
        val target = (dragFraction * (totalItems - 1)).roundToInt().coerceIn(0, totalItems - 1)
        scope.launch { onScrollToIndex(target) }
    }

    Box(
        modifier = modifier
            .align(Alignment.CenterEnd)
            .fillMaxHeight()
            .width(16.dp)
            .padding(vertical = 4.dp, horizontal = 4.dp)
            .onSizeChanged { trackHeightPx = it.height.coerceAtLeast(1) }
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStarted = { dragging = true },
                onDragStopped = { dragging = false },
            ),
    ) {
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxHeight()
                .width(3.dp)
                .clip(MaterialTheme.shapes.extraSmall)
                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
        )
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .offset { IntOffset(0, thumbOffsetPx.roundToInt()) }
                .width(8.dp)
                .height(with(androidx.compose.ui.platform.LocalDensity.current) { thumbHeightPx.toDp() })
                .clip(MaterialTheme.shapes.small)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = if (dragging) 0.95f else 0.72f))
        )
    }
}
