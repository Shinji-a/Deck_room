package jp.deckloom.app.ui

import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/** Hysteresis uses accumulated dp; small direction changes and horizontal drags do not toggle. */
@Composable
fun rememberHeaderScrollConnection(onCollapsed: (Boolean) -> Unit): NestedScrollConnection {
    val update by rememberUpdatedState(onCollapsed)
    val density = LocalDensity.current
    val hide = with(density) { 84.dp.toPx() }
    val show = with(density) { 44.dp.toPx() }
    return remember(hide, show) {
        object : NestedScrollConnection {
            var distance = 0f
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput || abs(available.y) < abs(available.x)) return Offset.Zero
                if (distance * available.y < 0) distance = 0f
                distance += available.y
                if (distance <= -hide) { update(true); distance = 0f }
                if (distance >= show) { update(false); distance = 0f }
                return Offset.Zero
            }
        }
    }
}
