package jp.deckloom.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.em

@Composable
fun ManaText(text: String, modifier: Modifier = Modifier, style: TextStyle = LocalTextStyle.current, maxLines: Int = Int.MAX_VALUE, overflow: TextOverflow = TextOverflow.Clip) {
    val parsed = remember(text) {
        buildAnnotatedString {
            var offset = 0
            // ICU (Android) requires the closing brace to be escaped too.
            Regex("\\{[^}]+\\}").findAll(text).forEach { match ->
                append(text.substring(offset, match.range.first))
                if (match.value in manaDrawables) appendInlineContent(match.value, match.value) else append(match.value)
                offset = match.range.last + 1
            }
            append(text.substring(offset))
        }
    }
    val symbols = remember(text) { manaDrawables.filterKeys { text.contains(it) } }
    val inline = symbols.mapValues { (symbol, resource) ->
        InlineTextContent(Placeholder(1.12.em, 1.12.em, PlaceholderVerticalAlign.TextCenter)) {
            Image(painterResource(resource), contentDescription = symbol, modifier = Modifier.fillMaxSize())
        }
    }
    Text(parsed, modifier = modifier, style = style, inlineContent = inline, maxLines = maxLines, overflow = overflow)
}
