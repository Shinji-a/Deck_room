package jp.deckloom.app.data

private val quantityRegex = Regex("^\\s*(\\d+)\\s*[xX]?\\s+(.+?)\\s*$")
private val setSuffixRegex = Regex("\\s+\\([A-Za-z0-9]+\\)\\s+[^\\s]+\\s*$")
private val categoryRegex = Regex("\\s*\\[([^]]+)]\\s*$")

data class ParsedDeckLine(
    val quantity: Int,
    val name: String,
    val category: String,
    val isCommander: Boolean,
)

object DeckListParser {
    fun parse(text: String): List<ParsedDeckLine> = buildList {
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isBlank() || line.startsWith("#") || line.startsWith("//")) return@forEach
            val match = quantityRegex.matchEntire(line) ?: return@forEach
            val quantity = match.groupValues[1].toIntOrNull() ?: return@forEach
            var rest = match.groupValues[2].trim()
            val categoryMatch = categoryRegex.find(rest)
            val categoryRaw = categoryMatch?.groupValues?.get(1)?.trim().orEmpty()
            if (categoryMatch != null) rest = rest.removeRange(categoryMatch.range).trim()
            rest = rest.replace(setSuffixRegex, "").trim()
            val isCommander = categoryRaw.equals("Commander", true) || categoryRaw.equals("統率者", true)
            val category = when {
                isCommander -> "Commander"
                categoryRaw.isNotBlank() -> categoryRaw
                else -> "未分類"
            }
            if (rest.isNotBlank()) add(ParsedDeckLine(quantity, rest, category, isCommander))
        }
    }
}
