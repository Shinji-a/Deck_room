package jp.deckloom.app.data

internal data class TokenNameQuery(val sql: String, val args: List<String>)

internal object TokenQueries {
    fun byName(name: String, power: String? = null, toughness: String? = null): TokenNameQuery {
        val conditions = mutableListOf("(english_name = ? COLLATE NOCASE OR japanese_name = ?)")
        val args = mutableListOf(name, name)
        // Android rawQuery binds every selection argument as a non-null String.
        // Omit an unspecified P/T condition instead of binding null or an empty substitute.
        if (power != null) {
            conditions += "power = ?"
            args += power
        }
        if (toughness != null) {
            conditions += "toughness = ?"
            args += toughness
        }
        return TokenNameQuery(
            sql = """SELECT token_key, english_name, COALESCE(japanese_name,''),
                COALESCE(NULLIF(japanese_type_line,''), english_type_line), COALESCE(power,''), COALESCE(toughness,''),
                COALESCE(NULLIF(japanese_image_normal,''), preferred_image_normal),
                COALESCE(NULLIF(japanese_scryfall_id,''), preferred_scryfall_id),
                COALESCE(NULLIF(japanese_text,''), english_oracle_text,'')
                FROM tokens WHERE ${conditions.joinToString(" AND ")} LIMIT 1""".trimIndent(),
            args = args,
        )
    }
}
