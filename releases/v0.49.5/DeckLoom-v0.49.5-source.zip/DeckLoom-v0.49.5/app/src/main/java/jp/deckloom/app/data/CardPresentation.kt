package jp.deckloom.app.data

/** Only kana readings attached to a preceding kanji are removed; other parentheses survive. */
object CardNames {
    private val reading = Regex("(?<=[\\p{IsHan}々〆ヶ])[（(][ぁ-ゖァ-ヺーゝゞヽヾ]+[）)]")
    fun clean(value: String): String = reading.replace(value, "").trim()
}

object CardCategories {
    val automatic = setOf("Land", "Creature", "Artifact", "Enchantment", "Instant", "Sorcery", "Planeswalker", "Battle", "Other", "未分類")
    fun fromType(type: String): String = automatic.firstOrNull { it != "Other" && it != "未分類" && type.contains(it, ignoreCase = true) } ?: "Other"
    fun imported(category: String): String = category.trim().takeUnless { it in automatic }.orEmpty()
    fun display(card: DeckCardEntity): String = card.userCategory.ifBlank {
        if (card.cacheState == "ERROR" && card.oracleId.isBlank() && card.oracleName.isBlank()) "DB未認識" else fromType(card.oracleTypeLine)
    }
}

object DeckCardSorting {
    val labels = linkedMapOf("ADDED_DESC" to "追加が新しい順", "REGISTERED" to "追加が古い順", "MV_ASC" to "MVが少ない順", "MV_DESC" to "MVが多い順", "NAME" to "名前順")
    fun sort(cards: List<DeckCardEntity>, mode: String, grouped: Boolean = true): List<DeckCardEntity> {
        val byName = compareBy<DeckCardEntity> { CardNames.clean(it.displayName.ifBlank { it.inputName }) }.thenBy { it.id }
        val within = when (mode) {
            "ADDED_DESC" -> compareByDescending<DeckCardEntity> { it.addedAt }.thenByDescending { it.id }
            "MV_ASC" -> compareBy<DeckCardEntity> { it.oracleId.isBlank() && it.oracleName.isBlank() }.thenBy { it.cmc }.then(byName)
            "MV_DESC" -> compareBy<DeckCardEntity> { it.oracleId.isBlank() && it.oracleName.isBlank() }.thenByDescending { it.cmc }.then(byName)
            "NAME" -> byName
            else -> compareBy<DeckCardEntity> { it.addedAt }.thenBy { it.id }
        }
        if (!grouped) return cards.sortedWith(within)
        return cards.groupBy(CardCategories::display).entries
            .sortedWith(compareByDescending<Map.Entry<String, List<DeckCardEntity>>> { (_, group) -> group.any { it.specialRole == DeckSpecialRoles.COMMANDER } }.thenBy { it.key })
            .flatMap { (_, group) -> group.sortedWith(compareByDescending<DeckCardEntity> { it.specialRole == DeckSpecialRoles.COMMANDER }.then(within)) }
    }
}

object DeckExports {
    fun exportEnglish(cards: List<DeckCardEntity>, selectedOnly: Boolean = false): String = cards
        .filter { selectedOnly || DeckRoles.countsTowardDeck(it.deckRole) }
        .sortedWith(compareByDescending<DeckCardEntity> { it.specialRole == DeckSpecialRoles.COMMANDER }.thenBy { CardCategories.display(it) }.thenBy { it.oracleName.ifBlank { it.inputName } })
        .joinToString("\n") { card -> "${card.quantity} ${card.oracleName.ifBlank { card.inputName }}" }

    fun exportHareruya(cards: List<DeckCardEntity>, selectedOnly: Boolean = false): String = cards
        .filter { selectedOnly || DeckRoles.countsTowardDeck(it.deckRole) }
        .sortedWith(compareByDescending<DeckCardEntity> { it.specialRole == DeckSpecialRoles.COMMANDER }.thenBy { CardCategories.display(it) }.thenBy { it.displayName.ifBlank { it.inputName } })
        .joinToString("\n") { card -> "${card.quantity} ${CardNames.clean(card.displayName.ifBlank { card.oracleName.ifBlank { card.inputName } })}" }

}
