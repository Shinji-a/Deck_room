package jp.deckloom.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HowToScreen(onBack: () -> Unit) {
    Scaffold(topBar = {
        DeckroomTopAppBar(
            title = { Text("DeckLoom README") },
            navigationIcon = { DeckroomIconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "戻る") } },
        )
    }) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("DeckLoom v${jp.deckloom.app.BuildConfig.VERSION_NAME}について", style = MaterialTheme.typography.titleLarge)
            Text("Magic: The Gatheringのデッキ管理と一人回しを手軽に行うためのアプリです。完全なルール処理は行わず、実際のカードを机の上で動かすようにユーザー自身で操作するサンドボックス型を基本としています。")

            HelpSection("デッキ", "デッキを新規作成するか、カードリストを貼り付けてインポートできます。カード名は日本語・英語のどちらにも対応しています。かなの読み仮名が括弧で入る日本語名は、読み仮名を省いた形でも検索できます。メイン、統率者、候補などの役割を設定でき、カードごとに使用する印刷版 / 絵柄も選べます。候補カードは100枚のデッキ枚数には含まれません。")
            HelpSection("デッキの整理", "フォルダは横一列に並び、左右にスクロールできます。タップして中へ入り、戻るボタンで親へ戻ります。長押しで名前・移動先・左右の順序を変更でき、一覧ボタンや画面タイトルから階層を検索できます。各デッキのメニューでは移動、一口メモ、上下の順序を変更できます。フォルダ削除時はデッキと子フォルダが親へ戻ります。")
            HelpSection("デッキ内の検索・分類", "検索欄は入力するだけで絞り込めます。虫眼鏡の▼から名前＋本文、名前、本文を選び、右の並び順アイコンでソートします。カード一覧を左右にスワイプするとカテゴリが切り替わります。メイン・候補・履歴はタブをタップして切り替えます。並び順は追加が新しい順・古い順、MVが少ない順・多い順、名前順。「種類別にまとめる」をオフにすると、すべてタブでは分類をまたいで並びます。この設定はデッキごとに保存され、個別カテゴリには影響しません。候補からメインへ移したカードは新しい追加として扱います。ユーザーカテゴリを指定するとタイプ別の自動分類より優先され、空欄に戻すと自動分類へ戻ります。長押しで複数選択すると一括カテゴリ変更と選択分だけの晴れる屋／英語出力ができます。")
            HelpSection("カードの編集", "カード詳細で枚数、メイン／候補、統率者・相棒／背景、カテゴリを編集し、保存でまとめて確定します。変更したまま閉じる場合は保存または破棄を選べます。保存できない理由は保存ボタンのすぐ上に表示され、保存前の候補データは残ります。下部は閉じる・削除・保存の順です。追加・削除・移動・編集の直後は通知の「元に戻す」で取り消せます。一括追加も、その操作で増やした全件を一回で取り消します。")
            HelpSection("採用枚数", "検索DBの枚数上限で通常1枚、基本土地や任意枚数・上限付きカードを判定します。統率者なども合算し、候補は対象外です。一括追加の途中だけは反映しません。未照合カードは上限未確認として扱い、すでにある超過カードは勝手に削除しません。")
            HelpSection("カード検索", "端末内のカード検索DBを使用します。カード名、ルール文章、色、カードタイプ、マナ総量、P/T、収録セットなどで絞り込めます。結果は40件ずつ表示します。通常の検索操作ごとにScryfallへ問い合わせる方式ではありません。画面名の横の状態アイコンからDBの状態と更新日時を確認できます。両面カードの画像では表面・裏面を切り替えられます。")
            HelpSection("一人回し", "初手7枚から開始し、手札、戦場、墓地、追放、ライブラリー、統率領域の間でカードを自由に移動できます。数値カウンター、汎用マーカー、両面カードの裏面表示、任意カードの裏向き表示を利用できます。特殊な処理や裁定はユーザー自身で管理してください。上部のUndo / Redoで操作を戻したりやり直したりできます。ライフの▼で数値を変更し、表示アイコンで拡大・縮小や戦場の移動を設定します。手札下の一列には手札一覧、左右移動、次のターン、メニューをまとめています。")
            HelpSection("領域一覧", "デッキ・手札・墓地などは即時検索でき、虫眼鏡の▼で名前／本文を選べます。画像をドラッグすると一覧が透過し、戦場の好きな位置や各領域へ置けます。リスト表示でドラッグできるのはサムネイルだけです。上部の専用キャンセルへ放すか戻るで取り消せます。タップした詳細からも移動でき、移動後は一覧を続けて使えます。")
            HelpSection("トークン", "候補をタップするたびに1体ずつ追加できます。画像は順次取得します。追加後もウィンドウは開いたままで、閉じる、窓の外、戻る操作で閉じられます。下部のデッキと墓地から一番上のカードをドラッグする操作も引き続き使えます。")
            HelpSection("カードデータ・利用元", "Scryfall（scryfall.com）：カード情報・英語Oracle・画像の主な取得元。MTGJSON（mtgjson.com）：不足する日本語情報の照合・補完。Wisdom Guild / WHISPER（whisper.wisdom-guild.net）：残る日本語名・本文の補完。日本公式サイト（mtg-jp.com）：日本語ギャラリーのテキスト情報による補完・記号画像。日本語補完データは Wisdom Guild / WHISPER より転載。独自の日本語訳を含み、公式の印刷本文とは限りません。検索用DBは端末に保存され、通常の検索でWHISPERに都度アクセスする方式ではありません。生成側で直列取得・取得間隔・キャッシュ・出典記録を管理します。")
            HelpSection("画像", "画像の事前ダウンロードは『なし / small / Medium』から選べます。smallはサムネイル向けの軽量パック、Mediumは400px WebPの標準閲覧用パックです。どちらも任意です。Mediumがあるカードのnormal自動取得は設定で切り替えられ、初期値はオフです。Mediumがないカードや指定した印刷版は必要な画像を取得し、取得済みnormalも利用します。検索詳細では高画質を手動取得できます。")
            HelpSection("表示設定", "ライト、ダーク、端末設定に従う、の3種類から選択できます。カード検索を開いた時の表示は、前回の表示、リスト、画像グリッドから選べます。マナやタップなどの記号には公式カードギャラリーの画像を使い、未収録の記号は元の文字表記を残します。")
            HelpSection("注意", "DeckLoomは非公式のMTG支援アプリです。正式なルール処理や裁定についてはMagic: The Gatheringの公式ルール等を確認してください。")
            HorizontalDivider()
            Text("ファンコンテンツについて", style = MaterialTheme.typography.titleMedium)
            Text("DeckLoomは非公式のファンコンテンツです。Magic: The Gatheringおよび関連する名称・画像・カードデータ等の権利は各権利者に帰属します。本アプリはWizards of the Coastの承認・提携を受けた公式製品ではありません。")
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HelpSection(title: String, body: String) {
    Text(title, style = MaterialTheme.typography.titleMedium)
    Text(body, style = MaterialTheme.typography.bodyMedium)
}
