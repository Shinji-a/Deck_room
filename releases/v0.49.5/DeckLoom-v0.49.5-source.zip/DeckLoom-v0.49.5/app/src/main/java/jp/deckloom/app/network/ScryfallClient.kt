package jp.deckloom.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URLEncoder
import java.net.UnknownHostException
import java.nio.charset.StandardCharsets
import jp.deckloom.app.data.CardNames
import jp.deckloom.app.data.CardLocalization

class ScryfallClient {
    class RateLimitedException(val retryAfterMillis: Long, message: String) : IOException(message)
    private val limiter = Mutex()
    private var lastRequestAt = 0L

    data class PrintingOption(
        val scryfallId: String,
        val label: String,
        val setCode: String,
        val releasedAt: String,
        val imageUrl: String,
        val thumbnailUrl: String,
        val backImageUrl: String,
        val lang: String,
    )

    data class ResolvedCard(
        val scryfallId: String,
        val oracleId: String,
        val oracleName: String,
        val displayName: String,
        val printedName: String,
        val displayTypeLine: String,
        val oracleTypeLine: String,
        val oracleText: String,
        val manaCost: String,
        val cmc: Double,
        val colorIdentity: String,
        val imageUrl: String,
        val thumbnailUrl: String,
        val backImageUrl: String,
        val backThumbnailUrl: String = "",
    )

    suspend fun cardNameCatalog(): List<String> = withContext(Dispatchers.IO) {
        val root = getJson("https://api.scryfall.com/catalog/card-names")
        val data = root.optJSONArray("data") ?: return@withContext emptyList()
        buildList(data.length()) {
            for (i in 0 until data.length()) {
                data.optString(i).takeIf { it.isNotBlank() }?.let(::add)
            }
        }
    }

    suspend fun resolve(name: String): ResolvedCard = withContext(Dispatchers.IO) {
        val base = try {
            getJson(namedUrl(name))
        } catch (t: Throwable) {
            // Only fall back to multilingual search for a real lookup miss.
            // DNS/timeouts/rate limits must bubble up instead of triggering another burst of API calls.
            if (t is RateLimitedException || t.isTransientNetworkError()) throw t
            searchAnyLanguage(name)
        }
        val japanese = findJapanesePrinting(base) ?: base
        toResolved(base, japanese)
    }


    suspend fun printings(scryfallId: String): List<PrintingOption> = withContext(Dispatchers.IO) {
        val base = getJson("https://api.scryfall.com/cards/${enc(scryfallId)}")
        var url = base.optString("prints_search_uri")
        if (url.isBlank()) return@withContext emptyList()
        url += if (url.contains("?")) "&include_multilingual=true" else "?include_multilingual=true"
        val out = mutableListOf<PrintingOption>()
        var pages = 0
        while (url.isNotBlank() && pages < 12) {
            pages++
            val root = getJson(url)
            val data = root.optJSONArray("data") ?: break
            for (i in 0 until data.length()) {
                val c = data.optJSONObject(i) ?: continue
                val (front, back) = imageUrls(c)
                val thumb = smallImageUrl(c).ifBlank { front }
                if (front.isBlank()) continue
                val name = CardNames.clean(c.optString("printed_name").ifBlank { c.optString("name") })
                val set = c.optString("set").uppercase()
                val lang = c.optString("lang")
                out += PrintingOption(
                    scryfallId = c.optString("id"),
                    label = "$name / $set / $lang",
                    setCode = set,
                    releasedAt = c.optString("released_at"),
                    imageUrl = front,
                    thumbnailUrl = thumb,
                    backImageUrl = back,
                    lang = lang,
                )
            }
            if (!root.optBoolean("has_more")) break
            url = root.optString("next_page")
        }
        out.distinctBy { it.scryfallId }.sortedWith(compareByDescending<PrintingOption> { it.lang == "ja" }.thenByDescending { it.releasedAt })
    }

    suspend fun resolveById(scryfallId: String, localize: Boolean = true): ResolvedCard = withContext(Dispatchers.IO) {
        val base = getJson("https://api.scryfall.com/cards/${enc(scryfallId)}")
        val localized = if (!localize || base.optString("lang") == "ja") base else findJapanesePrinting(base) ?: base
        toResolved(base, localized)
    }

    private fun namedUrl(name: String): String =
        "https://api.scryfall.com/cards/named?exact=${enc(name)}"

    private suspend fun searchAnyLanguage(name: String): JSONObject {
        var url = "https://api.scryfall.com/cards/search?q=${enc("\"$name\"")}&include_multilingual=true&unique=prints"
        while (true) {
            val root = getJson(url)
            val data = root.optJSONArray("data") ?: error("Card not found: $name")
            for (i in 0 until data.length()) {
                val c = data.getJSONObject(i)
                val names = listOf(c.optString("name"), c.optString("printed_name"))
                if (names.any { it.equals(name, ignoreCase = true) }) return c
            }
            if (!root.optBoolean("has_more")) break
            url = root.optString("next_page").ifBlank { break }
        }
        error("Card not found: $name")
    }

    private suspend fun findJapanesePrinting(base: JSONObject): JSONObject? {
        if (base.optString("lang") == "ja" && hasImage(base)) return base
        var url = base.optString("prints_search_uri")
        if (url.isBlank()) return null
        url += if (url.contains("?")) "&include_multilingual=true" else "?include_multilingual=true"
        var pages = 0
        while (url.isNotBlank() && pages < 8) {
            pages++
            val root = getJson(url)
            val data = root.optJSONArray("data") ?: return null
            var fallback: JSONObject? = null
            for (i in 0 until data.length()) {
                val c = data.getJSONObject(i)
                if (c.optString("lang") == "ja") {
                    if (fallback == null) fallback = c
                    if (hasImage(c)) return c
                }
            }
            if (fallback != null) return fallback
            if (!root.optBoolean("has_more")) break
            url = root.optString("next_page")
        }
        return null
    }

    private fun hasImage(card: JSONObject): Boolean =
        card.optJSONObject("image_uris")?.optString("normal")?.isNotBlank() == true ||
            card.optJSONArray("card_faces")?.optJSONObject(0)?.optJSONObject("image_uris")?.optString("normal")?.isNotBlank() == true

    private fun toResolved(base: JSONObject, localized: JSONObject): ResolvedCard {
        val (front, back) = imageUrls(localized).let { pair ->
            if (pair.first.isBlank()) imageUrls(base) else pair
        }
        val colors = base.optJSONArray("color_identity")?.let { arr ->
            (0 until arr.length()).joinToString("") { arr.optString(it) }
        }.orEmpty()
        val localizedFaces = localized.optJSONArray("card_faces")
        val baseFaces = base.optJSONArray("card_faces")
        val displayText = CardLocalization.networkField(localized, base, "printed_text", "oracle_text", "\n//\n")
        val displayType = CardLocalization.networkField(localized, base, "printed_type_line", "type_line", " // ")
        val displayName = CardLocalization.networkField(localized, base, "printed_name", "name", " // ")
        val mana = localized.optString("mana_cost").ifBlank {
            localizedFaces?.optJSONObject(0)?.optString("mana_cost").orEmpty()
        }
        return ResolvedCard(
            scryfallId = localized.optString("id").ifBlank { base.optString("id") },
            oracleId = base.optString("oracle_id"),
            oracleName = base.optString("name"),
            displayName = displayName,
            printedName = if (localized.optString("lang") == "ja") displayName else "",
            displayTypeLine = displayType,
            oracleTypeLine = base.optString("type_line"),
            oracleText = displayText,
            manaCost = mana,
            cmc = base.optDouble("cmc", 0.0),
            colorIdentity = colors,
            thumbnailUrl = localized.optJSONObject("image_uris")
                ?.optString("small")?.takeIf { it.isNotBlank() }
                ?: localizedFaces?.optJSONObject(0)?.optJSONObject("image_uris")
                    ?.optString("small")?.takeIf { it.isNotBlank() }
                ?: front,
            imageUrl = front,
            backImageUrl = back,
            backThumbnailUrl = if (back.isBlank()) "" else smallImageUrl(localized, 1).ifBlank { smallImageUrl(base, 1) }.ifBlank { back },
        )
    }


    private fun smallImageUrl(card: JSONObject, face: Int = 0): String {
        if (face == 0) card.optJSONObject("image_uris")?.optString("small")?.takeIf { it.isNotBlank() }?.let { return it }
        val faces = card.optJSONArray("card_faces") ?: return ""
        return faces.optJSONObject(face)?.optJSONObject("image_uris")?.optString("small").orEmpty()
    }
    private fun imageUrls(card: JSONObject): Pair<String, String> {
        card.optJSONObject("image_uris")?.optString("normal")?.takeIf { it.isNotBlank() }?.let {
            return it to ""
        }
        val faces = card.optJSONArray("card_faces") ?: return "" to ""
        val front = faces.optJSONObject(0)?.optJSONObject("image_uris")?.optString("normal").orEmpty()
        val back = faces.optJSONObject(1)?.optJSONObject("image_uris")?.optString("normal").orEmpty()
        return front to back
    }

    private suspend fun getJson(url: String): JSONObject {
        var lastError: Throwable? = null
        repeat(5) { attempt ->
            try {
                return getJsonOnce(url)
            } catch (rate: RateLimitedException) {
                lastError = rate
                if (attempt == 4) throw rate
                delay(rate.retryAfterMillis.coerceIn(1_000L, 30_000L))
            } catch (t: Throwable) {
                if (!t.isTransientNetworkError() || attempt == 4) throw t
                lastError = t
                delay((650L * (attempt + 1)).coerceAtMost(4_000L))
            }
        }
        throw lastError ?: IOException("Scryfall request failed")
    }

    private suspend fun getJsonOnce(url: String): JSONObject {
        throttle()
        val conn = URI(url).toURL().openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 12_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "DeckLoom/0.49 Android local-deck-manager")
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.let { BufferedReader(InputStreamReader(it)).use { reader -> reader.readText() } }.orEmpty()
            if (code == 429) {
                val retrySeconds = conn.getHeaderField("Retry-After")?.toLongOrNull() ?: 2L
                throw RateLimitedException(
                    retryAfterMillis = retrySeconds * 1_000L,
                    message = "Scryfall Rate_Limited: ${retrySeconds}秒後に再試行します",
                )
            }
            if (code !in 200..299) error("Scryfall HTTP $code: $body")
            return JSONObject(body)
        } finally {
            conn.disconnect()
        }
    }

    private fun Throwable.isTransientNetworkError(): Boolean =
        this is UnknownHostException || this is SocketTimeoutException || this is ConnectException || this is IOException

    private suspend fun throttle() = limiter.withLock {
        val now = System.currentTimeMillis()
        // Scryfall asks clients to stay below 10 API requests/sec. 220ms keeps us comfortably below that.
        val wait = 220L - (now - lastRequestAt)
        if (wait > 0) delay(wait)
        lastRequestAt = System.currentTimeMillis()
    }

    private fun enc(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
}
