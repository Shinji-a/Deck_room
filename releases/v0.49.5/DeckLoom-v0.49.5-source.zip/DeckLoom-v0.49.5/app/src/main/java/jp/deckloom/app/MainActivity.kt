package jp.deckloom.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import jp.deckloom.app.ui.AppViewModel
import jp.deckloom.app.ui.AppViewModelFactory
import jp.deckloom.app.ui.DeckLoomApp
import jp.deckloom.app.ui.theme.DeckLoomTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val app = application as DeckLoomApplication
            val settings by app.settingsStore.settings.collectAsState()
            DeckLoomTheme(themeMode = settings.themeMode) {
                val vm: AppViewModel = viewModel(factory = AppViewModelFactory(app.repository))
                DeckLoomApp(vm)
            }
        }
    }
}
