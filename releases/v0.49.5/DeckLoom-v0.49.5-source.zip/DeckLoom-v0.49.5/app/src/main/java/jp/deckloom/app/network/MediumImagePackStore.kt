package jp.deckloom.app.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URI
import java.security.MessageDigest
import java.util.zip.ZipInputStream

private const val MEDIUM_META_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/medium-image-pack-latest/medium-image-pack-meta.json"
private const val MEDIUM_MANIFEST_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/medium-image-pack-latest/medium-image-manifest.json"
private const val MEDIUM_PACK_URL = "https://github.com/Shinji-a/deckloom-card-index/releases/download/medium-image-pack-latest/deckloom-medium-images.zip"

class MediumImagePackStore(private val context: Context) {
    private val root = File(context.filesDir, "medium_image_pack")
    private val imagesDir = File(root, "images")
    private val manifestFile = File(root, "medium-image-pack-meta.json")
    private val entriesFile = File(root, "medium-image-manifest.json")
    @Volatile private var oracleMap: Map<String, List<Pair<Int, String>>>? = null
    private val _progress = MutableStateFlow(if (installed()) ImagePackProgress("READY", message = "標準画像パック導入済み") else ImagePackProgress())
    val progress: StateFlow<ImagePackProgress> = _progress.asStateFlow()

    fun installed(): Boolean = manifestFile.exists() && imagesDir.exists()
    fun installedBytes(): Long = if (!imagesDir.exists()) 0L else imagesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    fun installedImageCount(): Int = runCatching { JSONObject(manifestFile.readText()).optInt("image_count", 0) }.getOrDefault(0)
    fun installedBulkUpdatedAt(): String = runCatching { JSONObject(manifestFile.readText()).optString("scryfall_bulk_updated_at") }.getOrDefault("")

    fun mediumPath(scryfallId: String, face: Int = 0): String = findByScryfallId(scryfallId, face)

    fun mediumPathByOracleId(oracleId: String, fallbackScryfallId: String, face: Int = 0): String {
        if (oracleId.isBlank() || !installed()) return findByScryfallId(fallbackScryfallId, face)
        val hit = loadOracleMap()[oracleId]?.firstOrNull { it.first == face }?.second.orEmpty()
        return if (hit.isNotBlank()) findByScryfallId(hit, face) else findByScryfallId(fallbackScryfallId, face)
    }

    private fun findByScryfallId(scryfallId: String, face: Int): String {
        if (scryfallId.isBlank() || !installed()) return ""
        val suffix = "$scryfallId-f$face.webp"
        val cats = if (face == 0) listOf("card_primary","token_primary","card_extra_face","token_extra_face") else listOf("card_extra_face","token_extra_face","card_primary","token_primary")
        return cats.asSequence().map { File(imagesDir, "$it/$suffix") }.firstOrNull { it.exists() && it.length() > 0L }?.absolutePath.orEmpty()
    }

    private fun loadOracleMap(): Map<String, List<Pair<Int, String>>> {
        oracleMap?.let { return it }
        val built = linkedMapOf<String, MutableList<Pair<Int, String>>>()
        runCatching {
            val entries = JSONObject(entriesFile.readText()).optJSONObject("entries") ?: return@runCatching
            val keys = entries.keys()
            while (keys.hasNext()) {
                val key = keys.next(); val e = entries.optJSONObject(key) ?: continue
                if (!e.optString("category").startsWith("card_")) continue
                val oracle = e.optString("object_key"); val sid = e.optString("scryfall_id"); val face = e.optInt("face",0)
                if (oracle.isNotBlank() && sid.isNotBlank()) built.getOrPut(oracle) { mutableListOf() }.add(face to sid)
            }
        }
        return built.also { oracleMap = it }
    }

    suspend fun downloadFullPack(): Boolean = withContext(Dispatchers.IO) {
        try { val meta = fetchMeta() ?: return@withContext false; install(meta); true }
        catch (t: Throwable) { _progress.value = ImagePackProgress("ERROR", message = t.message ?: "標準画像パックの取得に失敗しました"); throw t }
    }

    suspend fun checkAndUpdateIfInstalled(blockMetered: Boolean, isMetered: Boolean): Boolean = withContext(Dispatchers.IO) {
        if (!installed()) return@withContext false
        val remote = fetchMeta() ?: return@withContext false
        val localSha = runCatching { JSONObject(manifestFile.readText()).optString("archive_sha256") }.getOrDefault("")
        if (remote.optString("archive_sha256") == localSha && localSha.isNotBlank()) { _progress.value = ImagePackProgress("READY", message="標準画像パックは最新です"); return@withContext false }
        if (blockMetered && isMetered) { _progress.value = ImagePackProgress("READY", message="従量制通信のため標準画像更新を保留中"); return@withContext false }
        install(remote); true
    }

    suspend fun clear(): Long = withContext(Dispatchers.IO) {
        val bytes = if (root.exists()) root.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L
        root.deleteRecursively(); oracleMap = null; _progress.value = ImagePackProgress(); bytes
    }

    private fun fetchMeta(): JSONObject? {
        _progress.value = ImagePackProgress("CHECKING", message="標準画像パックを確認中…")
        return runCatching { val c=open(MEDIUM_META_URL); try { JSONObject(c.inputStream.bufferedReader().use { it.readText() }) } finally { c.disconnect() } }
            .onFailure { _progress.value=ImagePackProgress("ERROR",message=it.message ?: "標準画像meta取得失敗") }.getOrNull()
    }

    private fun install(meta: JSONObject) {
        val tmp=File(context.cacheDir,"deckloom-medium-images.download")
        val staging=File(context.cacheDir,"deckloom-medium-images-staging")
        tmp.delete(); staging.deleteRecursively(); staging.mkdirs()
        val expected=meta.optLong("archive_bytes",0L)
        val manifestJson = runCatching { val c=open(MEDIUM_MANIFEST_URL); try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() } }.getOrElse { error("Medium manifest取得失敗: ${it.message}") }
        _progress.value=ImagePackProgress("DOWNLOADING",0L,expected,"標準画像パックをダウンロード中")
        val conn=open(MEDIUM_PACK_URL)
        try { val total=conn.contentLengthLong.takeIf{it>0} ?: expected; var done=0L; BufferedInputStream(conn.inputStream).use { input -> FileOutputStream(tmp).use { output -> val buf=ByteArray(256*1024); while(true){val n=input.read(buf);if(n<0)break;output.write(buf,0,n);done+=n;_progress.value=ImagePackProgress("DOWNLOADING",done,total,"標準画像パックをダウンロード中")}}}} finally {conn.disconnect()}
        val expectedSha=meta.optString("archive_sha256"); if(expectedSha.isNotBlank() && sha256(tmp)!=expectedSha){tmp.delete();error("Medium image pack SHA-256 mismatch")}
        _progress.value=ImagePackProgress("INSTALLING",message="標準画像を準備中…")
        ZipInputStream(BufferedInputStream(tmp.inputStream())).use { zip -> while(true){val e=zip.nextEntry?:break;val out=File(staging,e.name).canonicalFile;require(out.path.startsWith(staging.canonicalPath+File.separator));if(e.isDirectory)out.mkdirs()else{out.parentFile?.mkdirs();out.outputStream().use{zip.copyTo(it)}};zip.closeEntry()} }
        val stagedImages=File(staging,"images").takeIf{it.exists()} ?: staging
        val newRoot=File(context.filesDir,"medium_image_pack_new"); newRoot.deleteRecursively(); newRoot.mkdirs(); stagedImages.copyRecursively(File(newRoot,"images"),overwrite=true); File(newRoot,"medium-image-pack-meta.json").writeText(meta.toString()); File(newRoot,"medium-image-manifest.json").writeText(manifestJson); oracleMap = null
        val old=File(context.filesDir,"medium_image_pack_old");old.deleteRecursively();if(root.exists())require(root.renameTo(old));try{require(newRoot.renameTo(root));old.deleteRecursively()}catch(t:Throwable){root.deleteRecursively();if(old.exists())old.renameTo(root);throw t}
        tmp.delete();staging.deleteRecursively();_progress.value=ImagePackProgress("READY",message="標準画像パック導入済み")
    }
    private fun open(url:String)= (URI(url).toURL().openConnection() as HttpURLConnection).apply{connectTimeout=20_000;readTimeout=120_000;instanceFollowRedirects=true;setRequestProperty("User-Agent","DeckLoom/0.49 Android local-deck-manager")}
    private fun sha256(file:File):String{val md=MessageDigest.getInstance("SHA-256");file.inputStream().use{input->val b=ByteArray(1024*1024);while(true){val n=input.read(b);if(n<0)break;md.update(b,0,n)}};return md.digest().joinToString(""){"%02x".format(it)}}
}
