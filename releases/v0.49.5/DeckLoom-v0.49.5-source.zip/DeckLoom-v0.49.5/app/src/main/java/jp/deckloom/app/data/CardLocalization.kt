package jp.deckloom.app.data

import org.json.JSONArray
import org.json.JSONObject

/** Per-face fallback keeps the identity of the front/Adventure/back intact. */
object CardLocalization {
    private val japanese = Regex("[\\u3040-\\u30ff\\u3400-\\u9fff\\uf900-\\ufaff\\uff66-\\uff9f]")
    private val latin = Regex("[A-Za-z]+(?:['’-][A-Za-z]+)*")
    private val symbols = Regex("\\{[^{}]*\\}")

    fun usable(value: String, text: Boolean = false): Boolean {
        if (value.isBlank() || value == "null") return false
        val plain = symbols.replace(value, "")
        if (latin.containsMatchIn(plain) && !japanese.containsMatchIn(plain)) return false
        return !text || plain.lines().none { line ->
            !japanese.containsMatchIn(line) && latin.findAll(line).count() >= 3 &&
                !line.trim().matches(Regex("(?:LEVEL|Lv)\\s+\\d+(?:[-–]\\d+|\\+)?", RegexOption.IGNORE_CASE))
        }
    }

    fun preferJapanese(index: String, network: String): String = when {
        japanese.containsMatchIn(index) -> index
        japanese.containsMatchIn(network) -> network
        index.isNotBlank() -> index
        else -> network
    }

    fun field(root: String, oracleRoot: String, localizedFaces: String, oracleFaces: String,
              key: String, oracleKey: String, separator: String, preferFaceText: Boolean = false): String {
        fun parse(value: String): JSONArray = runCatching { JSONArray(value) }.getOrElse { JSONArray() }
        val local = parse(localizedFaces)
        val canonical = parse(oracleFaces).let { if (it.length() > 0) it else local }
        val isText = key == "printed_text"
        fun clean(value: String) = if (key == "printed_name") CardNames.clean(value) else value
        fun value(face: JSONObject?, field: String): String =
            face?.opt(field)?.takeUnless { it == JSONObject.NULL }?.toString().orEmpty()
        val rootUsable = usable(root, isText)
        if (canonical.length() == 0) return clean(if (rootUsable) root else oracleRoot)
        val pairs = (0 until canonical.length()).map { index ->
            val base = canonical.optJSONObject(index)
            // Match by the English face name, never slide a later face into a gap.
            val name = value(base, "name")
            val translated = (0 until local.length()).mapNotNull { local.optJSONObject(it) }
                .firstOrNull { value(it, "name") == name && name.isNotBlank() }
            value(translated, key).takeIf { usable(it, isText) }.orEmpty() to value(base, oracleKey)
        }
        if (key == "printed_name") {
            for ((aggregate, _) in pairs) {
                val combined = aggregate.split(" // ")
                if (combined.size == canonical.length() && combined.size > 1 &&
                    pairs.indices.all { pairs[it].first in listOf("", aggregate, combined[it]) }) {
                    return clean(combined.joinToString(separator))
                }
            }
        }
        // Some source printings put both Adventure texts in one aggregate field.
        if (rootUsable && (pairs.none { it.first.isNotBlank() } ||
            (isText && (!preferFaceText || root.contains("//ADV//"))))) return clean(root)
        if (isText) pairs.firstOrNull()?.first?.takeIf { it.contains("//ADV//") }?.let { return it }
        return pairs.joinToString(separator) { (translated, english) -> clean(translated.ifBlank { english }) }
            .takeIf { it.replace(separator, "").isNotBlank() } ?: clean(oracleRoot)
    }

    fun networkField(card: JSONObject, base: JSONObject, key: String, oracleKey: String, separator: String): String {
        fun text(obj: JSONObject, k: String) = obj.opt(k)?.takeUnless { it == JSONObject.NULL }?.toString().orEmpty()
        val localized = if (card.optString("lang") == "ja") card else JSONObject()
        return field(text(localized, key), text(base, oracleKey),
            localized.optJSONArray("card_faces")?.toString().orEmpty(),
            (base.optJSONArray("card_faces") ?: card.optJSONArray("card_faces"))?.toString().orEmpty(),
            key, oracleKey, separator)
    }
}

internal fun DeckCardEntity.withLocalization(record: CardIndexRecord): DeckCardEntity {
    if (oracleId != record.oracleId) return this
    return copy(
        displayName = CardNames.clean(CardLocalization.preferJapanese(record.displayName, displayName)),
        printedName = CardNames.clean(CardLocalization.preferJapanese(record.japaneseName, printedName)),
        displayTypeLine = CardLocalization.preferJapanese(record.displayTypeLine, displayTypeLine),
        oracleText = CardLocalization.preferJapanese(record.displayText, oracleText),
    )
}

