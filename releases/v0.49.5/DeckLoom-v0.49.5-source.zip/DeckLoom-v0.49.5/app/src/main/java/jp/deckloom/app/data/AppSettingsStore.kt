package jp.deckloom.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val themeMode: String = "SYSTEM", // SYSTEM / LIGHT / DARK
    val blockMeteredCardDbDownload: Boolean = true,
    val imagePreloadMode: String = "NONE", // NONE / SMALL / MEDIUM
    val normalOverMedium: Boolean = false,
    val searchDisplayMode: String = "LAST", // LAST / LIST / GRID
    val lastSearchGrid: Boolean = false,
)

class AppSettingsStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("deckloom_settings", Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun setThemeMode(mode: String) {
        val normalized = mode.takeIf { it in setOf("SYSTEM", "LIGHT", "DARK") } ?: "SYSTEM"
        prefs.edit().putString("theme_mode", normalized).apply()
        _settings.value = _settings.value.copy(themeMode = normalized)
    }

    fun setBlockMeteredCardDbDownload(enabled: Boolean) {
        prefs.edit().putBoolean("block_metered_card_db_download", enabled).apply()
        _settings.value = _settings.value.copy(blockMeteredCardDbDownload = enabled)
    }

    fun setImagePreloadMode(mode: String) {
        val normalized = mode.takeIf { it in setOf("NONE", "SMALL", "MEDIUM") } ?: "NONE"
        prefs.edit().putString("image_preload_mode", normalized).apply()
        _settings.value = _settings.value.copy(imagePreloadMode = normalized)
    }

    fun setNormalOverMedium(enabled: Boolean) {
        prefs.edit().putBoolean("normal_over_medium", enabled).apply()
        _settings.value = _settings.value.copy(normalOverMedium = enabled)
    }

    fun setSearchDisplayMode(mode: String) {
        val value = mode.takeIf { it in setOf("LAST", "LIST", "GRID") } ?: "LAST"
        prefs.edit().putString("search_display_mode", value).apply()
        _settings.value = _settings.value.copy(searchDisplayMode = value)
    }

    fun setLastSearchGrid(grid: Boolean) {
        prefs.edit().putBoolean("last_search_grid", grid).apply()
        _settings.value = _settings.value.copy(lastSearchGrid = grid)
    }

    private fun load() = AppSettings(
        themeMode = prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM",
        blockMeteredCardDbDownload = prefs.getBoolean("block_metered_card_db_download", true),
        imagePreloadMode = prefs.getString("image_preload_mode", null) ?: if (java.io.File(context.filesDir, "small_image_pack/image-manifest.json").exists()) "SMALL" else "NONE",
        normalOverMedium = prefs.getBoolean("normal_over_medium", false),
        searchDisplayMode = prefs.getString("search_display_mode", "LAST") ?: "LAST",
        lastSearchGrid = prefs.getBoolean("last_search_grid", false),
    )
}
