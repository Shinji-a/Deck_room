package jp.deckloom.app.ui

/** A callback from an outgoing screen cannot pop the newly exposed screen. */
class NavigationGate(private val clock: () -> Long) {
    private var lastAccepted: Long? = null
    fun accept(source: String, current: String?, resumed: Boolean): Boolean {
        val now = clock()
        if (source != current || !resumed || lastAccepted?.let { now - it < 350L } == true) return false
        lastAccepted = now
        return true
    }
}
