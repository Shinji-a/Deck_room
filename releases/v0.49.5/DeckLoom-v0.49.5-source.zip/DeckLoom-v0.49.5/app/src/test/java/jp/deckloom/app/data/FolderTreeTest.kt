package jp.deckloom.app.data

import org.junit.Assert.*
import org.junit.Test

class FolderTreeTest {
    private val folders = listOf(
        DeckFolderEntity(id = 1, name = "調整中"),
        DeckFolderEntity(id = 2, name = "土地", parentId = 1),
        DeckFolderEntity(id = 3, name = "完成"),
        DeckFolderEntity(id = 4, name = "土地", parentId = 3),
        DeckFolderEntity(id = 5, name = "試作", parentId = 2),
    )

    @Test fun namesAreDisambiguatedByTheWholePath() {
        assertEquals("デッキ", FolderTree.path(null, folders))
        assertEquals("デッキ / 調整中 / 土地 / 試作", FolderTree.path(5, folders))
        assertNotEquals(FolderTree.path(2, folders), FolderTree.path(4, folders))
    }

    @Test fun cannotMoveIntoSelfOrAnyDescendant() {
        assertFalse(FolderTree.canMove(1, 1, folders))
        assertFalse(FolderTree.canMove(1, 2, folders))
        assertFalse(FolderTree.canMove(1, 5, folders))
        assertFalse(FolderTree.canMove(2, 5, folders))
    }

    @Test fun canMoveToRootSiblingOrAncestor() {
        assertTrue(FolderTree.canMove(5, null, folders))
        assertTrue(FolderTree.canMove(5, 1, folders))
        assertTrue(FolderTree.canMove(2, 3, folders))
        assertTrue(FolderTree.canMove(2, 1, folders))
    }

    @Test fun missingSourcesAndDestinationsAreRejected() {
        assertFalse(FolderTree.canMove(99, null, folders))
        assertFalse(FolderTree.canMove(1, 99, folders))
    }

    @Test fun corruptedCycleCannotHangPathOrAllowMovesIntoIt() {
        val corrupt = folders + listOf(DeckFolderEntity(10, "A", parentId = 11), DeckFolderEntity(11, "B", parentId = 10))
        assertFalse(FolderTree.canMove(1, 10, corrupt))
        assertTrue(FolderTree.path(10, corrupt).length < 30)
    }
}
