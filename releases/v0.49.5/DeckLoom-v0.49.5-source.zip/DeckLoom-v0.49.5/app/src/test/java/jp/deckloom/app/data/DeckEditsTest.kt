package jp.deckloom.app.data
import org.junit.Assert.*
import org.junit.Test
class DeckEditsTest {
    private fun c(q: Int = 1, active: Boolean = true, limit: Int? = 1, key: String = "oracle") = CopyRuleCard(key, "カード", q, active, limit)
    @Test fun differentPrintingsWithSameOracleShareLimitIncludingCommander() {
        assertEquals(1, DeckCopyRules.violations(listOf(c()), listOf(c(), c())).size)
        assertTrue(DeckCopyRules.violations(listOf(c()), listOf(c(), c(key="other"))).isEmpty())
    }
    @Test fun candidatesAreExcludedUntilPromoted() {
        assertTrue(DeckCopyRules.violations(listOf(c()), listOf(c(), c(20, false))).isEmpty())
        assertFalse(DeckCopyRules.violations(listOf(c(), c(active=false)), listOf(c(), c())).isEmpty())
    }
    @Test fun basicUnlimitedAndSpecialLimitsAreRespected() {
        assertTrue(DeckCopyRules.violations(emptyList(), listOf(c(100, limit=-1))).isEmpty())
        assertTrue(DeckCopyRules.violations(emptyList(), listOf(c(7, limit=7))).isEmpty())
        assertFalse(DeckCopyRules.violations(emptyList(), listOf(c(8, limit=7))).isEmpty())
    }
    @Test fun oldInvalidDeckCanBeEditedOrReducedButNotMadeWorse() {
        val old = listOf(c(3))
        assertTrue(DeckCopyRules.violations(old, listOf(c(3))).isEmpty())
        assertTrue(DeckCopyRules.violations(old, listOf(c(2))).isEmpty())
        assertFalse(DeckCopyRules.violations(old, listOf(c(4))).isEmpty())
    }
    @Test fun unknownRulesAreNotInvented() {
        assertTrue(DeckCopyRules.violations(emptyList(), listOf(c(3, limit=null))).isEmpty())
    }
    @Test fun undoPreservesBackgroundLocalizationAndImagesButDetectsLaterEdits() {
        val original = DeckCardEntity(id=1, deckId=2, inputName="Forest", quantity=1, addedAt=50)
        val edited = original.copy(quantity=2)
        val resolved = edited.copy(imagePath="/new.jpg", displayName="森", oracleId="forest", oracleText="新しい本文", category="Land")
        assertTrue(DeckEditFields.same(edited, resolved))
        assertFalse(DeckEditFields.same(edited, resolved.copy(quantity=3)))
        assertFalse(DeckEditFields.same(edited, resolved.copy(userCategory="土地")))
        assertFalse(DeckEditFields.same(edited, null))
        val restored = DeckEditFields.restore(original, resolved)
        assertEquals(1, restored.quantity)
        assertEquals("/new.jpg", restored.imagePath)
        assertEquals("森", restored.displayName)
        assertEquals(50L, restored.addedAt)
    }
    @Test fun selectedExportsIncludeCandidateQuantitiesAndRemoveReadings() {
        val card = DeckCardEntity(id=1, deckId=1, quantity=3, inputName="Breeding Pool", oracleName="Breeding Pool", displayName="繁殖(はんしょく)した墓", deckRole=DeckRoles.CANDIDATE)
        assertEquals("", DeckExports.exportHareruya(listOf(card)))
        assertEquals("3 繁殖した墓", DeckExports.exportHareruya(listOf(card), true))
        assertEquals("3 Breeding Pool", DeckExports.exportEnglish(listOf(card), true))
    }
}
