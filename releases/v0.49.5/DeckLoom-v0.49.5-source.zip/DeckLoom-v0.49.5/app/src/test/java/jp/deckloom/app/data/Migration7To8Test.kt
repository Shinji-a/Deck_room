package jp.deckloom.app.data

import androidx.sqlite.db.SupportSQLiteDatabase
import jp.deckloom.app.DeckLoomApplication
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy
import java.sql.DriverManager

class Migration7To8Test {
    @Test fun sortingMigrationPreservesAllExistingValuesAndSeedsOrder() {
        DriverManager.getConnection("jdbc:sqlite::memory:").use { connection ->
            fun sql(statement: String) { connection.createStatement().use { it.execute(statement) } }
            fun rows(statement: String): List<List<String?>> = connection.createStatement().use { s ->
                s.executeQuery(statement).use { r -> buildList { while (r.next()) add((1..r.metaData.columnCount).map { r.getString(it) }) } }
            }
            sql("PRAGMA foreign_keys=ON")
            val schema = requireNotNull(javaClass.classLoader?.getResourceAsStream("schema-v5.sql")).bufferedReader().use { it.readText() }
            schema.split(';').filter { it.isNotBlank() }.forEach(::sql)
            val database = Proxy.newProxyInstance(SupportSQLiteDatabase::class.java.classLoader, arrayOf(SupportSQLiteDatabase::class.java)) { _, method, args ->
                if (method.name == "execSQL" && args?.size == 1) { sql(args[0] as String); null }
                else error("Unexpected call: ${method.name}")
            } as SupportSQLiteDatabase
            DeckLoomApplication.MIGRATION_5_6.migrate(database)
            sql("INSERT INTO deck_folders(id,name,sortOrder) VALUES(1,'調整中',0),(2,'完成',1)")
            sql("INSERT INTO decks(id,name,createdAt,folderId,note,sortOrder,cardSortMode) VALUES(1,'サンドマン',100,1,'3マナ域を減らす',4,'MV_ASC')")
            val columns = rows("PRAGMA table_info(deck_cards)")
            val supplied = mapOf("id" to "1", "deckId" to "1", "quantity" to "7", "inputName" to "森", "imagePath" to "/saved/card.jpg", "selectedPrintingId" to "chosen-printing", "userCategory" to "土地", "deckRole" to "MAIN")
            val values = columns.map { supplied[it[1]] ?: if (it[2] == "TEXT") "" else "0" }
            connection.prepareStatement("INSERT INTO deck_cards (${columns.joinToString(",") { it[1]!! }}) VALUES (${values.joinToString(",") { "?" }})").use { statement ->
                values.forEachIndexed { index, value -> statement.setString(index + 1, value) }; statement.executeUpdate()
            }
            sql("INSERT INTO deck_change_log(deckId,createdAt,action,cardName,quantity,fromRole,toRole,note) VALUES(1,200,'ADD','森',7,'','MAIN','記録')")
            sql("INSERT INTO saved_searches(createdAt,description,filterJson) VALUES(300,'土地検索','{}')")
            DeckLoomApplication.MIGRATION_6_7.migrate(database)
            val searchesBefore = rows("SELECT * FROM saved_searches")
            val decksBefore = rows("SELECT * FROM decks")
            val cardsBefore = rows("SELECT * FROM deck_cards")
            val logsBefore = rows("SELECT * FROM deck_change_log")
            DeckLoomApplication.MIGRATION_7_8.migrate(database)
            assertEquals(decksBefore, rows("SELECT id,name,createdAt,folderId,note,sortOrder,cardSortMode FROM decks"))
            assertEquals(cardsBefore, rows("SELECT ${columns.joinToString(",") { it[1]!! }} FROM deck_cards"))
            assertEquals(logsBefore, rows("SELECT * FROM deck_change_log"))
            assertEquals(searchesBefore, rows("SELECT * FROM saved_searches"))
            assertEquals(listOf(listOf("1")), rows("SELECT groupByCategory FROM decks"))
            assertEquals(listOf(listOf("1")), rows("SELECT addedAt FROM deck_cards"))
            sql("UPDATE decks SET groupByCategory=0,cardSortMode='ADDED_DESC' WHERE id=1")
            assertEquals(listOf(listOf("0", "ADDED_DESC")), rows("SELECT groupByCategory,cardSortMode FROM decks"))
            assertTrue(rows("PRAGMA foreign_key_check").isEmpty())
            assertEquals(listOf(listOf("ok")), rows("PRAGMA integrity_check"))
        }
    }
}
