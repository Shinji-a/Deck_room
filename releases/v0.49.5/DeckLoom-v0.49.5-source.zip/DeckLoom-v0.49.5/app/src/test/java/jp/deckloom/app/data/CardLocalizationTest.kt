package jp.deckloom.app.data

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class CardLocalizationTest {
    private val faces = """[{"name":"Virtue","oracle_text":"Front rules","type_line":"Enchantment"},{"name":"Adventure","oracle_text":"Draw a card.","type_line":"Sorcery"}]"""
    private fun field(local: String, key: String = "printed_name", oracleKey: String = "name", root: String = "", sep: String = " // ") =
        CardLocalization.field(root, "Virtue // Adventure", local, faces, key, oracleKey, sep)

    @Test fun missingFrontNeverPromotesAdventure() {
        assertEquals("Virtue // 出来事", field("""[{"name":"Virtue","printed_name":"Virtue"},{"name":"Adventure","printed_name":"出来事"}]"""))
    }
    @Test fun reorderedFacesMatchByIdentity() {
        assertEquals("徳目 // 出来事", field("""[{"name":"Adventure","printed_name":"出来事"},{"name":"Virtue","printed_name":"徳目"}]"""))
    }
    @Test fun partialTextKeepsTranslationAndFallsBackPerFace() {
        assertEquals("日本語の本体\n//\nDraw a card.", field("""[{"name":"Virtue","printed_text":"日本語の本体"}]""", "printed_text", "oracle_text", sep="\n//\n"))
    }
    @Test fun jsonNullNeverAppearsOnScreen() {
        assertEquals("Front rules\n//\nDraw a card.", field("""[{"name":"Virtue","printed_text":null},{"name":"Adventure","printed_text":null}]""", "printed_text", "oracle_text", sep="\n//\n"))
    }
    @Test fun aggregateAdventureTextIsPreserved() {
        val text="日本語本文\n//ADV//\n出来事の本文"
        assertEquals(text, field("""[{"name":"Virtue","printed_text":"日本語本文\n//ADV//\n出来事の本文"}]""", "printed_text", "oracle_text"))
    }
    @Test fun partialIndexAggregateDoesNotHideMissingFace() {
        val local="""[{"name":"Virtue","printed_text":"日本語の本体"}]"""
        assertEquals("日本語の本体\n//\nDraw a card.", CardLocalization.field("日本語の本体", "", local, faces,
            "printed_text", "oracle_text", "\n//\n", preferFaceText=true))
    }
    @Test fun splitFirstFaceAggregateNameIsNotDuplicated() {
        assertEquals("苦痛 // 受難",field("""[{"name":"Virtue","printed_name":"苦痛 // 受難"}]"""))
        assertEquals("苦痛 // 受難",field("""[{"name":"Virtue","printed_name":"苦痛 // 受難"},{"name":"Adventure","printed_name":"苦痛 // 受難"}]"""))
    }
    @Test fun sourceRootAggregateStillWorks() {
        assertEquals("表の本文\n//\n裏の本文", field("[]","printed_text","oracle_text",root="表の本文\n//\n裏の本文"))
    }
    @Test fun englishPrintedTextIsNotATranslation() {
        assertFalse(CardLocalization.usable("Draw a card.",true))
        assertFalse(CardLocalization.usable("日本語\nDraw a card.",true))
        assertTrue(CardLocalization.usable("{T}: {G}",true))
    }
    @Test fun networkUsesFaceNamesAndText() {
        val base=JSONObject("""{"lang":"ja","name":"Virtue // Adventure","card_faces":[{"name":"Virtue","printed_name":"徳目","oracle_text":"Front rules","printed_text":"日本語の本体"},{"name":"Adventure","printed_name":"出来事","oracle_text":"Draw a card."}]}""")
        assertEquals("徳目 // 出来事",CardLocalization.networkField(base,base,"printed_name","name"," // "))
        assertEquals("日本語の本体\n//\nDraw a card.",CardLocalization.networkField(base,base,"printed_text","oracle_text","\n//\n"))
    }
    @Test fun indexJapaneseSurvivesNetworkEnglish() {
        assertEquals("日本語本文",CardLocalization.preferJapanese("日本語本文","English text"))
        assertEquals("日本語本文",CardLocalization.preferJapanese("English text","日本語本文"))
    }
    @Test fun meaningfulParenthesesRemain() {
        assertEquals("徳目 // 出来事",field("""[{"name":"Virtue","printed_name":"徳（とく）目（もく）"},{"name":"Adventure","printed_name":"出来事"}]"""))
    }
    private fun record() = CardIndexRecord(
        oracleId="same", scryfallId="database-printing", englishName="Virtue // Adventure", japaneseName="徳目 // 出来事",
        englishTypeLine="Enchantment", japaneseTypeLine="エンチャント", englishOracleText="English", japaneseText="日本語本文",
        manaCost="", manaValue=0.0, colors="", colorIdentity="", power="", toughness="", loyalty="", defense="",
        layout="adventure", keywords=emptyList(), rarity="rare", setCode="woe", legalCommander="legal", copyLimit=1,
        copyLimitReason="singleton", isBasicLand=false, isCreature=false, isLand=false, isArtifact=false,
        isEnchantment=true, isInstant=false, isSorcery=false, isPlaneswalker=false, isBattle=false, isLegendary=false,
        isCompanion=false, isBackground=false, relatedPartsJson="",
    )
    @Test fun savedCardRepairPreservesDeckEditsAndSelectedImage() {
        val old = DeckCardEntity(id=7, deckId=3, quantity=4, inputName="imported", oracleId="same",
            displayName="出来事", oracleText="English", selectedPrintingId="chosen", imagePath="cached.jpg",
            userCategory="お気に入り", deckRole=DeckRoles.CANDIDATE, cacheState="READY")
        val repaired = old.withLocalization(record())
        assertEquals(old.copy(displayName="徳目 // 出来事", printedName="徳目 // 出来事",
            displayTypeLine="エンチャント", oracleText="日本語本文"), repaired)
        assertEquals(repaired, repaired.withLocalization(record()))
    }
    @Test fun savedCardRepairRejectsDifferentOracleIdentity() {
        val old = DeckCardEntity(deckId=3, quantity=1, inputName="Other", oracleId="other")
        assertEquals(old,old.withLocalization(record()))
    }
}
