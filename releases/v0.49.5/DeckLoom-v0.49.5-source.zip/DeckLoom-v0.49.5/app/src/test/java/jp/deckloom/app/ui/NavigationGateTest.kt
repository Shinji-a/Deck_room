package jp.deckloom.app.ui
import org.junit.Assert.*
import org.junit.Test
class NavigationGateTest {
    @Test fun outgoingCallbacksAndDoubleTapsCannotPopNextScreen() {
        var time = 0L
        val gate = NavigationGate { time }
        assertTrue(gate.accept("deck", "deck", true))
        time = 50
        assertFalse(gate.accept("deck", "home", true))
        assertFalse(gate.accept("home", "home", true))
        time = 400
        assertFalse(gate.accept("deck", "home", true))
        assertTrue(gate.accept("home", "home", true))
    }
    @Test fun transitionAndEmptyStackCallbacksAreRejectedWithoutConsumingNextAction() {
        val gate = NavigationGate { 500L }
        assertFalse(gate.accept("deck", "deck", false))
        assertFalse(gate.accept("deck", null, true))
        assertTrue(gate.accept("deck", "deck", true))
    }
}
