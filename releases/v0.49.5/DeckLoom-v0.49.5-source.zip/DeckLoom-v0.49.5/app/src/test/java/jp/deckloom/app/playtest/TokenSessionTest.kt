package jp.deckloom.app.playtest

import org.junit.Assert.*
import org.junit.Test

class TokenSessionTest {
    @Test fun undoRedoAvailabilityTracksLifeActionsAndNewGame() {
        val session = PlaytestSession()
        assertEquals(false to false, session.history.value)
        session.setLife(-5)
        assertEquals(35, session.state.value.life)
        assertEquals(true to false, session.history.value)
        session.undo()
        assertEquals(40, session.state.value.life)
        assertEquals(false to true, session.history.value)
        session.redo()
        assertEquals(35, session.state.value.life)
        assertEquals(true to false, session.history.value)
        session.undo()
        session.setLife(1)
        assertEquals(41, session.state.value.life)
        assertEquals(true to false, session.history.value)
        session.newGame(emptyList())
        assertEquals(false to false, session.history.value)
        assertEquals(40, session.state.value.life)
    }

    @Test fun repeatedTokensAreSeparateUndoableActions() {
        val session = PlaytestSession()
        session.createToken("宝物")
        session.createToken("宝物")
        session.createToken("宝物")
        assertEquals(3, session.state.value.zone(Zone.BATTLEFIELD).size)
        assertEquals(3, session.state.value.cards.map { it.uid }.distinct().size)
        session.undo()
        assertEquals(2, session.state.value.cards.size)
        session.redo()
        assertEquals(3, session.state.value.cards.size)
    }

    @Test fun lateImageCannotAttachToTokenCreatedAfterUndoOrNewGame() {
        val session = PlaytestSession()
        val first = session.createToken("宝物")
        session.undo()
        val second = session.createToken("食物")
        session.setTokenImage(first, "/old-token.jpg")
        assertNotEquals(first, second)
        assertEquals("", session.state.value.cards.single().imagePath)
        session.newGame(emptyList())
        val third = session.createToken("手掛かり")
        session.setTokenImage(second, "/other-game.jpg")
        assertNotEquals(second, third)
        assertEquals("", session.state.value.cards.single().imagePath)
    }

    @Test fun imageCompletionPreservesUndoAndRedo() {
        val session = PlaytestSession()
        val id = session.createToken("宝物")
        session.undo()
        session.setTokenImage(id, "/treasure.jpg")
        assertTrue(session.state.value.cards.isEmpty())
        session.redo()
        assertEquals("/treasure.jpg", session.state.value.cards.single().imagePath)
        session.undo()
        assertTrue(session.state.value.cards.isEmpty())
    }
}
