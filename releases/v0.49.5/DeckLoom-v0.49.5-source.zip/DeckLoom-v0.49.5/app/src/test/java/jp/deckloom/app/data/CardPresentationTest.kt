package jp.deckloom.app.data

import org.junit.Assert.*
import org.junit.Test

class CardPresentationTest {
    @Test fun namesRemoveReadingsWithoutEatingEnglishOrEditionNotes() {
        assertEquals("繁殖した墓", CardNames.clean("繁殖(はんしょく)した墓(はか)"))
        assertEquals("三顧の礼", CardNames.clean("三顧（さんこ）の礼（れい）"))
        assertEquals("骨 // 炎", CardNames.clean("骨(ほね) // 炎(ほのお)"))
        assertEquals("Who // What (Test)", CardNames.clean("Who // What (Test)"))
        assertEquals("森（旧枠）", CardNames.clean("森（旧枠）"))
        assertEquals("カード (Foil)", CardNames.clean("カード (Foil)"))
    }

    private fun card(id: Long, mv: Double, type: String = "Creature", category: String = "", special: String = DeckSpecialRoles.NONE) = DeckCardEntity(
        id = id, addedAt = id, deckId = 1, quantity = 1, inputName = "Card $id", displayName = "Card $id", oracleName = "Card $id", oracleId = "oracle-$id",
        oracleTypeLine = type, cmc = mv, userCategory = category, specialRole = special,
    )

    @Test fun customCategoryOverridesTypeAndClearingRestoresType() {
        val c = card(1, 3.0, "Artifact Creature — Golem", "マナ加速")
        assertEquals("マナ加速", CardCategories.display(c))
        assertEquals("Creature", CardCategories.display(c.copy(userCategory = "")))
        assertEquals("", CardCategories.imported("Creature"))
        assertEquals("マナ加速", CardCategories.imported("マナ加速"))
    }

    @Test fun manaSortStaysInsideCategoriesAndPinsCommander() {
        val cards = listOf(card(1, 5.0), card(2, 2.0), card(3, 3.0), card(4, 1.0, "Artifact"), card(5, 7.0, special = DeckSpecialRoles.COMMANDER))
        assertEquals(listOf(5L, 2L, 3L, 1L, 4L), DeckCardSorting.sort(cards, "MV_ASC").map { it.id })
        assertEquals(listOf(5L, 1L, 3L, 2L, 4L), DeckCardSorting.sort(cards, "MV_DESC").map { it.id })
        assertEquals(listOf(5L, 1L, 2L, 3L, 4L), DeckCardSorting.sort(cards.reversed(), "REGISTERED").map { it.id })
    }

    @Test fun unknownManaDoesNotLookLikeAZeroManaCard() {
        val unknown = card(1, 0.0).copy(oracleId = "", oracleName = "")
        val cards = listOf(unknown, card(2, 0.0), card(3, 3.0))
        assertEquals(listOf(2L, 3L, 1L), DeckCardSorting.sort(cards, "MV_ASC").map { it.id })
        assertEquals(listOf(3L, 2L, 1L), DeckCardSorting.sort(cards, "MV_DESC").map { it.id })
    }
    @Test fun flatSortCrossesCategoriesAndDoesNotPinCommander() {
        val cards = listOf(card(1, 8.0, special=DeckSpecialRoles.COMMANDER), card(2, 2.0, "Artifact"), card(3, 1.0))
        assertEquals(listOf(3L, 2L, 1L), DeckCardSorting.sort(cards, "ADDED_DESC", false).map { it.id })
        assertEquals(listOf(1L, 2L, 3L), DeckCardSorting.sort(cards, "REGISTERED", false).map { it.id })
        assertEquals(listOf(3L, 2L, 1L), DeckCardSorting.sort(cards, "MV_ASC", false).map { it.id })
    }
    @Test fun additionTimeWinsOverRowIdAndCategoryEditsDoNotAffectFlatOrder() {
        val cards = listOf(card(1, 2.0).copy(addedAt=100), card(2, 3.0).copy(addedAt=200), card(3, 1.0).copy(addedAt=150))
        assertEquals(listOf(2L, 3L, 1L), DeckCardSorting.sort(cards, "ADDED_DESC", false).map { it.id })
        assertEquals(listOf(2L, 3L, 1L), DeckCardSorting.sort(cards.map { it.copy(userCategory="別分類") }, "ADDED_DESC", false).map { it.id })
    }
}
