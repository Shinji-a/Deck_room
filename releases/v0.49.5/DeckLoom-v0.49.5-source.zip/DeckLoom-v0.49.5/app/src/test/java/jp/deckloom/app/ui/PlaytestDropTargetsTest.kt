package jp.deckloom.app.ui
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import jp.deckloom.app.playtest.Zone
import org.junit.Assert.*
import org.junit.Test
class PlaytestDropTargetsTest {
    private val targets = mapOf("battlefield" to Rect(0f, 0f, 400f, 600f), "hand" to Rect(0f, 600f, 400f, 750f), "graveyard" to Rect(200f, 750f, 300f, 830f))
    private val cancel = Rect(80f, 0f, 320f, 60f)
    @Test fun battlefieldUnderOriginalBrowserCardRemainsAValidDestination() {
        // This point was occupied by the source card before the browser became transparent.
        assertEquals(Zone.BATTLEFIELD, PlaytestDropTargets.resolve(Offset(180f, 300f), targets, cancel))
    }
    @Test fun dedicatedCancelTakesPriorityEvenWhereBattlefieldIsUnderneath() {
        assertNull(PlaytestDropTargets.resolve(Offset(180f, 30f), targets, cancel))
        assertEquals(Zone.BATTLEFIELD, PlaytestDropTargets.resolve(Offset(180f, 30f), targets))
    }
    @Test fun handAndOtherZonesRemainReachableAndOutsideIsNoMove() {
        assertEquals(Zone.HAND, PlaytestDropTargets.resolve(Offset(200f, 640f), targets, cancel))
        assertEquals(Zone.GRAVEYARD, PlaytestDropTargets.resolve(Offset(230f, 780f), targets, cancel))
        assertNull(PlaytestDropTargets.resolve(Offset(600f, 300f), targets, cancel))
    }
}
