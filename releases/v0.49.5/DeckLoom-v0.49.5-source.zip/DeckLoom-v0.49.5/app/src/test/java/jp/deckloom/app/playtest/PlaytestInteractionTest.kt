package jp.deckloom.app.playtest

import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import org.junit.Assert.*
import org.junit.Test

class PlaytestInteractionTest {
    private fun game(): PlaytestSession = PlaytestSession().also { session ->
        session.newGame(listOf(
            DeckCardEntity(id = 1, deckId = 1, inputName = "Main fixture", quantity = 10, backImagePath = "/fixture-back.jpg"),
            DeckCardEntity(id = 2, deckId = 1, inputName = "Commander fixture", quantity = 1, specialRole = DeckSpecialRoles.COMMANDER, isCommander = true),
            DeckCardEntity(id = 3, deckId = 1, inputName = "Candidate fixture", quantity = 20, deckRole = DeckRoles.CANDIDATE),
        ))
    }

    @Test fun realDeckQuantitiesAndCommandZoneRemainSeparateFromCandidates() {
        val session = game()
        assertEquals(11, session.state.value.cards.size)
        assertEquals(7, session.state.value.zone(Zone.HAND).size)
        assertEquals(3, session.state.value.zone(Zone.LIBRARY).size)
        assertEquals(2L, session.state.value.zone(Zone.COMMAND).single().sourceId)
        assertFalse(session.state.value.cards.any { it.sourceId == 3L })
    }

    @Test fun detailMovementThroughEveryZoneCanBeUndoneAndRedone() {
        val session = game()
        val uid = session.state.value.zone(Zone.HAND).first().uid
        for (zone in listOf(Zone.BATTLEFIELD, Zone.GRAVEYARD, Zone.EXILE, Zone.LIBRARY, Zone.HAND, Zone.COMMAND)) {
            val before = session.state.value
            session.move(uid, zone, toBottom = zone == Zone.LIBRARY)
            val after = session.state.value
            assertEquals(zone, after.cards.single { it.uid == uid }.zone)
            assertEquals(11, after.cards.size)
            if (zone == Zone.LIBRARY) assertEquals(uid, after.zone(zone).last().uid)
            session.undo()
            assertEquals(before, session.state.value)
            session.redo()
            assertEquals(after, session.state.value)
        }
    }

    @Test fun nextTurnUntapsAndDrawsWithoutLosingCountersMarkerOrBackFace() {
        val session = game()
        val uid = session.state.value.zone(Zone.HAND).first().uid
        session.move(uid, Zone.BATTLEFIELD, boardX = 24f, boardY = 36f)
        session.toggleTap(uid)
        session.counter(uid, 2)
        session.toggleMarker(uid)
        session.toggleBackFace(uid)
        val before = session.state.value
        session.nextTurn()
        val after = session.state.value
        val card = after.cards.single { it.uid == uid }
        assertEquals(2, after.turn)
        assertEquals(before.zone(Zone.HAND).size + 1, after.zone(Zone.HAND).size)
        assertFalse(card.tapped)
        assertEquals(2, card.counters)
        assertTrue(card.marked)
        assertEquals("BACK", card.faceMode)
        assertEquals(24f, card.boardX, 0f)
        assertEquals(36f, card.boardY, 0f)
        session.undo(); assertEquals(before, session.state.value)
        session.redo(); assertEquals(after, session.state.value)
    }

    @Test fun handReorderingAndNewestDrawRetainUndoHistory() {
        val session = game()
        val drawUid = session.state.value.zone(Zone.LIBRARY).first().uid
        session.draw()
        assertEquals(drawUid, session.state.value.zone(Zone.HAND).first().uid)
        val before = session.state.value
        val oldOrder = before.zone(Zone.HAND).map { it.uid }
        session.reorderHand(oldOrder.last(), 0)
        val after = session.state.value
        assertEquals(listOf(oldOrder.last()) + oldOrder.dropLast(1), after.zone(Zone.HAND).map { it.uid })
        session.undo(); assertEquals(before, session.state.value)
        session.redo(); assertEquals(after, session.state.value)
    }
}
