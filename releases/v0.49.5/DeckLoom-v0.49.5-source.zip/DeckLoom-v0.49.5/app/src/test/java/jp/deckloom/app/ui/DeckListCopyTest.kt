package jp.deckloom.app.ui

import jp.deckloom.app.data.DeckCardEntity
import jp.deckloom.app.data.DeckRoles
import jp.deckloom.app.data.DeckSpecialRoles
import org.junit.Assert.assertEquals
import org.junit.Test

class DeckListCopyTest {
    private val main = DeckCardEntity(id = 1, deckId = 1, quantity = 1,
        inputName = "Main", oracleName = "Main", displayName = "メイン", deckRole = DeckRoles.MAIN)
    private val candidate = DeckCardEntity(id = 2, deckId = 1, quantity = 3,
        inputName = "Candidate", oracleName = "Candidate", displayName = "候補(こうほ)", deckRole = DeckRoles.CANDIDATE)
    private val commander = DeckCardEntity(id = 3, deckId = 1, quantity = 1,
        inputName = "Commander", oracleName = "Commander", displayName = "統率者",
        deckRole = DeckRoles.COMMANDER, specialRole = DeckSpecialRoles.COMMANDER)

    @Test fun candidateTabExportsOnlyCandidatesWithRealQuantitiesInBothLanguages() {
        val another = candidate.copy(id = 4, quantity = 2, displayName = "別候補", oracleName = "Other Candidate")
        val cards = listOf(main, commander, candidate, another)
        assertEquals(setOf("3 候補", "2 別候補"), deckListForCopy(cards, true, false).lines().toSet())
        assertEquals(setOf("3 Candidate", "2 Other Candidate"), deckListForCopy(cards, true, true).lines().toSet())
        assertEquals(DeckRoles.CANDIDATE, candidate.deckRole)
    }

    @Test fun mainTabPreservesCommanderFirstAndExcludesCandidatesInBothLanguages() {
        val cards = listOf(candidate, main, commander)
        assertEquals("1 統率者\n1 メイン", deckListForCopy(cards, false, false))
        assertEquals("1 Commander\n1 Main", deckListForCopy(cards, false, true))
    }

    @Test fun emptyCandidateTabNeverFallsBackToMainDeck() {
        assertEquals("", deckListForCopy(listOf(main, commander), true, false))
        assertEquals("", deckListForCopy(listOf(main, commander), true, true))
    }

    @Test fun candidateListIncludesDifferentCategoriesAndUnresolvedNameFallbacks() {
        val unresolved = candidate.copy(id = 4, quantity = 5, displayName = "", oracleName = "",
            inputName = "Pending name", userCategory = "別のカテゴリ")
        val cards = listOf(candidate.copy(userCategory = "試したいカード"), unresolved, main)
        assertEquals(setOf("3 候補", "5 Pending name"), deckListForCopy(cards, true, false).lines().toSet())
        assertEquals(setOf("3 Candidate", "5 Pending name"), deckListForCopy(cards, true, true).lines().toSet())
    }
}
