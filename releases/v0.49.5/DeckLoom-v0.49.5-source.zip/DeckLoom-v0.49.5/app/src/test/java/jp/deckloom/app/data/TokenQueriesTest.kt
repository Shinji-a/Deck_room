package jp.deckloom.app.data

import org.junit.Assert.*
import org.junit.Test
import java.sql.Connection
import java.sql.DriverManager

class TokenQueriesTest {
    private fun withTokens(test: (Connection) -> Unit) {
        DriverManager.getConnection("jdbc:sqlite::memory:").use { db ->
            db.createStatement().use { statement ->
                statement.execute("""CREATE TABLE tokens (
                    token_key TEXT PRIMARY KEY, english_name TEXT, japanese_name TEXT,
                    english_type_line TEXT, japanese_type_line TEXT, power TEXT, toughness TEXT,
                    preferred_image_normal TEXT, japanese_image_normal TEXT,
                    preferred_scryfall_id TEXT, japanese_scryfall_id TEXT
                )""")
                statement.execute("""INSERT INTO tokens VALUES
                    ('treasure', 'Treasure', '宝物', 'Token Artifact — Treasure', '', NULL, NULL, 'en.jpg', '', 'en-id', ''),
                    ('bear-small', 'Bear', '熊', 'Token Creature — Bear', '', '1', '1', '', '', '', ''),
                    ('bear-large', 'Bear', '熊', 'Token Creature — Bear', '', '2', '2', '', '', '', ''),
                    ('bear-tall', 'Bear', '熊', 'Token Creature — Bear', '', '2', '3', '', '', '', ''),
                    ('variable', 'Spirit', 'スピリット', 'Token Creature — Spirit', '', '*', '*', '', '', '', '')
                """)
            }
            db.createStatement().use {
                it.execute("ALTER TABLE tokens ADD COLUMN english_oracle_text TEXT")
                it.execute("ALTER TABLE tokens ADD COLUMN japanese_text TEXT")
                it.execute("UPDATE tokens SET english_oracle_text='Add one mana', japanese_text='好きな色のマナ１点を加える。' WHERE token_key='treasure'")
            }
            test(db)
        }
    }

    private fun find(db: Connection, name: String, power: String? = null, toughness: String? = null): List<String>? {
        val query = TokenQueries.byName(name, power, toughness)
        assertEquals(query.sql.count { it == '?' }, query.args.size)
        // JDBC accepts null, but Android rawQuery does not. Enforce Android's contract here.
        query.args.forEach { assertNotNull("rawQuery must not receive a null bind value", it) }
        return db.prepareStatement(query.sql).use { statement ->
            query.args.forEachIndexed { index, value -> statement.setString(index + 1, value) }
            statement.executeQuery().use { result ->
                if (result.next()) (1..9).map { result.getString(it).orEmpty() } else null
            }
        }
    }

    @Test fun unspecifiedStatsFindNoncreatureTokens() = withTokens { db ->
        assertEquals(listOf("Treasure", "Treasure"), TokenQueries.byName("Treasure").args)
        val row = find(db, "Treasure")!!
        assertEquals("treasure", row[0])
        assertEquals("", row[4])
        assertEquals("", row[5])
        assertEquals("en.jpg", row[6])
        assertEquals("en-id", row[7])
    }

    @Test fun specifiedStatsApplyToBothEnglishAndJapaneseNames() = withTokens { db ->
        for (name in listOf("bEaR", "熊")) {
            assertEquals("bear-large", find(db, name, "2", "2")?.first())
            assertNull(find(db, name, "9", "9"))
        }
    }

    @Test fun eitherStatCanBeSpecifiedIndependently() = withTokens { db ->
        assertEquals("bear-small", find(db, "Bear", power = "1")?.first())
        assertEquals("bear-tall", find(db, "Bear", toughness = "3")?.first())
    }

    @Test fun unspecifiedEmptyAndVariableStatsRemainDifferent() = withTokens { db ->
        assertNotNull(find(db, "Bear"))
        assertNull(find(db, "Bear", power = ""))
        assertEquals("variable", find(db, "Spirit", "*", "*")?.first())
    }

    @Test fun namesAndStatsRemainBoundValues() = withTokens { db ->
        assertNull(find(db, "Bear' OR 1=1 --"))
        assertNull(find(db, "Bear", "2' OR 1=1 --", "2"))
    }
    @Test fun tokenBodyPrefersJapaneseAndFallsBackToEnglish() = withTokens { db ->
        assertEquals("好きな色のマナ１点を加える。", find(db, "Treasure")!![8])
        db.createStatement().use { it.execute("UPDATE tokens SET japanese_text='' WHERE token_key='treasure'") }
        assertEquals("Add one mana", find(db, "Treasure")!![8])
        assertEquals("", find(db, "Bear")!![8])
    }
}
