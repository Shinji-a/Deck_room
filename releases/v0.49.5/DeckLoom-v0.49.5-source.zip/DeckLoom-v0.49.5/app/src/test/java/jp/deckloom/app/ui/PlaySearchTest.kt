package jp.deckloom.app.ui

import org.junit.Assert.*
import org.junit.Test

class PlaySearchTest {
    @Test fun nameAndTextScopesDoNotLeakIntoOneAnother() {
        assertTrue(matchesPlaySearch("森 Forest", "基本土地", "Forest", "NAME"))
        assertFalse(matchesPlaySearch("森 Forest", "基本土地", "土地", "NAME"))
        assertTrue(matchesPlaySearch("森 Forest", "基本土地", "土地", "TEXT"))
        assertFalse(matchesPlaySearch("森 Forest", "基本土地", "森", "TEXT"))
    }
    @Test fun combinedScopeFindsEitherFieldIncludingEnglishCase() {
        assertTrue(matchesPlaySearch("森 Forest", "基本土地", "forest", "ALL"))
        assertTrue(matchesPlaySearch("森 Forest", "基本土地", "基本", "ALL"))
        assertFalse(matchesPlaySearch("森 Forest", "基本土地", "宝物", "ALL"))
    }
    @Test fun clearingOrWhitespaceRestoresTheWholeZone() {
        for (scope in listOf("ALL", "NAME", "TEXT")) {
            assertTrue(matchesPlaySearch("森", "", "", scope))
            assertTrue(matchesPlaySearch("森", "", "  ", scope))
        }
    }
}
