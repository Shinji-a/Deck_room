package jp.deckloom.app.data

import androidx.sqlite.db.SupportSQLiteDatabase
import jp.deckloom.app.DeckLoomApplication
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy
import java.sql.DriverManager

/** Runs the production migration SQL on SQLite. Device Room-open validation is separate. */
class Migration5To6Test {
    @Test fun migrationKeepsDecksCardsAndCustomCategoriesAndFolderDeletionKeepsDecks() {
        DriverManager.getConnection("jdbc:sqlite::memory:").use { connection ->
            fun sql(statement: String) { connection.createStatement().use { it.execute(statement) } }
            fun rows(statement: String): List<List<String?>> = connection.createStatement().use { s ->
                s.executeQuery(statement).use { r -> buildList { while (r.next()) add((1..r.metaData.columnCount).map { r.getString(it) }) } }
            }
            sql("PRAGMA foreign_keys=ON")
            val schema = requireNotNull(javaClass.classLoader?.getResourceAsStream("schema-v5.sql")).bufferedReader().use { it.readText() }
            schema.split(';').filter { it.isNotBlank() }.forEach(::sql)
            sql("INSERT INTO decks VALUES (1,'古いデッキ',100),(2,'新しいデッキ',200),(3,'同時刻のデッキ',200)")
            fun insertCard(id: Int, deck: Int, quantity: Int, category: String, special: String) {
                val columns = rows("PRAGMA table_info(deck_cards)")
                val data = mapOf("id" to id.toString(), "deckId" to deck.toString(), "quantity" to quantity.toString(), "category" to category, "specialRole" to special,
                    "imagePath" to "/saved/image.jpg", "selectedPrintingId" to "chosen-printing", "oracleText" to "元のカード本文", "deckRole" to "MAIN")
                val values = columns.map { data[it[1]] ?: if (it[2] == "TEXT") "" else "0" }
                connection.prepareStatement("INSERT INTO deck_cards (${columns.joinToString(",") { it[1]!! }}) VALUES (${values.joinToString(",") { "?" }})").use { statement ->
                    values.forEachIndexed { index, value -> statement.setString(index + 1, value) }
                    statement.executeUpdate()
                }
            }
            insertCard(10,1,1,"Creature","COMMANDER")
            insertCard(11,1,4,"マナ加速","NONE")
            insertCard(12,2,1,"未分類","NONE")
            val database = Proxy.newProxyInstance(SupportSQLiteDatabase::class.java.classLoader, arrayOf(SupportSQLiteDatabase::class.java)) { _, method, args ->
                if (method.name == "execSQL" && args?.size == 1) { sql(args[0] as String); null }
                else error("Unexpected database call: ${method.name}")
            } as SupportSQLiteDatabase
            DeckLoomApplication.MIGRATION_5_6.migrate(database)
            assertEquals(listOf(listOf("3"), listOf("2"), listOf("1")), rows("SELECT id FROM decks ORDER BY sortOrder,createdAt DESC,id DESC"))
            assertEquals(listOf(listOf("10","1","","COMMANDER"),listOf("11","4","マナ加速","NONE"),listOf("12","1","","NONE")), rows("SELECT id,quantity,userCategory,specialRole FROM deck_cards ORDER BY id"))
            assertEquals(listOf(listOf(null,"","REGISTERED")), rows("SELECT folderId,note,cardSortMode FROM decks WHERE id=1"))
            assertEquals(listOf(listOf("/saved/image.jpg","chosen-printing","元のカード本文","MAIN")), rows("SELECT imagePath,selectedPrintingId,oracleText,deckRole FROM deck_cards WHERE id=10"))
            sql("INSERT INTO deck_folders VALUES (1,'調整済み',0)")
            sql("UPDATE decks SET folderId=1,note='テストメモ',cardSortMode='MV_ASC' WHERE id=1")
            sql("DELETE FROM deck_folders WHERE id=1")
            assertEquals(listOf(listOf(null,"テストメモ","MV_ASC")), rows("SELECT folderId,note,cardSortMode FROM decks WHERE id=1"))
            assertEquals(listOf(listOf("3")), rows("SELECT COUNT(*) FROM deck_cards"))
            assertTrue(rows("PRAGMA foreign_key_check").isEmpty())
            assertTrue(rows("PRAGMA index_list(decks)").any { it[1] == "index_decks_folderId" })
        }
    }
}
