-- Frozen Room v5 schema derived from the v0.46 entities.

CREATE TABLE `decks` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  `name` TEXT NOT NULL,
  `createdAt` INTEGER NOT NULL
);

CREATE TABLE `deck_cards` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  `deckId` INTEGER NOT NULL,
  `quantity` INTEGER NOT NULL,
  `inputName` TEXT NOT NULL,
  `oracleName` TEXT NOT NULL,
  `oracleId` TEXT NOT NULL DEFAULT '',
  `displayName` TEXT NOT NULL,
  `printedName` TEXT NOT NULL,
  `displayTypeLine` TEXT NOT NULL,
  `oracleTypeLine` TEXT NOT NULL,
  `oracleText` TEXT NOT NULL,
  `manaCost` TEXT NOT NULL,
  `cmc` REAL NOT NULL,
  `colorIdentity` TEXT NOT NULL,
  `scryfallId` TEXT NOT NULL,
  `imagePath` TEXT NOT NULL,
  `backImagePath` TEXT NOT NULL,
  `selectedPrintingId` TEXT NOT NULL DEFAULT '',
  `category` TEXT NOT NULL,
  `isCommander` INTEGER NOT NULL,
  `deckRole` TEXT NOT NULL DEFAULT 'MAIN',
  `specialRole` TEXT NOT NULL DEFAULT 'NONE',
  `cacheState` TEXT NOT NULL,
  `errorMessage` TEXT NOT NULL,
  FOREIGN KEY (`deckId`) REFERENCES `decks` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
);

CREATE INDEX `index_deck_cards_deckId` ON `deck_cards` (`deckId`);

CREATE INDEX `index_deck_cards_deckId_deckRole` ON `deck_cards` (`deckId`, `deckRole`);


-- Existing v5 tables added to the fixture for v6->v7 preservation checks.
CREATE TABLE `deck_change_log` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  `deckId` INTEGER NOT NULL,
  `createdAt` INTEGER NOT NULL,
  `action` TEXT NOT NULL,
  `cardName` TEXT NOT NULL,
  `quantity` INTEGER NOT NULL,
  `fromRole` TEXT NOT NULL,
  `toRole` TEXT NOT NULL,
  `note` TEXT NOT NULL,
  FOREIGN KEY (`deckId`) REFERENCES `decks` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE
);
CREATE INDEX `index_deck_change_log_deckId` ON `deck_change_log` (`deckId`);
CREATE INDEX `index_deck_change_log_deckId_createdAt` ON `deck_change_log` (`deckId`, `createdAt`);
CREATE TABLE `saved_searches` (
  `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  `createdAt` INTEGER NOT NULL,
  `description` TEXT NOT NULL,
  `filterJson` TEXT NOT NULL
);
CREATE INDEX `index_saved_searches_createdAt` ON `saved_searches` (`createdAt`);
