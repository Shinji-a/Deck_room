# v0.49.2 検証結果

2026-10-10、前回納品のv0.49.1 Sourceを基準に検証しました。実機／エミュレーターでのアプリ描画・指操作は未確認です。

| 検証 | 結果 |
| --- | --- |
| Web参照 | 指定URL、リンク先CSS、ページJSがHTTP 200。配色はCSSの定義と使用箇所から確認 |
| 配色値照合 | Androidで採用したHEX色30種類がすべて取得CSS内に存在 |
| 文字コントラスト | 主要20組（明色10・暗色10）が4.5:1以上。明色primaryは5.25:1、エラー文字と面は5.12:1 |
| `:app:assembleDebug` | 成功 |
| `:app:testDebugUnitTest` | 57件成功／失敗0／エラー0／スキップ0 |
| APKメタデータ | jp.deckloom.app / versionName 0.49.2 / versionCode 21 / minSdk 26 |
| `:app:lintDebug` | 前回と同じFullBackupContentエラー6件・警告31件・ヒント2件。元v0.49の指摘とも一致し、追加指摘なし |
| Source／Patch | 元の納品v0.49.1 ZIPへ実際のPatch ZIPを適用し、Source版149ファイルとのバイト一致を確認 |

環境は前回と同じTemurin JDK 17.0.18+8、Gradle 8.13、Android Platform 36／Build Tools 35.0.0。前回の変更前v0.49ビルドと50テスト、v0.49.1の57テストの記録は[前回の検証資料](VALIDATION-v0.49.1.md)に保持しています。

今回の本番変更はテーマの配色とバージョン表記です。テーマ以外のv0.49.1画面実装、DB取得・日本語補完・更新・キャッシュ・一人回しエンジン・移行・依存宣言が同一であることを照合し、既存の57回帰テストを再実行しました。

`tools/verify_room_schema.py`も5→6→7→8移行後の5テーブルとRoom生成DDLが一致し、foreign_key_checkを通過。`tools/verify_regex_icu.py`はICU 76で本番22正規表現とマナ抽出9ケースを通過しています。

配色のソースと対応表は[WEB_COLORS.md](WEB_COLORS.md)。現行Webの専用エラー画面とダーク描画は未確認です。AndroidのエラーはWebの負の状態の色、ダークはCSSの暗色ベースを参照した対応です。ブラウザー表示や実機での描画を確認したとは扱いません。

文字コントラストの照合は直接指定した文字／面の色を対象にしています。Materialの半透明な無効状態・押下状態・スクロール・ドラッグ・文字拡大・操作感はこの検証の対象外です。[TODO.md](TODO.md)で実機確認が必要です。

配布はSourceとv0.49.1向けPatchのセットです。変更7・追加2・削除0ファイル。実際の元ZIPと配布Patch ZIPの適用結果を、Source版全149ファイルとバイト単位で照合し、ZIPのCRCチェックも通過しています。SDK・キャッシュ・署名キー・ビルド生成物・端末固有設定は含めません。SHA-256はSHA256SUMS-v0.49.2.txt、照合結果はverification-v0.49.2.jsonに記録しています。
