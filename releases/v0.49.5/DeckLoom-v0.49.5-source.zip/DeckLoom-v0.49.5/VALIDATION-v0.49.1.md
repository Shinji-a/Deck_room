# v0.49.1 検証結果

2026-10-10、添付v0.49 Sourceを基準に検証しました。Android実機／エミュレーターでの起動・描画・指操作は未実施です。

## 環境と変更前の確認

- Temurin JDK 17.0.18+8、Gradle Wrapper 8.13、Android Platform 36 / Build Tools 35.0.0。
- 元Sourceの全139ファイルが一致する状態で `:app:assembleDebug :app:testDebugUnitTest` を実行し、成功を確認してからUIを変更しました。
- 変更前JUnitは **50件成功／失敗0／エラー0／スキップ0**。設定・依存バージョンは変更していません。
- 保存済み導入スクリプトの再実行も成功。詳細は[CLOUD_SETUP.md](CLOUD_SETUP.md)を参照。

## 変更後の確認

| チェック | 結果 |
| --- | --- |
| `:app:assembleDebug` | 成功 |
| `:app:testDebugUnitTest` | **57件成功／失敗0／エラー0／スキップ0** |
| APKメタデータ | jp.deckloom.app / versionName 0.49.1 / versionCode 20 / minSdk 26 |
| `tools/verify_room_schema.py` | 本番5→6→7→8移行とRoom生成DDLの5テーブルが一致。foreign_key_check通過 |
| `tools/verify_regex_icu.py` | ICU 76で本番22正規表現のコンパイルとマナ抽出9ケース成功。v0.47の旧式の位置8での失敗も再現 |
| `:app:lintDebug` | 既存バックアップ設定のFullBackupContentエラー6件で失敗。元v0.49も同じ6件・警告31件・ヒント2件。追加指摘0件 |
| Source／Patch適用照合 | 元の添付ZIPへ実際のPatch ZIPを上書きし、Source版全147ファイルとのバイト一致を確認 |

追加した7テストは、一人回しエンジンの実枚数・候補除外・統率領域、全領域への移動とUndo／Redo、次ターンとカウンター／マーカー／裏面保持、手札並べ替え・ドロー、および領域検索の名前／本文／両方・空入力を対象にしています。元の50件には、分類とカテゴリをまたぐ並び順、基本土地・特例の枚数制限、Undo、選択出力、フォルダ、移行、トークン、戻る操作、ドラッグの領域判定の回帰が含まれます。

これらはJVM、JDBC／Python SQLite、ICUによる確認です。Compose画面の描画・ジェスチャー、Android端末上のRoom移行、ユーザー実データの更新を実行したとは扱いません。

## Lintの既存指摘

`backup_rules.xml` の5・6行目と `data_extraction_rules.xml` の6・7・12・13行目が対象です。databaseとsharedprefだけをincludeした設定にfileのexcludeがあるため、`deck_cards/` と `card_index/` がinclude対象ではないと報告されます。両ファイルは添付v0.49からバイト単位で変更していません。

バックアップ仕様は今回のUI改修対象外として維持しました。Lintを無効化したり、新しいbaselineファイルで指摘を隠したりしていません。元のv0.49 Sourceを別の作業コピーで実際にLintへかけ、変更前と変更後のID・重要度・メッセージ・対象ファイルの件数を比較した結果、同じ指摘であることを確認しました。Gradle／Composeの既存非推奨警告も残ります。

## 保持した処理・データ

- `data/`、`network/`、`playtest/`の本番全ファイル、`DeckLoomApplication.kt`のDB移行、Gradle Wrapper・依存宣言が添付v0.49と同じであることを照合。
- カード検索DB取得、日本語補完、更新・画像キャッシュ、重複例外、候補保存、Undoのトランザクションは既存実装を利用。
- READMEのカードDB・画像出典の節を元版のまま保持。`MANA_ASSETS.md`とアプリ内READMEの出典記載も維持。
- HTMLモックの画像・本文・枚数・簡略動作はアプリへ追加していません。

## 配布と残る確認

Sourceと**添付v0.49向け**Patchをセットで生成しました。元の添付Source ZIPを作業コピーへ展開し、実際に配布するPatch ZIPを適用して、Source版の全147ファイルとのバイト一致を確認しています。変更14・追加8・削除0ファイルです。Patch直下はapp・文書等のプロジェクト相対パスで、files階層はありません。ZIPのCRCチェックも通過しました。

適用方法は[RELEASE-v0.49.1.md](RELEASE-v0.49.1.md)を参照してください。SDK・キャッシュ・ビルド生成物・署名キー・端末固有設定は配布しません。配布ZIPのSHA-256と照合詳細は成果物のSHA256SUMS.txt／verification-v0.49.1.jsonに記録しています。

Web配色は指定URLへの接続が通信プロキシで403拒否となり未確認です。推測の色を採用せず、現行テーマを暫定維持しています。[WEB_COLORS.md](WEB_COLORS.md)の6種類の確認・反映が必要です。

実機での表示、文字拡大・横画面・小画面、スクロール、サムネイルからのドラッグと領域移動、通知によるボタン位置、ダイアログの操作感、オンライン／オフライン画像表示、既存データへの上書きRunは未確認です。[TODO.md](TODO.md)を実機チェックリストとします。
