# v0.49 検証結果

## ビルド

- JDK 17.0.20、Gradle 8.13、Android SDK Platform 36 / Build Tools 35.0.0。
- `:app:assembleDebug :app:testDebugUnitTest`：成功。
- APKメタデータ：applicationId `jp.deckloom.app`、versionName `0.49`、versionCode `19`、minSdk 26。
- JUnit **50件成功／失敗0／エラー0／スキップ0**。

| テスト | 件数 | 主な対象 |
| --- | ---: | --- |
| CardLocalization | 14 | 日本語名・本文の優先、両面／出来事などの既存回帰 |
| CardPresentation | 6 | 読み仮名、分類優先、分類内／全体ソート、新旧の追加順 |
| DeckEdits | 7 | Oracle同一性、候補の除外、無制限と特例上限、既存超過の削減、未照合、Undo、選択出力 |
| FolderTree | 5 | 階層・循環移動などの回帰 |
| Migration5To6 / 6To7 / 7To8 | 各1 | 本番移行SQL、既存値の保持、追加列、外部キー |
| TokenQueries | 6 | null引数クラッシュの回帰とP/T検索・本文の言語優先 |
| TokenSession | 4 | トークン連続追加、セッション操作の回帰 |
| NavigationGate | 2 | 古い画面のコールバック、連打、遷移中、空スタック |
| PlaytestDropTargets | 3 | 元カード直下への配置、専用キャンセルの優先、領域判定、無効な場所 |

## DB移行と正規表現

- `python3 tools/verify_room_schema.py`：成功。本番5→6→7→8移行後とRoom生成スキーマのdecks・deck_cards・deck_folders・deck_change_log・saved_searchesについて、列・既定値・キー・インデックスが一致。foreign_key_check通過。
- `python3 tools/verify_regex_icu.py`：成功。ICU 74で本番の正規表現22箇所をコンパイル、マナ抽出9ケース成功。v0.47の旧式が位置8で失敗することも再現。
- これらはJDBC／Python SQLiteと本番移行クラス・Room生成DDLによる確認です。Android端末上の移行テストではありません。

## 配布内容

Sourceとv0.48.1用Patchを生成し、元Sourceを展開した作業コピーへ実際のPatch ZIPを上書きして、Source版の全139ファイルとのバイト一致を確認しました。変更30・追加10・削除0ファイルです。Patch直下にapp等を置き、files階層はありません。ビルド生成物・端末固有SDK設定・署名キーは配布Sourceへ含めません。

## 残る実機確認

Android端末／エミュレーターでの画面描画、スクロールとドラッグの感触、ダイアログのサイズ、ユーザー実データへの上書きRun、オンライン／オフラインの画像表示は未確認です。詳細はTODO.mdのv0.49実機確認を参照してください。

ビルドには既存のGradle／Compose API非推奨警告等が残ります。今回の成果物はソースと差分です。いつもの署名でAndroid StudioからRunしてください。
