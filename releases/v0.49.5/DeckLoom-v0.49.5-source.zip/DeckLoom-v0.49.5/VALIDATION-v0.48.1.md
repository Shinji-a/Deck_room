# v0.48.1 検証

- JDK 17 / Gradle 8.13 / Android SDK 36で :app:assembleDebug と :app:testDebugUnitTest を実行。
- JUnit 34件: 既存20件＋CardLocalizationTest 14件。面名の欠落・順序・集約名、片面本文欠落、JSON null、英語混入、DB優先、Oracle ID不一致、保存済みカードの設定保持を検証。
- ICU 74: 本番正規表現22箇所がコンパイル可能。過去のマナ正規表現クラッシュを再現し、現行式9ケース成功。
- 既存Room 5→7移行と生成schema 7の照合、foreign_key_check成功。今回はschema・migrationを変更していない。
- 配布Patchをv0.48へ上書きした結果とSource版をファイル単位で照合。

DB生成側は別リポジトリ。39件の回帰テストと同一bulk全件再生成の旧実装比較を実施。
54万2,689印刷版／3万7,589カード。日本語以外のカード列、トークン、収録セット、表示用語は一致。
後続面名だけが日本語だった88件は、すべて日本語本体名を補完。

実機表示、端末内の実データを用いた更新、スクロールやタップの感触は未検証。
既存Compose等の非推奨警告は残る。
