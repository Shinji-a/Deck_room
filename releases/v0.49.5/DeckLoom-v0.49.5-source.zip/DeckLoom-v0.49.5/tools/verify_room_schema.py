"""After assembleDebug, compare the production 5->6->7->8 migrations with Room's generated schema.
Uses only Python's standard library. Does not open any user database.
"""
from pathlib import Path
import json
import re
import sqlite3

root = Path(__file__).resolve().parents[1]
fixture = root / 'app/src/test/resources/schema-v5.sql'
application = root / 'app/src/main/java/jp/deckloom/app/DeckLoomApplication.kt'
generated = list((root / 'app/build/generated/ksp').rglob('AppDatabase_Impl.*'))
if not generated:
    raise SystemExit('Run :app:assembleDebug first to generate the Room implementation.')

expected = sqlite3.connect(':memory:')
migrated = sqlite3.connect(':memory:')
for db in (expected, migrated):
    db.execute('PRAGMA foreign_keys=ON')

# Room may emit Java or Kotlin; these DDL strings contain no interpolation.
literal = r'"(?:[^"\\]|\\.)*"'
statements = []
for match in re.finditer(r'execSQL\((' + literal + r')\)', generated[0].read_text()):
    text = json.loads(match.group(1))
    if text.startswith('CREATE TABLE') or text.startswith('CREATE INDEX') or text.startswith('CREATE UNIQUE INDEX'):
        statements.append(text)
if not statements:
    raise SystemExit('Room DDL format changed; update this verifier before using it.')
for sql in statements:
    expected.execute(sql)

migrated.executescript(fixture.read_text())
for version in ('5_6', '6_7', '7_8'):
    block = application.read_text().split(f'val MIGRATION_{version} =', 1)[1].split('val MIGRATION_', 1)[0]
    for match in re.finditer(r'db\.execSQL\((' + literal + r')\)', block):
        migrated.execute(json.loads(match.group(1)))

def schema(db, table):
    columns = sorted(tuple(row[1:]) for row in db.execute(f'PRAGMA table_info({table})'))
    foreign = sorted(tuple(row[2:]) for row in db.execute(f'PRAGMA foreign_key_list({table})'))
    indexes = []
    for row in db.execute(f'PRAGMA index_list({table})'):
        if row[3] == 'pk':
            continue
        indexes.append((row[1], row[2], tuple(r[2] for r in db.execute(f'PRAGMA index_info({row[1]})'))))
    return columns, foreign, sorted(indexes)

for table in ('decks', 'deck_cards', 'deck_folders', 'deck_change_log', 'saved_searches'):
    actual, wanted = schema(migrated, table), schema(expected, table)
    assert actual == wanted, f'{table} schema mismatch:\nactual={actual}\nexpected={wanted}'
    print(f'PASS {table}: migrated v5 matches generated Room v8 columns, defaults, keys and indexes')
assert not list(migrated.execute('PRAGMA foreign_key_check'))
print('PASS foreign_key_check')
