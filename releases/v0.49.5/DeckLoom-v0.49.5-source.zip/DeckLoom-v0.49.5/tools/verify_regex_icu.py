"""Check production Kotlin Regex literals with ICU, plus the v0.47 mana regression.

Run with Python 3 on Linux with libicui18n/libicuuc installed. No pip packages
are required. This checks the ICU engine directly; it is not an Android device
or Compose UI test. Desktop JVM tests alone miss the unescaped-brace crash.
"""
from pathlib import Path
import ctypes as C
from ctypes.util import find_library
import json
import re


class ParseError(C.Structure):
    _fields_ = [
        ("line", C.c_int32), ("offset", C.c_int32),
        ("preContext", C.c_uint16 * 16), ("postContext", C.c_uint16 * 16),
    ]


def load_icu():
    name = find_library("icui18n")
    common = find_library("icuuc")
    if not name or not common:
        raise SystemExit("ICU shared libraries are required (libicui18n and libicuuc).")
    lib, uc = C.CDLL(name), C.CDLL(common)
    suffix = re.search(r"\.so\.(\d+)", name)
    suffix = "_" + suffix.group(1) if suffix else ""

    def fn(owner, symbol, args, result):
        method = getattr(owner, symbol + suffix)
        method.argtypes, method.restype = args, result
        return method

    status = C.POINTER(C.c_int32)
    uchar = C.POINTER(C.c_uint16)
    return {
        "library": name,
        "open": fn(lib, "uregex_open", [uchar, C.c_int32, C.c_uint32, C.POINTER(ParseError), status], C.c_void_p),
        "close": fn(lib, "uregex_close", [C.c_void_p], None),
        "set_text": fn(lib, "uregex_setText", [C.c_void_p, uchar, C.c_int32, status], None),
        "find": fn(lib, "uregex_find", [C.c_void_p, C.c_int32, status], C.c_int8),
        "next": fn(lib, "uregex_findNext", [C.c_void_p, status], C.c_int8),
        "start": fn(lib, "uregex_start", [C.c_void_p, C.c_int32, status], C.c_int32),
        "end": fn(lib, "uregex_end", [C.c_void_p, C.c_int32, status], C.c_int32),
        "error_name": fn(uc, "u_errorName", [C.c_int32], C.c_char_p),
    }


def utf16(value):
    data = value.encode("utf-16-le")
    return data, (C.c_uint16 * max(1, len(data) // 2)).from_buffer_copy(data or b"\0\0")


def compile_pattern(api, pattern):
    data, chars = utf16(pattern)
    error, detail = C.c_int32(0), ParseError()
    handle = api["open"](chars, len(data) // 2, 0, C.byref(detail), C.byref(error))
    if error.value > 0:
        if handle:
            api["close"](handle)
        raise ValueError(f'{api["error_name"](error.value).decode()} at offset {detail.offset}: {pattern}')
    if not handle:
        raise ValueError("ICU returned no compiled pattern")
    return handle


def matches(api, pattern, text):
    handle = compile_pattern(api, pattern)
    data, chars = utf16(text)
    error = C.c_int32(0)
    found = []
    try:
        api["set_text"](handle, chars, len(data) // 2, C.byref(error))
        exists = api["find"](handle, 0, C.byref(error))
        while exists and error.value <= 0:
            start = api["start"](handle, 0, C.byref(error))
            end = api["end"](handle, 0, C.byref(error))
            found.append(data[start * 2:end * 2].decode("utf-16-le"))
            exists = api["next"](handle, C.byref(error))
        if error.value > 0:
            raise ValueError(api["error_name"](error.value).decode())
        return found
    finally:
        api["close"](handle)


def main():
    root = Path(__file__).resolve().parents[1]
    api = load_icu()
    print("ICU:", api["library"])

    # Positive control: this is the exact failing v0.47 expression from Logcat.
    try:
        old = compile_pattern(api, r"\{[^}]+}")
    except ValueError as error:
        assert "U_REGEX_RULE_SYNTAX at offset 8" in str(error), error
        print("PASS: v0.47 failure reproduced (U_REGEX_RULE_SYNTAX at offset 8)")
    else:
        api["close"](old)
        raise AssertionError("This ICU build did not reproduce the reported invalid expression")

    literal = re.compile(r'Regex\(\s*(?P<raw>"""[\s\S]*?""")|Regex\(\s*(?P<quoted>"(?:\\.|[^"\\])*")')
    patterns = []
    for source in sorted((root / "app/src/main/java").rglob("*.kt")):
        text = source.read_text(encoding="utf-8")
        for match in literal.finditer(text):
            value = match.group("raw")
            value = value[3:-3] if value is not None else json.loads(match.group("quoted"))
            line = text.count("\n", 0, match.start()) + 1
            try:
                handle = compile_pattern(api, value)
            except ValueError as error:
                raise AssertionError(f"{source.relative_to(root)}:{line}: {error}") from error
            api["close"](handle)
            patterns.append((source, line, value))
    assert patterns, "No production Regex literals found"
    print(f"PASS: all {len(patterns)} production Regex literals compile under ICU")

    mana = [pattern for source, _, pattern in patterns if source.name == "ManaText.kt"]
    assert len(mana) == 1
    cases = [
        ("", []),
        ("マナ記号なし", []),
        ("{W}{U}{B}{R}{G}", ["{W}", "{U}", "{B}", "{R}", "{G}"]),
        ("{2}{W/U}{2/B}{G/P}", ["{2}", "{W/U}", "{2/B}", "{G/P}"]),
        ("{T}：{G}を加える。\n{1}{U}", ["{T}", "{G}", "{1}", "{U}"]),
        ("🐉：{R}{R}", ["{R}", "{R}"]),
        ("{NEW} {E} {X} {C}", ["{NEW}", "{E}", "{X}", "{C}"]),
        ("余分な } と {U}", ["{U}"]),
        ("{} または {W", []),
    ]
    for text, expected in cases:
        actual = matches(api, mana[0], text)
        assert actual == expected, (text, actual, expected)
    print(f"PASS: ManaText production expression extracts expected tokens in {len(cases)} cases")


if __name__ == "__main__":
    main()
