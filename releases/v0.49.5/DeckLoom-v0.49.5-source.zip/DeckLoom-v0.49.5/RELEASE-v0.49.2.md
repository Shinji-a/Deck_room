# DeckLoom v0.49.2 — Web配色の反映

基準は前回納品した**DeckLoom-v0.49.1-source.zip**。versionName **0.49.2** / versionCode **21**、applicationId `jp.deckloom.app`、Room **8** / カード検索DB schema **4**を維持します。

## 今回の変更

前回403で保留したWeb版Deckroomを再取得できたため、HTMLとCSSの値をAndroidのテーマへ反映しました。生成りの背景、白いカード面、緑のアクセント、選択面と境界線を対応させています。ライト／ダーク／端末設定の切り替えも維持します。

エラーの明色表示は、白とのコントラストが低い継承destructive色をそのまま使わず、Webの負の状態で使われる赤い文字と淡い赤の面を利用します。Androidのダークは同じCSSに残る暗色ベースを参照しています。Web専用エラー表示と現行Webの暗色描画は未確認で、根拠と違いは[WEB_COLORS.md](WEB_COLORS.md)に記載しています。

v0.49.1のデッキ一覧・検索・カード詳細・一人回しのUI整理と既存機能を維持しました。今回、テーマ以外の画面実装、DB取得・日本語補完・更新・画像キャッシュ、移行、データ形式、依存バージョンは変更していません。READMEとアプリ内READMEの出典も保持しています。

## Patch適用（前回納品v0.49.1から）

1. 元プロジェクトをバックアップし、Android Studioで実行中なら停止します。
2. `DeckLoom-v0.49.2-patch-from-v0.49.1.zip` を展開し、**ZIP直下のapp・文書等を、元プロジェクトのsettings.gradle.ktsと同じ階層へ上書き**します。files等の中間フォルダはありません。
3. Gradle Sync → Build > Clean Project → 従来と同じ端末・署名でRunし、アプリ内READMEの **v0.49.2** を確認します。

このPatchをv0.49へ直接適用しないでください。v0.49からは前回のv0.49.1用Patchを適用してから今回のPatchを使うか、下記の最新Sourceを別フォルダへ展開します。アンインストール・データ消去・カード検索DB／画像パックの再取得は不要です。同じapplicationId・署名で更新します。

## Source版

`DeckLoom-v0.49.2-source.zip` を別フォルダへ展開し、`DeckLoom-v0.49.2` をAndroid Studioで開きます。JDK 17とAndroid SDK 36を設定してください。SDK・キャッシュ・署名キー・端末固有設定は含めません。

[検証結果](VALIDATION-v0.49.2.md)、[実機確認項目](TODO.md)も参照してください。
