# マナシンボル画像の出典

Wizards of the Coastの日本公式カードギャラリーで使用されているシンボル画像。
元の画像の権利はWizards of the Coastに帰属します。DeckLoomは非公式のファンコンテンツです。

参照ページ: https://mtg-jp.com/products/card-gallery/0000275/650283/
ファンコンテンツ・ポリシー: https://company.wizards.com/ja/legal/fancontentpolicy

画像未収録の記号は元の `{...}` 表記で表示します。

- `{0}`: https://mtg-jp.com/img_sys/cardImages/common/0.png
- `{1}`: https://mtg-jp.com/img_sys/cardImages/common/1.png
- `{2}`: https://mtg-jp.com/img_sys/cardImages/common/2.png
- `{3}`: https://mtg-jp.com/img_sys/cardImages/common/3.png
- `{4}`: https://mtg-jp.com/img_sys/cardImages/common/4.png
- `{5}`: https://mtg-jp.com/img_sys/cardImages/common/5.png
- `{6}`: https://mtg-jp.com/img_sys/cardImages/common/6.png
- `{7}`: https://mtg-jp.com/img_sys/cardImages/common/7.png
- `{8}`: https://mtg-jp.com/img_sys/cardImages/common/8.png
- `{9}`: https://mtg-jp.com/img_sys/cardImages/common/9.png
- `{10}`: https://mtg-jp.com/img_sys/cardImages/common/10.png
- `{11}`: https://mtg-jp.com/img_sys/cardImages/common/11.png
- `{12}`: https://mtg-jp.com/img_sys/cardImages/common/12.png
- `{13}`: https://mtg-jp.com/img_sys/cardImages/common/13.png
- `{15}`: https://mtg-jp.com/img_sys/cardImages/common/15.png
- `{16}`: https://mtg-jp.com/img_sys/cardImages/common/16.png
- `{20}`: https://mtg-jp.com/img_sys/cardImages/common/20.png
- `{W}`: https://mtg-jp.com/img_sys/cardImages/common/W.png
- `{U}`: https://mtg-jp.com/img_sys/cardImages/common/U.png
- `{B}`: https://mtg-jp.com/img_sys/cardImages/common/B.png
- `{R}`: https://mtg-jp.com/img_sys/cardImages/common/R.png
- `{G}`: https://mtg-jp.com/img_sys/cardImages/common/G.png
- `{X}`: https://mtg-jp.com/img_sys/cardImages/common/X.png
- `{Y}`: https://mtg-jp.com/img_sys/cardImages/common/Y.png
- `{Z}`: https://mtg-jp.com/img_sys/cardImages/common/Z.png
- `{C}`: https://mtg-jp.com/img_sys/cardImages/common/C.png
- `{E}`: https://mtg-jp.com/img_sys/cardImages/common/E.png
- `{S}`: https://mtg-jp.com/img_sys/cardImages/common/Snow.png
- `{T}`: https://mtg-jp.com/img_sys/cardImages/common/Tap.png
- `{Q}`: https://mtg-jp.com/img_sys/cardImages/common/Untap.png
- `{TK}`: https://mtg-jp.com/img_sys/cardImages/common/ticket.png
- `{W/U}`: https://mtg-jp.com/img_sys/cardImages/common/WU.png
- `{U/B}`: https://mtg-jp.com/img_sys/cardImages/common/UB.png
- `{B/R}`: https://mtg-jp.com/img_sys/cardImages/common/BR.png
- `{R/G}`: https://mtg-jp.com/img_sys/cardImages/common/RG.png
- `{G/W}`: https://mtg-jp.com/img_sys/cardImages/common/GW.png
- `{W/B}`: https://mtg-jp.com/img_sys/cardImages/common/WB.png
- `{U/R}`: https://mtg-jp.com/img_sys/cardImages/common/UR.png
- `{B/G}`: https://mtg-jp.com/img_sys/cardImages/common/BG.png
- `{R/W}`: https://mtg-jp.com/img_sys/cardImages/common/RW.png
- `{G/U}`: https://mtg-jp.com/img_sys/cardImages/common/GU.png
- `{2/W}`: https://mtg-jp.com/img_sys/cardImages/common/2W.png
- `{W/P}`: https://mtg-jp.com/img_sys/cardImages/common/WP.png
- `{2/U}`: https://mtg-jp.com/img_sys/cardImages/common/2U.png
- `{U/P}`: https://mtg-jp.com/img_sys/cardImages/common/UP.png
- `{2/B}`: https://mtg-jp.com/img_sys/cardImages/common/2B.png
- `{B/P}`: https://mtg-jp.com/img_sys/cardImages/common/BP.png
- `{2/R}`: https://mtg-jp.com/img_sys/cardImages/common/2R.png
- `{R/P}`: https://mtg-jp.com/img_sys/cardImages/common/RP.png
- `{2/G}`: https://mtg-jp.com/img_sys/cardImages/common/2G.png
- `{G/P}`: https://mtg-jp.com/img_sys/cardImages/common/GP.png
- `{G/W/P}`: https://mtg-jp.com/img_sys/cardImages/common/gwp.png
- `{G/U/P}`: https://mtg-jp.com/img_sys/cardImages/common/gup.png
- `{R/W/P}`: https://mtg-jp.com/img_sys/cardImages/common/manasymbol_P_RW.png
- `{R/G/P}`: https://mtg-jp.com/img_sys/cardImages/common/manasymbol_P_RG.png
