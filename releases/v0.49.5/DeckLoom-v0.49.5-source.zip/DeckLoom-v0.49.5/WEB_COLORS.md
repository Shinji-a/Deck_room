# Web版Deckroom配色 — v0.49.5

2026-10-13（日本時間）に現行HTML・CSSを再取得しました。CSSは前版と同じSHA-256で、Theme.ktの基本パレット／補助色35種類は変更していません。今回のタイル・アニメーション・絞り込み・候補コピーは既存の色を利用します。現行Web専用エラー表示とダーク表示の保留も維持します。新しいWeb参照と設計は[DESIGN_RULES.md](DESIGN_RULES.md)を参照してください。

## v0.49.4の配色対応（履歴・現行パレットの根拠）

# Web版Deckroom配色 — v0.49.4

2026-10-10に現行HTML／CSS／JSを再取得し、390px幅のWeb描画からcomputed styleも確認しました。CSSは下記v0.49.2の参照と同一です。今回の基準はWebスマホ表示の見た目で、共通ルール・確認方法と限界は[DESIGN_RULES.md](DESIGN_RULES.md)を参照してください。

基本パレット30色を維持し、現行CSSの上書きから次の補助色を追加しました。

| 役割 | 現行CSS | Android |
| --- | --- | --- |
| ブランド文字 | `.brand`の`#263828` | 最上位のDeckLoom見出し |
| 検索の通常枠 | `.search-bar`の`#7C9C65` | デッキ／検索／領域一覧の共通検索欄 |
| 選択面と文字 | `.type-mode button[aria-pressed=true]`の`#DCEBCF`／`#2D5523` | 選択タブ・カテゴリ・カード面 |
| カード選択枠 | `.card-item.is-selected .card-art`の最終上書き`#648C36` | 選択カードの2dp枠とカテゴリの枠 |

基本パレットと補助色のHEX 35種類はすべて取得CSSに存在します。主要文字色22組（従来20組・ブランド文字・新しい選択文字）は静的に4.5:1以上です。Androidダークでは同じCSSの暗色ベースの役割へ対応させます。Webの専用エラー表示と現行ダーク表示は未確認で、下記の制約を維持します。Androidの実機描画・無効状態・文字拡大・押下時は[TODO.md](TODO.md)で確認が必要です。

## v0.49.2の配色対応（履歴・基本パレットの根拠）

2026-10-10、ユーザー指定の https://deckroom-card-search.justmoment-y.chatgpt.site を再試行し、HTTP 200でタイトル「Deckroom | MTGカード検索」のHTMLを取得できました。リンク先の[配色CSS](https://deckroom-card-search.justmoment-y.chatgpt.site/_next/static/css/index.BJRaQceH.css)と[ページJS](https://deckroom-card-search.justmoment-y.chatgpt.site/_next/static/chunks/page-LP5Z3n5p.js)も取得しています。ブラウザーによる描画・操作は確認していません。

取得CSSのSHA-256は `b8fc557a68594ec6fe5056d732d6f658a2d0201f0d960d0ebc47a722a6cea925`（174,313 bytes）。CSSには:rootが2つあり、後半の明色定義が先頭の暗色定義を上書きしています。HTMLにdarkクラスはありません。現在のWebを暗色と判断して先頭の色を採用しないよう、明色と暗色ベースを区別しました。

| 役割 | 現行Webの根拠 | Androidの主な対応 |
| --- | --- | --- |
| 背景・カード面 | 後半:rootの--background `#F6F7F4`、--card／--popover `#FFFFFF` | background／surface・メニュー面 |
| 主文字・補助文字 | --foreground `#202920`、--muted-foreground `#526153` | onBackground／onSurface／onSurfaceVariant |
| アクセント | --primary `#547627`、--primary-foreground `#FFFFFF`、外部リンク.external `#3E681E` | primary／onPrimary／tertiary |
| 選択状態 | --accent `#E6EEDB`、--accent-foreground `#29451C`。汎用Selectの選択／フォーカスもこの変数を利用 | primaryContainer／secondaryContainerと対応文字色 |
| 境界線 | --input `#CBD5C6`、--border `#D9E0D5` | outline／outlineVariant |
| エラー・負の状態 | .type-row .type-exclude[aria-pressed=true]の文字 `#A04336`、面 `#F4E5E1`。継承--destructiveは `#EF8888` | 明色error／errorContainerは読みやすい負の状態の組を利用。暗色errorはdestructiveを利用 |

Materialのsurface階層には、Webの白・背景・--muted `#EEF1EB`・--secondary `#EFF2EC`・サイドバー `#F0F3ED`を対応させました。Webのレイアウトは移植していません。色の役割をAndroidコンポーネントへ対応させたもので、押下・無効化・立体表示などMaterialの状態描画まで同一とするものではありません。

**Web専用エラー表示は未確認**です。CSSのdestructive色はソースで確認できますが、白に対して2.46:1のため、明色のエラー文字にそのまま使っていません。Webの負の状態に実際に使われる#A04336／#F4E5E1をAndroidのエラーへ対応させました。これらの色を「Webの専用エラー画面を見て確認した色」とは扱いません。

**現行Webのダーク表示も未確認**です。AndroidのDARK／SYSTEM機能を維持するため、同じCSSの先頭に残る暗色ベース（背景#121516、面#1B1F20、文字#EDF0EC、アクセント#C5EF72、選択面#343D31、選択文字#D9F6AC、境界#343B3B／#3B4443）を参照しました。現在のWebページではこれらの変数は後半の明色定義に上書きされており、Webの暗色切り替えを確認したことにはなりません。暗色のエラー面も、確認できた明色の負の状態の組を利用しています。

採用したHEX色30種類がすべて取得CSS内に存在することと、主要文字色20組（ライト10・ダーク10）の静的なコントラストが4.5:1以上であることを照合しました。推測で新しい色値を追加していません。実機の描画・無効状態・文字拡大・押下時の読みやすさはTODO.mdで確認が必要です。

## v0.49.1の保留記録（履歴）

以下は前回納品時の記録です。現在の取得状況と配色は上記v0.49.2を優先してください。

参照先はユーザー指定の https://deckroom-card-search.justmoment-y.chatgpt.site です。2026-10-10、この環境の通信プロキシがHTTPS接続を403で拒否したため、HTML・CSS・表示のいずれも確認できませんでした。添付Android SourceにWeb版の配色定義はありません。

環境設定案の許可ドメインに `deckroom-card-search.justmoment-y.chatgpt.site` を追加して保存しました。設定案の保存は公開・実行中環境への反映を意味しません。環境設定で反映後、再取得して実色を確認する必要があります。Web版ソースを参照できる場合も、その定義を根拠にできます。

| 確認対象 | Androidで対応する主なテーマ値 | 状態 |
| --- | --- | --- |
| 背景・カード面 | background / surface / surfaceContainer | 未確認。Webのページ背景とカード面を確認する |
| 主文字・補助文字 | onBackground / onSurface / onSurfaceVariant | 未確認。本文・見出し・メモ・無効状態を確認する |
| アクセント・操作 | primary / onPrimary / secondary | 未確認。ボタン・リンク・アイコンと文字色を確認する |
| 選択状態 | primaryContainer / secondaryContainer / onPrimaryContainer / onSecondaryContainer | 未確認。選択カード・タブ・カテゴリの面と文字を確認する |
| 境界線 | outline / outlineVariant | 未確認。検索欄・カード・区切り線を確認する |
| エラー | error / onError / errorContainer / onErrorContainer | 未確認。エラー文字・面・ボタンを確認する |

現時点の `ui/theme/Theme.kt` はv0.49と同じMaterial 3の明暗テーマです。Web版と色が一致するとは扱いません。追加・保存エラー、選択状態、境界線などはこの既存テーマの役割名を利用しています。検索進捗の固定紫も既存テーマのprimary参照へ置き換えました。HTMLモックの紫の値は採用していません。

実色を確認できたら、確認元のCSS値または表示根拠と日時をここへ記録し、明暗モードの対応と文字の読みやすさを確認してテーマへ反映してください。Web版のレイアウト移植は対象外です。
