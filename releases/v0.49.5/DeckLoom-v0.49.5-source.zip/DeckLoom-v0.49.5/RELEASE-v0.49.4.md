# DeckLoom v0.49.4 — Webスマホ表示を基準にしたUI

基準は前回納品の **DeckLoom-v0.49.3-source.zip**。versionName **0.49.4** / versionCode **23**、applicationId `jp.deckloom.app`、Room **8**／カード検索DB schema **4**を維持します。

見た目の基準を現行Web版Deckroomのスマホ表示へ変更しました。白・淡い背景・オリーブの操作色、文字の強弱、細い境界線、小さい角丸、線のアイコン、淡い選択状態を共通化し、デッキ一覧・デッキ内容・カード検索・詳細・一人回しへ適用しています。[DESIGN_RULES.md](DESIGN_RULES.md)に現行ソースの根拠とAndroidでの調整を記録しました。

検索の絞り込みと除外をAndroidの下部シートにまとめました。全条件と保存済み検索は維持し、閉じるは下書き破棄、適用は条件を確定して従来の検索操作へ戻ります。グリッドには実カード名とタイプ、選択枠を表示します。一人回しは盤面・手札の寸法とカード移動を維持し、余白を増やしません。

右上4アイコン、横一列フォルダ、虫眼鏡の検索対象・×、即時デッキ検索・表示保存、開いたままの並び順メニュー、等幅の一人回し／追加ボタン、固定位置の追加通知、一括Undo、左下閉じる、詳細内の保存エラーと候補保持を引き継ぎます。HTMLモックの紫・装飾・ダミーデータは採用していません。DB取得・日本語補完・更新・保存形式・依存・出典は変更しません。

## Patch適用（前回納品v0.49.3から）

1. v0.49.3プロジェクトをバックアップし、Android Studioで実行中なら停止します。
2. `DeckLoom-v0.49.4-patch-from-v0.49.3.zip`を展開し、**ZIP直下のapp・文書等を、元のsettings.gradle.ktsがある階層へ上書き**します。files等の中間フォルダはありません。
3. Gradle JDK **17**・Android SDK **36**でGradle Sync → Clean Projectを実行します。Wrapperは前版と同じ **8.14.4**です。
4. 従来と同じapplicationId・署名・端末へRunし、アプリ内READMEの **v0.49.4** と保存データの保持を確認します。

このPatchは前回納品v0.49.3 Source専用です。v0.49.2以前や手修正した異なる版へ直接適用しないでください。適用元が違う場合は最新Sourceを使うか、対応する過去Patchを順番に適用します。アプリのアンインストール・データ消去・カード検索DB／画像パックの再取得は不要です。

## Source版

`DeckLoom-v0.49.4-source.zip`を別フォルダへ展開し、`DeckLoom-v0.49.4`をAndroid Studioで開きます。JDK 17とAndroid SDK 36を設定し、既存と同じ署名でRunすれば保存データを引き継げます。端末固有のlocal.propertiesや署名キーは含みません。

GitHubの`releases/v0.49.4`でZIPを選び、Download raw fileから保存できます。Source一式とPatchの適用後は全156ファイルが一致することを照合しました。検証は[VALIDATION-v0.49.4.md](VALIDATION-v0.49.4.md)、残る実機確認は[TODO.md](TODO.md)を参照してください。
