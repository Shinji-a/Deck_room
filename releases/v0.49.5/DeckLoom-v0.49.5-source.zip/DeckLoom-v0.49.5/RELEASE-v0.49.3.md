# DeckLoom v0.49.3 — Gradle Wrapper更新

基準は前回納品した **DeckLoom-v0.49.2-source.zip**。versionName **0.49.3** / versionCode **22**、applicationId `jp.deckloom.app`、Room **8** / カード検索DB schema **4**を維持します。

## 変更理由と内容

ユーザーのWindows版Android Studioで、Gradle Syncは成功した一方、Gradle 8.13の `DeprecatedGradleVersionWarning` が表示されました。これは現在の同期失敗ではなく、今後のKotlin 2.5.0では最低Gradle 8.14.4になるという予告です。同じ警告をクラウドでも再現しました。

Gradle Wrapperを **8.13 → 8.14.4** へ更新し、標準のgradlew・gradlew.bat・Wrapper JARを再生成しました。公式配布のSHA-256とJARのSHA-256を照合しています。警告抑制フラグは追加していません。AGP 8.13.0・Kotlin 2.4.20・KSP 2.3.10・JDK 17・SDK 36と、その他のアプリ依存は維持します。Kotlin 2.5.0への更新は今回含みません。

v0.49.2のUI・Web配色、DB取得・日本語補完・更新、画像、データ形式、スキーマ、READMEの出典を保持します。アプリのソース・リソース・テストは前版と同一で、アプリ側の変更はバージョン表記です。

## Patch適用（前回納品v0.49.2から）

1. 前回のv0.49.2プロジェクトをバックアップし、Android Studioで実行中なら停止します。
2. `DeckLoom-v0.49.3-patch-from-v0.49.2.zip` を展開し、**ZIP直下のapp・gradle・gradlew・gradlew.bat・文書等を、元プロジェクトのsettings.gradle.ktsと同じ階層へ上書き**します。files等の中間フォルダはありません。
3. Android StudioのGradle JDKを **17** にし、Gradle Syncを実行します。初回はGradle 8.14.4をダウンロードするため通信が必要です。
4. Clean Projectを行い、従来と同じapplicationId・署名・端末へRunして、アプリ内READMEの **v0.49.3** を確認します。

このPatchはv0.49.2 Source専用です。v0.49やv0.49.1へ直接適用しないでください。適用元が異なる場合は最新Sourceを別フォルダへ展開するか、順番に既存Patchを適用してください。アンインストール・データ消去・カード検索DB／画像パックの再取得は不要です。

## Source版

`DeckLoom-v0.49.3-source.zip` を別フォルダへ展開し、`DeckLoom-v0.49.3` をAndroid Studioで開きます。JDK 17とAndroid SDK 36を設定してください。SDK・キャッシュ・署名キー・ビルド生成物・端末固有設定は含みません。

GitHubの `releases/v0.49.3` から対象ZIPを選び、ファイルのダウンロードボタン（Download raw file）で保存できます。検証結果は[VALIDATION-v0.49.3.md](VALIDATION-v0.49.3.md)、Windows環境と実機の残る確認は[TODO.md](TODO.md)を参照してください。
